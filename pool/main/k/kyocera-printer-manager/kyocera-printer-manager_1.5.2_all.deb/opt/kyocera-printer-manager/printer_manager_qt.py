#!/usr/bin/env python3
"""High-fidelity Qt desktop interface for Printer Counter."""

from __future__ import annotations

import json
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

if sys.platform == "win32":
    try:
        import ctypes
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass

try:
    from PySide6.QtCore import QObject, QRunnable, QSize, Qt, QThreadPool, QTimer, Signal
    from PySide6.QtGui import QColor, QIcon, QPixmap
    from PySide6.QtWidgets import (
        QApplication, QComboBox, QDialog, QDialogButtonBox, QFrame, QGridLayout, QLayout,
        QHBoxLayout, QLabel, QLineEdit, QListWidget, QMainWindow, QMessageBox,
        QPushButton, QScrollArea, QSizePolicy, QStackedWidget, QTextEdit, QVBoxLayout,
        QWidget,
    )
except ImportError:
    # Zorin/Ubuntu repositories consistently provide PyQt5 even when the
    # split PySide6 packages are unavailable.
    from PyQt5.QtCore import QObject, QRunnable, QSize, Qt, QThreadPool, QTimer, pyqtSignal as Signal
    from PyQt5.QtGui import QColor, QIcon, QPixmap
    from PyQt5.QtWidgets import (
        QApplication, QComboBox, QDialog, QDialogButtonBox, QFrame, QGridLayout, QLayout,
        QHBoxLayout, QLabel, QLineEdit, QListWidget, QMainWindow, QMessageBox,
        QPushButton, QScrollArea, QSizePolicy, QStackedWidget, QTextEdit, QVBoxLayout,
        QWidget,
    )

from app_paths import CONFIG_PATH, RESOURCE_DIR, STATUS_PATH, ensure_data_dir
from auto_update import check_for_update
from delivery_queue import enqueue_payload, process_queue
from network_discovery import scan_all_printers
from printer_forwarder import collect_all_printers, load_config, send_to_api
from secret_store import PLACEHOLDER, save_api_secrets
from usb_collector import usb_profile


APP_VERSION = "1.5.2"
COLORS = {
    "bg": "#0c111b", "sidebar": "#0f1520", "panel": "#121b28",
    "panel2": "#182333", "line": "#263244", "text": "#edf2fa",
    "muted": "#77879f", "blue": "#4089f6", "green": "#64d9a2",
    "amber": "#f0bb60", "red": "#ff626d",
}

def svg_icon(name: str, color: str = "#b9d2ff", size: int = 22) -> QIcon:
    # Prefer bundled PNGs. PyQt5 may be installed without the optional QtSvg
    # plugin on Ubuntu/Zorin, which otherwise makes icons silently disappear.
    png_name = {
        "brand-printer": "printer", "fleet-printer": "printer",
        "manage": "settings", "globe": "activity", "snmp": "online",
        "activity-empty": "activity", "chevron-right": "send",
    }.get(name, name)
    variants = {
        COLORS["blue"]: "blue", COLORS["green"]: "green", COLORS["amber"]: "amber",
        COLORS["red"]: "red", "white": "white", "#ffffff": "white",
    }
    variant = variants.get(color.lower(), "light")
    png_asset = RESOURCE_DIR / "assets" / "icons" / f"{png_name}-{variant}.png"
    if png_asset.exists():
        return QIcon(str(png_asset))

    figma_name = {
        "online": "activity", "document": "printer", "send": "chevron-right",
        "trash": "settings",
    }.get(name, name)
    figma_asset = RESOURCE_DIR / "assets" / "figma" / f"{figma_name}.svg"
    if figma_asset.exists():
        return QIcon(str(figma_asset))
    return QIcon()


def icon_label(name: str, color: str, size: int = 24) -> QLabel:
    label = QLabel()
    label.setPixmap(svg_icon(name, color, size).pixmap(size, size))
    label.setFixedSize(size, size)
    return label


class WorkerSignals(QObject):
    done = Signal(object)
    failed = Signal(str)


class Worker(QRunnable):
    def __init__(self, action: Callable[[], Any]):
        super().__init__()
        self.action = action
        self.signals = WorkerSignals()

    def run(self) -> None:
        try:
            self.signals.done.emit(self.action())
        except Exception as exc:
            self.signals.failed.emit(str(exc))


class PrinterCounterWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        ensure_data_dir()
        self.setWindowTitle("Printer Counter")
        self.setMinimumSize(1000, 620)
        self.resize(1480, 850)
        self.thread_pool = QThreadPool.globalInstance()
        screen = QApplication.primaryScreen()
        self.compact_ui = (screen.availableGeometry().height() / max(1.0, screen.devicePixelRatio())) < 740
        self.last_payload: dict[str, Any] | None = None
        self.update_check_running = False
        self.config = load_config(CONFIG_PATH)
        self.profiles = list(self.config.get("printers") or [])
        self.nav_buttons: dict[str, QPushButton] = {}
        self._apply_style()
        self._build_ui()
        self.refresh_dashboard()
        self.refresh_service()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_service)
        self.timer.start(5000)
        QTimer.singleShot(350, self.refresh_printer_data)
        QTimer.singleShot(1800, self.check_for_updates)

    def _apply_style(self) -> None:
        self.setStyleSheet(f"""
            * {{ font-family: 'Segoe UI'; color: {COLORS['text']}; }}
            QMainWindow, QWidget#root {{ background: {COLORS['bg']}; }}
            QFrame#sidebar {{ background: {COLORS['sidebar']}; border-right: 1px solid {COLORS['line']}; }}
            QFrame#toolbar {{ background: {COLORS['bg']}; border-bottom: 1px solid {COLORS['line']}; }}
            QFrame#card, QFrame#metric, QFrame#delivery, QFrame#panel {{ background: {COLORS['panel']}; border: 1px solid {COLORS['line']}; border-radius: 10px; }}
            QLabel#muted {{ color: {COLORS['muted']}; }}
            QPushButton {{ background: #182333; border: 1px solid {COLORS['line']}; border-radius: 7px; padding: 9px 14px; font-size: 13px; font-weight: 600; }}
            QPushButton:hover {{ background: #213047; border-color: #35465e; }}
            QPushButton:pressed {{ background: #18304f; }}
            QPushButton#primary {{ background: {COLORS['blue']}; border: none; font-weight: 700; }}
            QPushButton#primary:hover {{ background: #5597f8; }}
            QPushButton#nav {{ text-align: left; border: 0; background: transparent; color: #a6b3c7; padding: 12px; font-size: 13px; }}
            QPushButton#nav:checked {{ background: #182e4b; color: #90beff; font-weight: 700; }}
            QLineEdit, QComboBox, QListWidget, QTextEdit {{ background: #0f1724; border: 1px solid {COLORS['line']}; border-radius: 7px; padding: 10px; selection-background-color: {COLORS['blue']}; }}
            QLineEdit:focus, QComboBox:focus, QListWidget:focus, QTextEdit:focus {{ border: 1px solid {COLORS['blue']}; }}
            QScrollArea, QScrollArea > QWidget, QScrollArea > QWidget > QWidget {{ border: 0; background: {COLORS['bg']}; }}
            QScrollBar:vertical {{ width: 8px; background: transparent; }}
            QScrollBar::handle:vertical {{ background: #355475; border-radius: 4px; min-height: 30px; }}
            QDialog, QMessageBox {{ background-color: {COLORS['panel']}; }}
            QMessageBox QLabel {{ color: {COLORS['text']}; background: transparent; font-size: 13px; }}
            QMessageBox QPushButton {{ min-width: 92px; color: {COLORS['text']}; background: #182333; }}
            QLabel#sectionTitle {{ font-size: 16px; font-weight: 700; }}
            QLabel#eyebrow {{ color: {COLORS['blue']}; font-size: 11px; font-weight: 800; }}
            QFrame#softCard {{ background: {COLORS['panel']}; border: 1px solid {COLORS['line']}; border-radius: 10px; }}
        """)

    def _build_ui(self) -> None:
        root = QWidget(objectName="root")
        self.setCentralWidget(root)
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        sidebar = QFrame(objectName="sidebar")
        sidebar.setFixedWidth(228)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(16, 27, 16, 24)
        side.setSpacing(0)
        brand = QHBoxLayout()
        brand.setContentsMargins(8, 0, 0, 0)
        brand.setSpacing(10)
        icon = QLabel()
        icon.setPixmap(svg_icon("brand-printer", COLORS["blue"]).pixmap(18, 18))
        icon.setFixedSize(30, 32)
        icon.setAlignment(Qt.AlignCenter)
        icon.setStyleSheet("background:#182e4b; border-radius:7px;")
        brand.addWidget(icon)
        brand_text = QVBoxLayout()
        brand_text.setSpacing(0)
        title = QLabel("Printer Counter")
        title.setStyleSheet("font-size:15px; font-weight:500;")
        version = QLabel(f"Version {APP_VERSION}", objectName="muted")
        version.setStyleSheet("font-size:9px;")
        brand_text.addWidget(title)
        brand_text.addWidget(version)
        brand.addLayout(brand_text)
        brand.addStretch()
        side.addLayout(brand)
        side.addSpacing(38)
        workspace = QLabel("WORKSPACE", objectName="muted")
        workspace.setStyleSheet("font-size:10px; font-weight:600;")
        side.addWidget(workspace)
        side.addSpacing(6)
        for key, label, icon_name in (("dashboard", "Dashboard", "dashboard"), ("printers", "Printers", "printer"), ("activity", "Activity", "activity"), ("settings", "Settings", "settings")):
            button = QPushButton(label, objectName="nav", checkable=True)
            button.setFixedHeight(44)
            button.setIcon(svg_icon(icon_name, "#a6b3c7", 18))
            button.setIconSize(QSize(18, 18))
            button.setShortcut({"dashboard": "Ctrl+1", "printers": "Ctrl+2", "activity": "Ctrl+3", "settings": "Ctrl+4"}[key])
            button.clicked.connect(lambda _checked=False, name=key: self.show_page(name))
            side.addWidget(button)
            self.nav_buttons[key] = button
        side.addStretch()
        service_card = QFrame(objectName="panel")
        service_layout = QVBoxLayout(service_card)
        service_layout.setContentsMargins(14, 11, 14, 11)
        service_layout.setSpacing(8)
        service_title = QLabel("PRINTER SERVICE", objectName="muted")
        service_title.setStyleSheet("font-size:10px;")
        service_layout.addWidget(service_title)
        self.service_badge = QLabel("●  Service checking")
        self.service_badge.setStyleSheet(f"color:{COLORS['muted']}; font-size:12px; font-weight:500;")
        service_layout.addWidget(self.service_badge)
        side.addWidget(service_card)
        outer.addWidget(sidebar)

        content = QWidget()
        content.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        body = QVBoxLayout(content)
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        toolbar = QFrame(objectName="toolbar")
        toolbar.setFixedHeight(76)
        header = QHBoxLayout(toolbar)
        header.setContentsMargins(40, 0, 40, 0)
        breadcrumb = QLabel("Workspace   ›   ", objectName="muted")
        breadcrumb.setStyleSheet("font-size:12px;")
        header.addWidget(breadcrumb)
        self.page_title = QLabel("Dashboard")
        self.page_title.setStyleSheet("font-size:12px; color:#a6b3c7;")
        header.addWidget(self.page_title)
        header.addStretch()
        manual = QPushButton("Add Manually")
        manual.setFixedHeight(38)
        manual.setIcon(svg_icon("plus"))
        manual.clicked.connect(self.add_manually)
        header.addWidget(manual)
        scan = QPushButton("Scan Printers", objectName="primary")
        scan.setFixedHeight(38)
        scan.setIcon(svg_icon("search", "white"))
        scan.clicked.connect(self.scan_network)
        header.addWidget(scan)
        body.addWidget(toolbar)
        self.stack = QStackedWidget()
        self.stack.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.dashboard = self._build_dashboard()
        self.printers_page = self._build_printers_page()
        self.activity = self._build_activity()
        self.settings = self._build_settings()
        self.stack.addWidget(self.dashboard)
        self.stack.addWidget(self.printers_page)
        self.stack.addWidget(self.activity)
        self.stack.addWidget(self.settings)
        body.addWidget(self.stack, 1)
        outer.addWidget(content, 1)
        self.show_page("dashboard")

    def _metric(self, label: str, color: str, icon_name: str) -> tuple[QFrame, QLabel]:
        frame = QFrame(objectName="metric")
        frame.setFixedHeight(116)
        layout = QVBoxLayout(frame)
        layout.setSizeConstraint(QLayout.SetNoConstraint)
        frame.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        layout.setContentsMargins(24, 18, 18, 18)
        top = QHBoxLayout()
        caption = QLabel(label, objectName="muted")
        caption.setStyleSheet("font-size:13px; color:#a6b3c7;")
        top.addWidget(caption)
        top.addStretch()
        top.addWidget(icon_label(icon_name, color, 18))
        layout.addLayout(top)
        layout.addStretch()
        value = QLabel("—")
        value.setStyleSheet(f"font-size:28px; font-weight:600; color:{COLORS['text']};")
        layout.addWidget(value)
        return frame, value

    def _build_dashboard(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        page = QWidget()
        page.setMinimumWidth(780)
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 30, 40, 40)
        layout.setSpacing(20)
        heading = QLabel("Dashboard")
        heading.setStyleSheet("font-size:30px; font-weight:400;")
        layout.addWidget(heading)
        subtitle = QLabel("Printer service, collection status, and delivery at a glance.", objectName="muted")
        subtitle.setStyleSheet("font-size:13px; color:#a6b3c7;")
        layout.addWidget(subtitle)
        layout.addSpacing(8)
        metrics = QHBoxLayout()
        metrics.setSpacing(16)
        self.metrics: dict[str, QLabel] = {}
        self.metric_cards: list[QFrame] = []
        for key, label, color, icon_name in (("last", "Last collection", COLORS["blue"], "refresh"), ("delivery", "Delivery state", COLORS["green"], "check"), ("queue", "Queued reports", COLORS["amber"], "clock")):
            card, value = self._metric(label, color, icon_name)
            self.metrics[key] = value
            self.metric_cards.append(card)
            metrics.addWidget(card, 1)
        self.delivery_text = self.metrics["delivery"]
        layout.addLayout(metrics)
        split = QHBoxLayout()
        split.setSpacing(24)
        fleet = QFrame(objectName="panel")
        fleet_box = QVBoxLayout(fleet)
        fleet_box.setContentsMargins(0, 0, 0, 0)
        fleet_box.setSpacing(0)
        fleet_head = QFrame()
        fleet_head.setObjectName("panelHeader")
        fleet_head.setFixedHeight(91)
        fleet_head.setStyleSheet(f"QFrame#panelHeader{{border-bottom:1px solid {COLORS['line']};}}")
        fleet_head_row = QHBoxLayout(fleet_head)
        fleet_head_row.setContentsMargins(24, 18, 24, 18)
        titles = QVBoxLayout()
        titles.setSpacing(5)
        fleet_title = QLabel("Printer fleet", objectName="sectionTitle")
        titles.addWidget(fleet_title)
        titles.addWidget(QLabel("Configured printers and available counters", objectName="muted"))
        fleet_head_row.addLayout(titles)
        fleet_head_row.addStretch()
        self.fleet_service_badge = QLabel("●  Service checking")
        self.fleet_service_badge.setFixedHeight(23)
        self.fleet_service_badge.setStyleSheet(f"background:#16322b; color:{COLORS['green']}; border-radius:12px; padding:5px 9px; font-size:11px; font-weight:600;")
        fleet_head_row.addWidget(self.fleet_service_badge)
        fleet_box.addWidget(fleet_head)
        self.dashboard_fleet_rows = QVBoxLayout()
        self.dashboard_fleet_rows.setContentsMargins(24, 0, 24, 0)
        self.dashboard_fleet_rows.setSpacing(0)
        fleet_box.addLayout(self.dashboard_fleet_rows)
        split.addWidget(fleet, 1)

        connection = QFrame(objectName="panel")
        connection.setFixedWidth(400)
        connection_box = QVBoxLayout(connection)
        connection_box.setContentsMargins(24, 18, 24, 22)
        connection_box.setSpacing(18)
        connection_box.addWidget(QLabel("Connection", objectName="sectionTitle"))
        self.connection_address = QLabel("—", objectName="muted")
        self.connection_address.setStyleSheet("font-size:12px;")
        connection_box.addWidget(self.connection_address)
        line = QFrame()
        line.setFixedHeight(1)
        line.setStyleSheet(f"background:{COLORS['line']}; border:0;")
        connection_box.addWidget(line)
        for icon_name, title_text, detail, color in (
            ("snmp", "SNMP collection", "UDP 161 · Community: public", COLORS["green"]),
            ("globe", "Web fallback", "HTTP 80 · Automatic panel detection", "#90beff"),
            ("calendar", "Scheduled delivery", "12:00 PM and 3:00 PM", COLORS["amber"]),
        ):
            item = QHBoxLayout()
            item.setSpacing(12)
            item.addWidget(icon_label(icon_name, color, 18), 0, Qt.AlignTop)
            words = QVBoxLayout()
            words.setSpacing(4)
            label = QLabel(title_text)
            label.setStyleSheet("font-size:12px; font-weight:600;")
            words.addWidget(label)
            detail_label = QLabel(detail, objectName="muted")
            detail_label.setStyleSheet("font-size:11px;")
            words.addWidget(detail_label)
            item.addLayout(words, 1)
            connection_box.addLayout(item)
        connection_box.addStretch()
        split.addWidget(connection)
        layout.addLayout(split)

        log = QFrame(objectName="panel")
        log_box = QVBoxLayout(log)
        log_box.setContentsMargins(24, 18, 24, 24)
        log_box.setSpacing(6)
        log_box.addWidget(QLabel("Activity log", objectName="sectionTitle"))
        log_box.addWidget(QLabel("Collection and delivery activity", objectName="muted"))
        empty = QVBoxLayout()
        empty.setContentsMargins(0, 28, 0, 12)
        symbol = icon_label("activity-empty", "#a6b3c7", 24)
        symbol.setAlignment(Qt.AlignCenter)
        empty.addWidget(symbol, 0, Qt.AlignHCenter)
        self.activity_preview = QLabel("Collection and delivery activity will appear here.", objectName="muted", alignment=Qt.AlignCenter)
        self.activity_preview.setStyleSheet("font-size:12px; padding-top:8px;")
        empty.addWidget(self.activity_preview)
        log_box.addLayout(empty)
        layout.addWidget(log)
        layout.addStretch()
        scroll.setWidget(page)
        return scroll

    def _clear_layout(self, layout: QGridLayout) -> None:
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def refresh_dashboard(self) -> None:
        while self.dashboard_fleet_rows.count():
            item = self.dashboard_fleet_rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        payload = (self.last_payload or {}).get("printers", [])
        by_id = {str(item.get("id")): item for item in payload}
        for index, profile in enumerate(self.profiles):
            result = by_id.get(str(profile.get("id")), {})
            if result.get("ok") is True:
                status, color = "Online", COLORS["green"]
            elif result.get("ok") is False:
                status, color = "Offline", COLORS["red"]
            else:
                status, color = "Ready", COLORS["amber"]
            self.dashboard_fleet_rows.addWidget(self._fleet_row(index, profile, result, status, color))
        if not self.profiles:
            empty = QLabel("No printers configured. Add one manually or scan the network.", objectName="muted", alignment=Qt.AlignCenter)
            empty.setStyleSheet("padding:30px;")
            self.dashboard_fleet_rows.addWidget(empty)
        first = self.profiles[0] if self.profiles else {}
        if first.get("connection_type") == "usb":
            self.connection_address.setText(str(first.get("usb", {}).get("port") or "USB"))
        else:
            self.connection_address.setText(str(first.get("snmp", {}).get("host") or "—"))
        self._refresh_printers_page()

    def _fleet_row(self, index: int, profile: dict[str, Any], result: dict[str, Any], status: str, color: str) -> QFrame:
        row_frame = QFrame()
        row_frame.setObjectName("fleetRow")
        row_frame.setFixedHeight(166)
        row_frame.setStyleSheet(f"QFrame#fleetRow{{border-bottom:1px solid {COLORS['line']};}}")
        row = QGridLayout(row_frame)
        row.setContentsMargins(0, 20, 0, 20)
        row.setHorizontalSpacing(12)
        row.setVerticalSpacing(6)
        row.setColumnStretch(1, 3)
        row.setColumnStretch(2, 2)
        row.setColumnStretch(3, 2)
        symbol = QLabel()
        symbol.setFixedSize(42, 42)
        symbol.setAlignment(Qt.AlignCenter)
        symbol.setPixmap(svg_icon("fleet-printer", COLORS["blue"]).pixmap(22, 22))
        symbol.setStyleSheet("background:#182333; border:0; border-radius:7px;")
        row.addWidget(symbol, 0, 0, 2, 1, Qt.AlignTop)
        printer = result.get("printer", {})
        counters = result.get("counters", {})
        is_usb = str(profile.get("connection_type", "network")).lower() == "usb"
        address = str(profile.get("usb", {}).get("port") or "USB") if is_usb else str(profile.get("snmp", {}).get("host") or "—")
        name = str(printer.get("model") or profile.get("name") or f"Printer {index + 1}")
        title = QLabel(name)
        title.setStyleSheet("font-size:15px; font-weight:600;")
        row.addWidget(title, 0, 1, Qt.AlignBottom)
        target = QLabel(address, objectName="muted")
        target.setStyleSheet("font-family:'Cascadia Mono','Consolas'; font-size:12px; color:#a6b3c7;")
        row.addWidget(target, 1, 1, Qt.AlignTop)
        status_label = QLabel(f"●  {status}")
        status_label.setFixedHeight(23)
        status_label.setStyleSheet(f"background:#332b1c; color:{color}; border:0; border-radius:12px; padding:5px 9px; font-size:11px; font-weight:600;")
        row.addWidget(status_label, 0, 3, 2, 1, Qt.AlignRight | Qt.AlignVCenter)
        serial = str(printer.get("serial_number") or profile.get("usb", {}).get("serial_number") or profile.get("discovery", {}).get("serial_number") or "—")
        total = counters.get("copy_printer_fax_total", counters.get("printed_pages", {}).get("total", "—"))
        for column, (caption, value) in enumerate((("Serial", serial), ("Total counter", f"{total:,}" if isinstance(total, int) else str(total)))):
            cap = QLabel(caption, objectName="muted")
            cap.setStyleSheet("font-size:11px;")
            val = QLabel(value)
            val.setStyleSheet("font-size:14px; color:#a6b3c7;")
            row.addWidget(cap, 2, column + 1, Qt.AlignBottom)
            row.addWidget(val, 3, column + 1, Qt.AlignTop)
        manage = QPushButton("Manage")
        manage.setIcon(svg_icon("manage"))
        manage.setFixedHeight(38)
        manage.clicked.connect(lambda _checked=False, i=index: self.open_settings(i))
        row.addWidget(manage, 2, 3, 2, 1, Qt.AlignRight | Qt.AlignBottom)
        return row_frame

    def _fit_dashboard_cards(self) -> None:
        return

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        QTimer.singleShot(0, self._fit_dashboard_cards)

    def _printer_card(self, index: int, profile: dict[str, Any], result: dict[str, Any], status: str, color: str) -> QFrame:
        card = QFrame(objectName="card")
        box = QVBoxLayout(card)
        card.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Expanding)
        box.setContentsMargins(12, 10, 12, 10)
        box.setSpacing(4)
        image = QLabel(alignment=Qt.AlignCenter)
        pixmap = QPixmap(str(RESOURCE_DIR / "assets" / "printer-card.png"))
        image_size = (175, 115) if self.compact_ui else (200, 140)
        image.setPixmap(pixmap.scaled(*image_size, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        box.addWidget(image)
        printer = result.get("printer", {})
        counters = result.get("counters", {})
        name = str(printer.get("model") or profile.get("name") or f"Printer {index + 1}")
        title = QLabel(name)
        title.setWordWrap(True)
        title.setStyleSheet("font-size:16px; font-weight:800;")
        box.addWidget(title)
        state = QLabel(f"●  {status}")
        state.setStyleSheet(f"color:{color}; font-size:13px; font-weight:700; padding-bottom:2px; border-bottom:1px solid {COLORS['line']};")
        box.addWidget(state)
        is_usb = str(profile.get("connection_type", "network")).lower() == "usb"
        connection = str(profile.get("usb", {}).get("port") or "USB") if is_usb else str(profile.get("snmp", {}).get("host") or "—")
        serial = str(printer.get("serial_number") or profile.get("usb", {}).get("serial_number") or profile.get("discovery", {}).get("serial_number") or "—")
        total = counters.get("copy_printer_fax_total", counters.get("printed_pages", {}).get("total", "—"))
        for label, value in (("USB connection" if is_usb else "IP address", connection), ("Serial number", serial), ("Copy + Printer + Fax", "")):
            row = QHBoxLayout()
            left = QLabel(label, objectName="muted")
            right = QLabel(str(value))
            row.addWidget(left)
            row.addStretch()
            row.addWidget(right)
            box.addLayout(row)
        total_row = QHBoxLayout()
        total_row.addWidget(icon_label("document", "#b9d2ff", 20))
        total_caption = QLabel("Total")
        total_caption.setStyleSheet("font-size:14px; font-weight:700;")
        total_row.addWidget(total_caption)
        total_row.addStretch()
        total_label = QLabel(f"{total:,}" if isinstance(total, int) else str(total), alignment=Qt.AlignRight)
        total_label.setStyleSheet("font-size:23px; font-weight:800;")
        total_row.addWidget(total_label)
        box.addLayout(total_row)
        actions = QHBoxLayout()
        test = QPushButton("Test")
        test.setStyleSheet("padding:6px;")
        test.setIcon(svg_icon("document", "#b9d2ff", 18))
        test.clicked.connect(self.test_all)
        actions.addWidget(test, 1)
        manage = QPushButton("•••")
        manage.setStyleSheet("padding:6px;")
        manage.setFixedWidth(58)
        manage.clicked.connect(lambda: self.open_settings(index))
        actions.addWidget(manage)
        box.addLayout(actions)
        return card

    def _add_card(self) -> QFrame:
        card = QFrame(objectName="card")
        box = QVBoxLayout(card)
        card.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Expanding)
        box.setContentsMargins(18, 18, 18, 18)
        box.addStretch()
        title = QLabel("Add another printer", alignment=Qt.AlignCenter)
        title.setStyleSheet("font-size:18px; font-weight:800;")
        box.addWidget(title)
        info = QLabel("Enter an IP address or scan network and USB printers.", objectName="muted", alignment=Qt.AlignCenter)
        info.setWordWrap(True)
        info.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        box.addWidget(info)
        manual = QPushButton("Add Manually")
        manual.setIcon(svg_icon("plus", "#b9d2ff"))
        manual.clicked.connect(self.add_manually)
        box.addWidget(manual)
        scan = QPushButton("Scan Printers", objectName="primary")
        scan.setIcon(svg_icon("search", "white"))
        scan.clicked.connect(self.scan_network)
        box.addWidget(scan)
        box.addStretch()
        return card

    def _build_printers_page(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        page = QWidget()
        page.setMinimumWidth(780)
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 30, 40, 40)
        layout.setSpacing(20)
        heading = QLabel("Printers")
        heading.setStyleSheet("font-size:30px; font-weight:400;")
        layout.addWidget(heading)
        layout.addWidget(QLabel("Configured devices and their available counter data.", objectName="muted"))
        layout.addSpacing(8)
        panel = QFrame(objectName="panel")
        panel_box = QVBoxLayout(panel)
        panel_box.setContentsMargins(0, 0, 0, 0)
        panel_box.setSpacing(0)
        panel_head = QFrame()
        panel_head.setObjectName("panelHeader")
        panel_head.setFixedHeight(91)
        panel_head.setStyleSheet(f"QFrame#panelHeader{{border-bottom:1px solid {COLORS['line']};}}")
        intro_row = QHBoxLayout(panel_head)
        intro_row.setContentsMargins(24, 18, 24, 18)
        intro_text = QVBoxLayout()
        intro_text.setSpacing(5)
        intro_text.addWidget(QLabel("Printer fleet", objectName="sectionTitle"))
        intro_text.addWidget(QLabel("Manage addresses, verify counters, and check connectivity.", objectName="muted"))
        intro_row.addLayout(intro_text)
        intro_row.addStretch()
        test = QPushButton("Test all")
        test.setFixedHeight(38)
        test.setIcon(svg_icon("refresh"))
        test.clicked.connect(self.test_all)
        intro_row.addWidget(test)
        panel_box.addWidget(panel_head)
        headings = QFrame()
        headings.setFixedHeight(42)
        headings.setStyleSheet("background:#0f1520; border:0;")
        columns = QHBoxLayout(headings)
        columns.setContentsMargins(24, 13, 24, 13)
        columns.setSpacing(24)
        for text, stretch in (("PRINTER", 4), ("STATUS", 1), ("SERIAL", 2), ("TOTAL COUNTER", 2), ("ACTIONS", 1)):
            label = QLabel(text, objectName="muted")
            label.setStyleSheet("font-size:10px; font-weight:600;")
            columns.addWidget(label, stretch)
        panel_box.addWidget(headings)
        self.printer_rows = QVBoxLayout()
        self.printer_rows.setSpacing(0)
        panel_box.addLayout(self.printer_rows)
        self.printer_count_label = QLabel("0 configured printers", objectName="muted")
        self.printer_count_label.setStyleSheet("padding:16px 24px; font-size:11px;")
        panel_box.addWidget(self.printer_count_label)
        layout.addWidget(panel)
        layout.addStretch()
        scroll.setWidget(page)
        return scroll

    def _refresh_printers_page(self) -> None:
        if not hasattr(self, "printer_rows"):
            return
        while self.printer_rows.count():
            item = self.printer_rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        payload = (self.last_payload or {}).get("printers", [])
        by_id = {str(item.get("id")): item for item in payload}
        for index, profile in enumerate(self.profiles):
            result = by_id.get(str(profile.get("id")), {})
            printer = result.get("printer", {})
            counters = result.get("counters", {})
            total = counters.get("copy_printer_fax_total", counters.get("printed_pages", {}).get("total", "—"))
            status = "Online" if result.get("ok") is True else "Offline" if result.get("ok") is False else "Ready"
            color = COLORS["green"] if result.get("ok") is True else COLORS["red"] if result.get("ok") is False else COLORS["amber"]
            card = QFrame()
            card.setObjectName("printerTableRow")
            card.setFixedHeight(90)
            card.setStyleSheet(f"QFrame#printerTableRow{{border-bottom:1px solid {COLORS['line']};}}")
            row = QHBoxLayout(card)
            row.setContentsMargins(24, 17, 24, 17)
            row.setSpacing(24)
            identity_wrap = QWidget()
            identity = QHBoxLayout(identity_wrap)
            identity.setContentsMargins(0, 0, 0, 0)
            identity.setSpacing(14)
            symbol = QLabel()
            symbol.setFixedSize(40, 40)
            symbol.setAlignment(Qt.AlignCenter)
            symbol.setPixmap(svg_icon("fleet-printer").pixmap(22, 22))
            symbol.setStyleSheet("background:#182333; border:0; border-radius:7px;")
            identity.addWidget(symbol)
            text = QVBoxLayout()
            text.setSpacing(6)
            name = QLabel(str(printer.get("model") or profile.get("name") or f"Printer {index + 1}"))
            name.setStyleSheet("font-size:13px; font-weight:600;")
            text.addWidget(name)
            connection = profile.get("usb", {}).get("port") if profile.get("connection_type") == "usb" else profile.get("snmp", {}).get("host")
            address = QLabel(str(connection or "—"), objectName="muted")
            address.setStyleSheet("font-family:'Consolas'; font-size:11px;")
            text.addWidget(address)
            identity.addLayout(text, 1)
            row.addWidget(identity_wrap, 4)
            state = QLabel(f"●  {status}")
            state.setFixedSize(82, 23)
            state.setAlignment(Qt.AlignCenter)
            state.setStyleSheet(f"background:#332b1c; color:{color}; border:0; border-radius:12px; padding:5px 9px; font-size:11px; font-weight:600;")
            row.addWidget(state, 1)
            serial_value = QLabel(str(printer.get("serial_number") or profile.get("usb", {}).get("serial_number") or profile.get("discovery", {}).get("serial_number") or "—"))
            serial_value.setStyleSheet("font-family:'Consolas'; color:#a6b3c7; font-size:14px;")
            row.addWidget(serial_value, 2)
            total_text = f"{total:,}" if isinstance(total, int) else str(total)
            total_value = QLabel(total_text)
            total_value.setStyleSheet("font-family:'Consolas'; color:#a6b3c7; font-size:14px;")
            row.addWidget(total_value, 2)
            manage = QPushButton("Manage")
            manage.setFixedHeight(38)
            manage.setIcon(svg_icon("manage"))
            manage.clicked.connect(lambda _checked=False, i=index: self.open_settings(i))
            row.addWidget(manage, 1)
            self.printer_rows.addWidget(card)
        count = len(self.profiles)
        self.printer_count_label.setText(f"{count} configured printer{'s' if count != 1 else ''}")

    def _build_activity(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        page = QWidget()
        page.setMinimumWidth(780)
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 30, 40, 40)
        layout.setSpacing(20)
        heading = QLabel("Activity")
        heading.setStyleSheet("font-size:30px; font-weight:400;")
        layout.addWidget(heading)
        layout.addWidget(QLabel("Monitor collection and delivery activity from the printer service.", objectName="muted"))
        layout.addSpacing(8)
        summary = QHBoxLayout()
        summary.setSpacing(16)
        self.activity_metrics = {}
        for label, value, color, icon_name in (("Last collection", "Waiting", COLORS["blue"], "refresh"), ("Delivery state", "Ready", COLORS["green"], "check"), ("Queued reports", "0", COLORS["amber"], "clock")):
            card, val = self._metric(label, color, icon_name)
            self.activity_metrics[label] = val
            val.setText(value)
            summary.addWidget(card, 1)
        layout.addLayout(summary)
        log = QFrame(objectName="panel")
        log_box = QVBoxLayout(log)
        log_box.setContentsMargins(0, 0, 0, 0)
        log_box.setSpacing(0)
        log_header = QFrame()
        log_header.setObjectName("activityHeader")
        log_header.setFixedHeight(86)
        log_header.setStyleSheet(f"QFrame#activityHeader{{border-bottom:1px solid {COLORS['line']};}}")
        log_head = QHBoxLayout(log_header)
        log_head.setContentsMargins(24, 18, 24, 18)
        log_head.addWidget(QLabel("Activity log", objectName="sectionTitle"))
        log_head.addStretch()
        clear = QPushButton("Clear view")
        clear.setFixedHeight(38)
        clear.setIcon(svg_icon("activity"))
        clear.clicked.connect(self._clear_activity_log)
        log_head.addWidget(clear)
        log_box.addWidget(log_header)
        self.activity_log = QTextEdit(readOnly=True)
        self.activity_log.setPlainText("Collection and delivery activity will appear here.")
        self.activity_log.setAlignment(Qt.AlignCenter)
        self.activity_log.setMinimumHeight(430)
        self.activity_log.setStyleSheet("border:0; border-radius:0; padding:185px 24px 24px 24px; background:#121b28; color:#a6b3c7;")
        log_box.addWidget(self.activity_log)
        layout.addWidget(log, 1)
        scroll.setWidget(page)
        return scroll

    def _build_settings(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        page = QWidget()
        page.setMinimumWidth(780)
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 30, 40, 40)
        layout.setSpacing(20)
        heading = QLabel("Settings")
        heading.setStyleSheet("font-size:30px; font-weight:400;")
        layout.addWidget(heading)
        layout.addWidget(QLabel("Add a network printer by IP, or discover devices and USB printers automatically.", objectName="muted"))
        section = QHBoxLayout()
        section.setSpacing(10)
        section.addWidget(icon_label("settings", "#90beff", 18))
        section.addWidget(QLabel("Printer settings", objectName="sectionTitle"))
        section.addStretch()
        layout.addLayout(section)
        columns = QHBoxLayout()
        columns.setSpacing(24)
        fleet = QFrame(objectName="panel")
        fleet.setFixedWidth(450)
        fleet.setFixedHeight(526)
        fleet_box = QVBoxLayout(fleet)
        fleet_box.setContentsMargins(16, 18, 16, 16)
        fleet_title = QLabel("Configured printers", objectName="sectionTitle")
        fleet_box.addWidget(fleet_title)
        fleet_box.addWidget(QLabel("Select a printer to edit its connection.", objectName="muted"))
        fleet_box.addSpacing(12)
        self.profile_list = QListWidget()
        self.profile_list.setStyleSheet(f"QListWidget{{border:0;background:transparent;}} QListWidget::item{{padding:16px;border:1px solid transparent;border-radius:7px;}} QListWidget::item:selected{{background:#182e4b;border:1px solid {COLORS['blue']};color:{COLORS['text']};}}")
        self.profile_list.currentRowChanged.connect(self._load_selected_ip)
        fleet_box.addWidget(self.profile_list, 1)
        columns.addWidget(fleet)
        editor = QFrame(objectName="panel")
        editor.setFixedHeight(526)
        editor_box = QVBoxLayout(editor)
        editor_box.setContentsMargins(24, 18, 24, 24)
        editor_box.setSpacing(12)
        editor_box.addWidget(QLabel("Connection", objectName="sectionTitle"))
        editor_box.addSpacing(12)
        self.connection_label = QLabel("PRINTER IP ADDRESS", objectName="eyebrow")
        self.connection_label.setStyleSheet("font-size:10px; color:#77879f;")
        editor_box.addWidget(self.connection_label)
        self.ip_edit = QLineEdit()
        self.ip_edit.setPlaceholderText("Printer IP address")
        self.ip_edit.setFixedHeight(44)
        editor_box.addWidget(self.ip_edit)
        editor_box.addSpacing(2)
        for icon_name, title, detail, color in (
            ("snmp", "SNMP collection", "UDP 161 · Community: public", COLORS["green"]),
            ("globe", "Web fallback", "HTTP 80 · Automatic panel detection", COLORS["blue"]),
            ("calendar", "Scheduled delivery", "12:00 PM and 3:00 PM", COLORS["amber"]),
        ):
            info = QFrame()
            info.setObjectName("connectionMethod")
            info.setStyleSheet(f"QFrame#connectionMethod{{background:#182333;border:1px solid {COLORS['line']};border-radius:7px;}}")
            info_row = QHBoxLayout(info)
            info_row.setContentsMargins(18, 12, 18, 12)
            info_row.addWidget(icon_label(icon_name, color, 20))
            info_text = QVBoxLayout()
            label = QLabel(title)
            label.setStyleSheet("font-size:12px; font-weight:600;")
            info_text.addWidget(label)
            detail_label = QLabel(detail, objectName="muted")
            detail_label.setStyleSheet("font-size:11px;")
            info_text.addWidget(detail_label)
            info_row.addLayout(info_text)
            info_row.addStretch()
            editor_box.addWidget(info)
        editor_box.addStretch()
        columns.addWidget(editor, 1)
        layout.addLayout(columns, 1)
        buttons = QHBoxLayout()
        save = QPushButton("Save", objectName="primary")
        save.setIcon(svg_icon("check", "white", 18))
        save.clicked.connect(self.save_settings)
        buttons.addWidget(save)
        test = QPushButton("Test all printers")
        test.setIcon(svg_icon("refresh", "#b9d2ff", 18))
        test.clicked.connect(self.test_all)
        buttons.addWidget(test)
        updates = QPushButton("Check for updates")
        updates.setIcon(svg_icon("refresh", "#b9d2ff", 18))
        updates.clicked.connect(lambda: self.check_for_updates(manual=True))
        buttons.addWidget(updates)
        send = QPushButton("Send now", objectName="primary")
        send.setIcon(svg_icon("send", "white", 18))
        send.clicked.connect(self.send_now)
        buttons.addWidget(send)
        remove = QPushButton("Remove selected")
        remove.setStyleSheet("color:#f18f98;")
        remove.setIcon(svg_icon("trash", COLORS["red"], 18))
        remove.clicked.connect(self.remove_selected)
        buttons.addStretch()
        buttons.addWidget(remove)
        layout.addLayout(buttons)
        self._refresh_profile_list()
        layout.addStretch()
        scroll.setWidget(page)
        return scroll

    def show_page(self, name: str) -> None:
        pages = {
            "dashboard": self.dashboard,
            "printers": self.printers_page,
            "activity": self.activity,
            "settings": self.settings,
        }
        self.stack.setCurrentWidget(pages.get(name, self.dashboard))
        self.page_title.setText(name.title())
        for key, button in self.nav_buttons.items():
            button.setChecked(key == name)

    def open_settings(self, index: int) -> None:
        self.show_page("settings")
        self.profile_list.setCurrentRow(index)

    def _profile(self, ip: str, index: int, discovered: dict[str, Any] | None = None) -> dict[str, Any]:
        profile = {
            "id": f"printer-{int(time.time() * 1000)}-{index}", "name": f"Printer {index + 1}",
            "connection_type": "network",
            "snmp": {"enabled": True, "host": ip, "port": 161, "community": "public", "timeout_seconds": 5},
            "printer": {"base_url": f"http://{ip}", "timeout_seconds": 15, "wake_retries": 5, "wake_retry_delay_seconds": 2, "verify_tls": True},
        }
        if discovered:
            profile["name"] = str(discovered.get("model") or profile["name"])
            profile["discovery"] = {
                "model": str(discovered.get("model") or ""),
                "serial_number": str(discovered.get("serial_number") or ""),
            }
        return profile

    def add_manually(self) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Printer Manually")
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel("Enter the printer IP address. Network settings are automatic."))
        entry = QLineEdit()
        entry.setPlaceholderText("192.168.1.50")
        layout.addWidget(entry)
        buttons = QDialogButtonBox(QDialogButtonBox.Cancel | QDialogButtonBox.Ok)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.Accepted:
            return
        ip = entry.text().strip()
        parts = ip.split(".")
        if len(parts) != 4 or any(not part.isdigit() or not 0 <= int(part) <= 255 for part in parts):
            QMessageBox.warning(self, "Invalid address", "Enter a valid IPv4 address.")
            return
        if any(p.get("snmp", {}).get("host") == ip for p in self.profiles):
            QMessageBox.information(self, "Already added", "This printer is already configured.")
            return
        self.profiles.append(self._profile(ip, len(self.profiles)))
        self.save_settings(silent=True)
        self._refresh_profile_list()
        self.refresh_dashboard()

    def scan_network(self) -> None:
        self.service_badge.setText("●  Scanning network and USB")
        self.service_badge.setStyleSheet(f"color:{COLORS['blue']}; font-weight:700;")
        self._work(scan_all_printers, self._show_scan)

    def _show_scan(self, result: dict[str, Any]) -> None:
        printers = result.get("printers", [])
        if not printers:
            networks = ", ".join(result.get("networks", [])) or "none detected"
            usb_error = str(result.get("usb_error") or "No USB printer was reported by CUPS or /dev/usb.")
            QMessageBox.information(
                self,
                "Printer Scan",
                f"No network or USB printers were found.\n\nNetworks scanned: {networks}\nUSB: {usb_error}\n\nYou can still add a network printer manually.",
            )
            self.refresh_service()
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("Discovered Printers")
        dialog.resize(720, 440)
        layout = QVBoxLayout(dialog)
        found = QListWidget()
        found.setSelectionMode(QListWidget.MultiSelection)
        for item in printers:
            if item.get("connection_type") == "usb":
                found.addItem(f"USB    {item.get('model', '')}    {item.get('serial_number', '')}")
            else:
                found.addItem(f"NETWORK    {item['ip']}    {item.get('model', '')}    {item.get('serial_number', '')}")
        found.selectAll()
        layout.addWidget(found)
        buttons = QDialogButtonBox(QDialogButtonBox.Cancel | QDialogButtonBox.Ok)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
        layout.addWidget(buttons)
        if dialog.exec() == QDialog.Accepted:
            existing_network = {p.get("snmp", {}).get("host") for p in self.profiles if p.get("connection_type", "network") == "network"}
            existing_usb = {p.get("usb", {}).get("serial_number") or p.get("usb", {}).get("device_id") for p in self.profiles if p.get("connection_type") == "usb"}
            for index in sorted({row.row() for row in found.selectedIndexes()}):
                item = printers[index]
                if item.get("connection_type") == "usb":
                    identity = item.get("serial_number") or item.get("device_id")
                    if identity not in existing_usb:
                        self.profiles.append(usb_profile(item, len(self.profiles)))
                        existing_usb.add(identity)
                else:
                    ip = item["ip"]
                    if ip not in existing_network:
                        self.profiles.append(self._profile(ip, len(self.profiles), item))
                        existing_network.add(ip)
            self.save_settings(silent=True)
            self._refresh_profile_list()
            self.refresh_dashboard()
        self.refresh_service()

    def _refresh_profile_list(self) -> None:
        if not hasattr(self, "profile_list"):
            return
        self.profile_list.clear()
        for index, profile in enumerate(self.profiles):
            is_usb = profile.get("connection_type") == "usb"
            target = profile.get("usb", {}).get("serial_number") or profile.get("usb", {}).get("port", "USB") if is_usb else profile.get("snmp", {}).get("host", "No IP")
            self.profile_list.addItem(f"Printer {index + 1} — {'USB · ' if is_usb else ''}{target}")
        if self.profiles:
            self.profile_list.setCurrentRow(0)

    def _load_selected_ip(self, index: int) -> None:
        if 0 <= index < len(self.profiles):
            profile = self.profiles[index]
            is_usb = profile.get("connection_type") == "usb"
            self.connection_label.setText("USB DEVICE" if is_usb else "PRINTER IP ADDRESS")
            self.ip_edit.setText(str(profile.get("usb", {}).get("serial_number") or profile.get("usb", {}).get("port") or "") if is_usb else str(profile.get("snmp", {}).get("host", "")))
            self.ip_edit.setReadOnly(is_usb)

    def save_settings(self, silent: bool = False) -> None:
        row = self.profile_list.currentRow() if hasattr(self, "profile_list") else -1
        if 0 <= row < len(self.profiles) and self.profiles[row].get("connection_type", "network") == "network" and self.ip_edit.text().strip():
            ip = self.ip_edit.text().strip()
            self.profiles[row]["snmp"]["host"] = ip
            self.profiles[row]["printer"]["base_url"] = f"http://{ip}"
        config = dict(self.config)
        config["printers"] = self.profiles
        save_api_secrets(config.get("api", {}))
        config["api"] = dict(PLACEHOLDER)
        CONFIG_PATH.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        self.config = load_config(CONFIG_PATH)
        if not silent:
            QMessageBox.information(self, "Saved", "Settings saved successfully.")
        self.refresh_dashboard()
        self._refresh_printers_page()

    def remove_selected(self) -> None:
        row = self.profile_list.currentRow()
        if row < 0 or len(self.profiles) <= 1:
            return
        self.profiles.pop(row)
        self.save_settings(silent=True)
        self._refresh_profile_list()

    def _runtime_config(self) -> dict[str, Any]:
        config = load_config(CONFIG_PATH)
        config["printers"] = self.profiles
        return config

    def test_all(self) -> None:
        self.service_badge.setText("●  Reading printers")
        self._work(lambda: collect_all_printers(self._runtime_config()), self._collection_done)

    def refresh_printer_data(self) -> None:
        """Refresh card identity and counters at startup without sending a report."""
        worker = Worker(lambda: collect_all_printers(self._runtime_config()))
        worker.signals.done.connect(self._collection_done)
        worker.signals.failed.connect(lambda _message: self.refresh_service())
        self.thread_pool.start(worker)

    def _collection_done(self, payload: dict[str, Any]) -> None:
        self.last_payload = payload
        self.activity_log.setStyleSheet("border:0; border-radius:0; padding:24px; background:#121b28; color:#a6b3c7; font-family:'Consolas';")
        self.activity_log.setAlignment(Qt.AlignLeft)
        self.activity_log.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
        if hasattr(self, "activity_preview"):
            count = sum(1 for item in payload.get("printers", []) if item.get("ok") is True)
            self.activity_preview.setText(f"Collection complete · {count} printer(s) responded")
        self.metrics["last"].setText(datetime.now().strftime("%I:%M %p").lstrip("0"))
        if hasattr(self, "activity_metrics"):
            self.activity_metrics["Last collection"].setText(datetime.now().strftime("%I:%M %p").lstrip("0"))
        self.refresh_dashboard()
        self.refresh_service()

    def _clear_activity_log(self) -> None:
        self.activity_log.setStyleSheet("border:0; border-radius:0; padding:185px 24px 24px 24px; background:#121b28; color:#a6b3c7;")
        self.activity_log.setPlainText("Collection and delivery activity will appear here.")
        self.activity_log.setAlignment(Qt.AlignCenter)

    def send_now(self) -> None:
        def action() -> tuple[dict[str, Any], dict[str, Any]]:
            config = self._runtime_config()
            payload = collect_all_printers(config)
            enqueue_payload(payload)
            return payload, process_queue(config, send_to_api)
        self._work(action, self._sent)

    def _sent(self, value: tuple[dict[str, Any], dict[str, Any]]) -> None:
        payload, result = value
        self._collection_done(payload)
        self.delivery_text.setText("Report safely queued" if result.get("pending") else "Last report sent successfully")

    def _work(self, action: Callable[[], Any], done: Callable[[Any], None]) -> None:
        worker = Worker(action)
        worker.signals.done.connect(done)
        worker.signals.failed.connect(lambda message: QMessageBox.critical(self, "Operation failed", message))
        self.thread_pool.start(worker)

    def check_for_updates(self, manual: bool = False) -> None:
        if self.update_check_running:
            return
        self.update_check_running = True
        worker = Worker(lambda: check_for_update(APP_VERSION, install=False))

        def completed(result: dict[str, Any]) -> None:
            self.update_check_running = False
            if not result.get("available"):
                if manual:
                    QMessageBox.information(self, "Software Update", f"Version {APP_VERSION} is the latest version.")
                return
            latest = str(result.get("latest_version") or "new")
            prompt = QMessageBox(self)
            prompt.setIcon(QMessageBox.Information)
            prompt.setWindowTitle("Update Available")
            prompt.setText(f"Printer Counter {latest} is available.")
            prompt.setInformativeText(
                f"Current version: {APP_VERSION}\n\nChoose how you want to install the verified update."
            )
            normal_button = prompt.addButton("Install normally", QMessageBox.AcceptRole)
            silent_button = prompt.addButton("Install silently", QMessageBox.ActionRole)
            prompt.addButton("Later", QMessageBox.RejectRole)
            prompt.setDefaultButton(normal_button)
            prompt.exec()
            if prompt.clickedButton() is normal_button:
                self._install_update(latest, silent=False)
            elif prompt.clickedButton() is silent_button:
                self._install_update(latest, silent=True)

        def failed(message: str) -> None:
            self.update_check_running = False
            if manual:
                QMessageBox.warning(self, "Update Check Failed", message)

        worker.signals.done.connect(completed)
        worker.signals.failed.connect(failed)
        self.thread_pool.start(worker)

    def _install_update(self, latest_version: str, *, silent: bool) -> None:
        self.update_check_running = True
        worker = Worker(lambda: check_for_update(APP_VERSION, install=True, silent=silent))

        def completed(result: dict[str, Any]) -> None:
            self.update_check_running = False
            if result.get("launched"):
                QMessageBox.information(
                    self,
                    "Update Ready",
                    f"Version {latest_version} was verified and the installer has started. The application will now close.",
                )
                QApplication.quit()

        def failed(message: str) -> None:
            self.update_check_running = False
            QMessageBox.critical(self, "Update Failed", message)

        worker.signals.done.connect(completed)
        worker.signals.failed.connect(failed)
        self.thread_pool.start(worker)

    def refresh_service(self) -> None:
        try:
            status = json.loads(STATUS_PATH.read_text(encoding="utf-8"))
            heartbeat = datetime.fromisoformat(str(status["heartbeat"]).replace("Z", "+00:00"))
            live = (datetime.now(heartbeat.tzinfo) - heartbeat).total_seconds() < 35
            pending = int(status.get("queue_pending", 0) or 0)
            self.metrics["queue"].setText(str(pending))
            if hasattr(self, "activity_metrics"):
                self.activity_metrics["Queued reports"].setText(str(pending))
                self.activity_metrics["Delivery state"].setText("Ready" if status.get("last_result", {}).get("ok") else "Waiting")
            self.service_badge.setText(f"●  {'Service running' if live else 'Service offline'}")
            self.service_badge.setStyleSheet(f"color:{COLORS['green'] if live else COLORS['red']}; font-weight:700;")
            self.fleet_service_badge.setText(f"●  {'Service running' if live else 'Service offline'}")
            self.fleet_service_badge.setStyleSheet(
                f"background:{'#16322b' if live else '#391f27'}; color:{COLORS['green'] if live else COLORS['red']}; border-radius:12px; padding:5px 9px; font-size:11px; font-weight:600;"
            )
            if status.get("last_result", {}).get("ok"):
                self.delivery_text.setText("Ready")
        except Exception:
            self.service_badge.setText("●  Service offline")
            self.service_badge.setStyleSheet(f"color:{COLORS['red']}; font-weight:700;")
            if hasattr(self, "fleet_service_badge"):
                self.fleet_service_badge.setText("●  Service offline")


def main() -> None:
    app = QApplication(sys.argv)
    app.setApplicationName("Printer Counter")
    icon = QIcon(str(RESOURCE_DIR / "assets" / "app-icon.png"))
    app.setWindowIcon(icon)
    try:
        window = PrinterCounterWindow()
    except Exception as exc:
        error = QMessageBox()
        error.setWindowTitle("Printer Counter could not start")
        error.setIcon(QMessageBox.Critical)
        error.setText("The application could not read its configuration.")
        error.setInformativeText(str(exc))
        error.setStyleSheet(
            f"QMessageBox{{background:{COLORS['panel']};}}"
            f"QLabel{{color:{COLORS['text']};font-size:13px;}}"
            f"QPushButton{{color:{COLORS['text']};background:#182333;padding:8px 14px;}}"
        )
        error.exec()
        raise SystemExit(1)
    window.showMaximized()
    window.show_page("dashboard")
    raise SystemExit(app.exec())


if __name__ == "__main__":
    main()
