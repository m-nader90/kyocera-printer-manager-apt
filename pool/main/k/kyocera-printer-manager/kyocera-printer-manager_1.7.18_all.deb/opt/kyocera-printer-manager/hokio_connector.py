"""Supervised Hokio relay connector with strict local forwarding policy."""

from __future__ import annotations

import asyncio
import base64
import json
import hashlib
import logging
import random
import re
import threading
from typing import Any, Callable, Iterable
from urllib.parse import unquote, urlsplit

import aiohttp

from tls_support import create_verified_ssl_context


HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailer", "transfer-encoding", "upgrade",
}
MAX_REQUEST_BODY = 10 * 1024 * 1024
REQUEST_ID = re.compile(r"^[A-Za-z0-9._:-]{1,64}$")


def connection_error_label(error: BaseException) -> str:
    """Return diagnostics that cannot disclose relay hosts or credentials."""
    details = [type(error).__name__]
    status = getattr(error, "status", None)
    if isinstance(status, int):
        details.append(f"HTTP {status}")
    os_error = getattr(error, "os_error", None)
    error_number = getattr(os_error, "errno", None) or getattr(error, "errno", None)
    if isinstance(error_number, int):
        details.append(f"errno {error_number}")
    return ", ".join(details)


def request_id(value: Any) -> str:
    candidate = str(value or "")
    return candidate if REQUEST_ID.fullmatch(candidate) else ""


def filtered_headers(headers: Iterable[tuple[str, str]]) -> list[list[str]]:
    result = []
    for name, value in headers:
        if (
            not 1 <= len(name) <= 256
            or len(value) > 8192
            or name.lower() in HOP_BY_HOP
            or "\r" in name
            or "\n" in name
            or "\r" in value
            or "\n" in value
        ):
            continue
        result.append([name, value])
        if len(result) >= 100:
            break
    return result


def request_is_allowed(config: dict[str, Any], method: str, path: str) -> bool:
    if len(method) > 16 or not 1 <= len(path) <= 2048:
        return False
    if method.upper() not in config["allowed_methods"]:
        return False
    target = urlsplit(path)
    if target.scheme or target.netloc or not target.path.startswith("/") or target.path.startswith("//"):
        return False
    request_path = target.path
    for _ in range(3):
        decoded = unquote(request_path)
        if decoded == request_path:
            break
        request_path = decoded
    if any(ord(character) < 32 for character in request_path) or "\\" in request_path:
        return False
    if any(segment in {".", ".."} for segment in request_path.split("/")):
        return False
    return any(
        request_path.startswith(allowed[:-1]) if allowed.endswith("/*") else request_path == allowed
        for allowed in config["allowed_paths"]
    )


class HokioRelayConnector:
    def __init__(
        self,
        config: dict[str, Any],
        *,
        stop_event: threading.Event | None = None,
        status_callback: Callable[[str, str], None] | None = None,
    ):
        self.config = config
        self.stop_event = stop_event or threading.Event()
        self.status_callback = status_callback or (lambda _state, _code: None)
        self._send_lock: asyncio.Lock | None = None
        self._tasks: set[asyncio.Task[None]] = set()

    def run_forever(self) -> None:
        asyncio.run(self.run())

    async def run(self) -> None:
        delay = 2.0
        while not self.stop_event.is_set():
            try:
                await self.connect_once()
                delay = 2.0
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logging.warning(
                    "Hokio relay connection failed (%s)",
                    connection_error_label(exc),
                )
                self.status_callback("degraded", "CONNECTOR_DISCONNECTED")
            if self.stop_event.is_set():
                break
            await asyncio.sleep(delay + random.random())
            delay = min(delay * 2, 60.0)
        self.status_callback("stopped", "")

    async def connect_once(self) -> None:
        self._send_lock = asyncio.Lock()
        timeout = aiohttp.ClientTimeout(total=None, sock_connect=20.0, sock_read=None)
        headers = {
            "X-Relay-Device": self.config["device_id"],
            "X-Relay-Token": self.config["token"],
        }
        self.status_callback("connecting", "")
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.ws_connect(
                self.config["relay_url"],
                headers=headers,
                heartbeat=30,
                max_msg_size=12 * 1024 * 1024,
                ssl=create_verified_ssl_context(),
            ) as websocket:
                self.status_callback("online", "")
                while not self.stop_event.is_set():
                    try:
                        message = await asyncio.wait_for(websocket.receive(), timeout=1.0)
                    except asyncio.TimeoutError:
                        continue
                    if message.type == aiohttp.WSMsgType.TEXT:
                        try:
                            payload = json.loads(message.data)
                        except json.JSONDecodeError:
                            continue
                        if isinstance(payload, dict) and payload.get("type") == "request":
                            relay_request_id = request_id(payload.get("id"))
                            if len(self._tasks) >= int(self.config["max_concurrency"]):
                                await self._send_error(
                                    websocket,
                                    relay_request_id or "invalid",
                                    503,
                                    b"local relay is busy",
                                )
                                continue
                            task = asyncio.create_task(self._handle_request(session, websocket, payload))
                            self._tasks.add(task)
                            task.add_done_callback(self._tasks.discard)
                    elif message.type in {aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSE}:
                        break
        if self._tasks:
            tasks = tuple(self._tasks)
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            self._tasks.clear()

    async def _handle_request(self, session, websocket, payload: dict[str, Any]) -> None:
        relay_request_id = request_id(payload.get("id"))
        try:
            method = str(payload.get("method", "GET")).upper()
            path = str(payload.get("path", "/"))
            if not relay_request_id or not request_is_allowed(self.config, method, path):
                await self._send_error(
                    websocket,
                    relay_request_id or "invalid",
                    403,
                    b"relay route not allowed",
                )
                return
            encoded = payload.get("body", "")
            body = base64.b64decode(encoded, validate=True)
            if len(body) > MAX_REQUEST_BODY:
                raise ValueError("request body too large")
            raw_headers = payload.get("headers", [])
            if not isinstance(raw_headers, list) or len(raw_headers) > 100:
                raise ValueError("invalid request headers")
            pairs = []
            for pair in raw_headers:
                if not isinstance(pair, list) or len(pair) != 2:
                    raise ValueError("invalid request header")
                pairs.append((str(pair[0]), str(pair[1])))
            headers = [(a, b) for a, b in filtered_headers(pairs) if a.lower() != "host"]
            async with session.request(
                method,
                f"http://127.0.0.1:{self.config['local_port']}{path}",
                headers=headers,
                data=body,
                allow_redirects=False,
                timeout=aiohttp.ClientTimeout(total=float(self.config["local_timeout"])),
            ) as response:
                response_body = bytearray()
                async for chunk in response.content.iter_chunked(64 * 1024):
                    response_body.extend(chunk)
                    if len(response_body) > int(self.config["max_response_body"]):
                        raise ValueError("local response exceeds configured limit")
                result = {
                    "type": "response", "id": relay_request_id, "status": response.status,
                    "headers": filtered_headers(response.headers.items()),
                    "body": base64.b64encode(bytes(response_body)).decode("ascii"),
                }
        except Exception:
            logging.warning("Hokio local relay request failed id=%s", relay_request_id or "invalid")
            result = {
                "type": "response", "id": relay_request_id or "invalid", "status": 502,
                "headers": [["Content-Type", "text/plain; charset=utf-8"]],
                "body": base64.b64encode(b"local service unavailable").decode("ascii"),
            }
        async with self._send_lock:
            await websocket.send_json(result)

    async def _send_error(self, websocket, request_id: str, status: int, message: bytes) -> None:
        async with self._send_lock:
            await websocket.send_json({
                "type": "response", "id": request_id, "status": status,
                "headers": [["Content-Type", "text/plain; charset=utf-8"]],
                "body": base64.b64encode(message).decode("ascii"),
            })


class HokioConnectorSupervisor:
    def __init__(self):
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._signature: str | None = None
        self._generation = 0

    def start(self, config: dict[str, Any], status_callback: Callable[[str, str], None]) -> None:
        signature_data = {key: value for key, value in config.items() if key != "token"}
        signature_data["token_hash"] = hashlib.sha256(str(config["token"]).encode("utf-8")).hexdigest()
        signature = json.dumps(signature_data, sort_keys=True)
        if self._thread and self._thread.is_alive() and self._signature == signature:
            return
        self.stop()
        self._stop = threading.Event()
        self._generation += 1
        generation = self._generation
        connector = HokioRelayConnector(config, stop_event=self._stop, status_callback=status_callback)
        connector.status_callback = lambda state, code: self._publish_status(
            generation, status_callback, state, code
        )
        self._signature = signature
        self._thread = threading.Thread(target=connector.run_forever, name="hokio-relay-connector", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        # Invalidate callbacks before waiting. A WebSocket thread may take
        # longer than the bounded join to exit; its eventual "stopped" event
        # must not overwrite the replacement connector's live state.
        self._generation += 1
        thread = self._thread
        self._stop.set()
        if thread and thread.is_alive():
            thread.join(timeout=3)
        self._thread = None
        self._signature = None

    def _publish_status(
        self,
        generation: int,
        callback: Callable[[str, str], None],
        state: str,
        code: str,
    ) -> None:
        if generation == self._generation:
            callback(state, code)
