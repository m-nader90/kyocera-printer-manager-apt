#!/usr/bin/env python3
"""Durable disk queue for printer API deliveries."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app_paths import QUEUE_DIR, ensure_data_dir
from typing import Any, Callable


DEFAULT_QUEUE_DIR = QUEUE_DIR
RETRY_DELAYS_SECONDS = (60, 300, 900)


def _printer_identity(printer: dict[str, Any]) -> set[str]:
    values = {
        printer.get("id"), printer.get("serial_number"),
        printer.get("printer", {}).get("serial_number") if isinstance(printer.get("printer"), dict) else None,
        printer.get("discovery", {}).get("serial_number") if isinstance(printer.get("discovery"), dict) else None,
        printer.get("usb", {}).get("serial_number") if isinstance(printer.get("usb"), dict) else None,
    }
    return {"".join(str(value).split()).casefold() for value in values if value}


def filter_disabled_printers(config: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    """Prevent disabled printers from leaving disk, including previously queued reports."""
    disabled: set[str] = set()
    for profile in config.get("printers", []):
        if isinstance(profile, dict) and not bool(profile.get("enabled", True)):
            disabled.update(_printer_identity(profile))
    if not disabled or not isinstance(payload.get("printers"), list):
        return payload
    filtered = dict(payload)
    filtered["printers"] = [
        printer for printer in payload["printers"]
        if not isinstance(printer, dict) or _printer_identity(printer).isdisjoint(disabled)
    ]
    summary = filtered.get("summary")
    if isinstance(summary, dict):
        removed = len(payload["printers"]) - len(filtered["printers"])
        filtered["summary"] = {**summary, "disabled": int(summary.get("disabled", 0)) + removed}
    return filtered


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _write_atomic(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def enqueue_payload(payload: dict[str, Any], queue_dir: Path = DEFAULT_QUEUE_DIR) -> Path:
    ensure_data_dir()
    created = utc_now()
    item = {
        "queue_version": 1,
        "idempotency_key": str(uuid.uuid4()),
        "created_at": created.isoformat(),
        "attempts": 0,
        "next_attempt_at": created.isoformat(),
        "last_error": None,
        "payload": payload,
    }
    filename = f"{created:%Y%m%dT%H%M%S%fZ}-{uuid.uuid4().hex}.json"
    path = queue_dir / filename
    _write_atomic(path, item)
    return path


def queue_count(queue_dir: Path = DEFAULT_QUEUE_DIR) -> int:
    if not queue_dir.exists():
        return 0
    return sum(1 for path in queue_dir.glob("*.json") if path.is_file())


def process_queue(
    config: dict[str, Any],
    sender: Callable[..., tuple[int, str]],
    queue_dir: Path = DEFAULT_QUEUE_DIR,
    *,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = now or utc_now()
    sent = 0
    failed = 0
    last_status: int | None = None
    last_response = ""
    last_error = ""
    authentication_failed = False
    registration_missing = False
    credential_recovery_required = False

    if not queue_dir.exists():
        return {"sent": 0, "failed": 0, "pending": 0}

    for path in sorted(queue_dir.glob("*.json")):
        try:
            item = json.loads(path.read_text(encoding="utf-8"))
            due = datetime.fromisoformat(str(item.get("next_attempt_at", item["created_at"])).replace("Z", "+00:00"))
            if due > current:
                continue
            idempotency_key = str(item.get("idempotency_key") or path.stem)
            # Keep the same key for every retry so the API can safely deduplicate it.
            if not item.get("idempotency_key"):
                item["idempotency_key"] = idempotency_key
                _write_atomic(path, item)
            payload = filter_disabled_printers(config, item["payload"])
            if not payload.get("printers"):
                path.unlink()
                continue
            status, body = sender(config, payload, idempotency_key)
            last_status = status
            last_response = body[:500]
            path.unlink()
            sent += 1
        except Exception as exc:
            failed += 1
            last_error = str(exc)
            exception_name = exc.__class__.__name__
            authentication_failed = authentication_failed or exception_name in {
                "DeviceAuthenticationError", "DeviceCredentialRecoveryRequiredError", "DeviceNotRegisteredError",
            }
            registration_missing = registration_missing or exception_name == "DeviceNotRegisteredError"
            credential_recovery_required = credential_recovery_required or exception_name in {
                "DeviceCredentialRecoveryRequiredError", "DeviceNotRegisteredError",
            }
            try:
                attempts = int(item.get("attempts", 0)) + 1
                delay = RETRY_DELAYS_SECONDS[min(attempts - 1, len(RETRY_DELAYS_SECONDS) - 1)]
                item.update({
                    "attempts": attempts,
                    "last_error": last_error,
                    "last_attempt_at": current.isoformat(),
                    "next_attempt_at": (current + timedelta(seconds=delay)).isoformat(),
                })
                _write_atomic(path, item)
            except Exception:
                # Leave an unreadable item untouched for manual inspection rather than deleting data.
                pass

    result: dict[str, Any] = {
        "sent": sent,
        "failed": failed,
        "pending": queue_count(queue_dir),
        "authentication_failed": authentication_failed,
        "registration_missing": registration_missing,
        "credential_recovery_required": credential_recovery_required,
    }
    if last_status is not None:
        result.update({"http_status": last_status, "api_response": last_response})
    if last_error:
        result["last_error"] = last_error
    return result
