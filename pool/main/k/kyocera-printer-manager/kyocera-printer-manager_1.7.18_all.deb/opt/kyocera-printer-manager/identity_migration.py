"""One-time migration of identity and settings from legacy installations."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Iterable


IDENTITY_FIELDS = ("device_id", "installation_id", "access_token", "bearer_token", "activated")


def legacy_config_candidates(current_path: Path) -> list[Path]:
    candidates: list[Path] = []
    if sys.platform == "win32":
        for variable in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
            root = os.environ.get(variable)
            if root:
                candidates.extend([
                    Path(root) / "Kyocera Printer Manager" / "config.json",
                    Path(root) / "Kyocera Printer Manager Legacy" / "config.json",
                ])
    elif sys.platform.startswith("linux"):
        candidates.extend([
            Path("/opt/kyocera-printer-manager/config.json"),
            Path("/etc/kyocera-printer-manager/config.json"),
            Path("/var/lib/kyocera-counter/config.json"),
        ])
    candidates.append(Path(sys.executable).resolve().parent / "config.json")
    unique: list[Path] = []
    for candidate in candidates:
        if candidate != current_path and candidate not in unique:
            unique.append(candidate)
    return unique


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        return value if isinstance(value, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def _has_identity(api: Any) -> bool:
    return isinstance(api, dict) and bool(api.get("device_id") and (api.get("access_token") or api.get("bearer_token")))


def migrate_legacy_identity(current_path: Path, candidates: Iterable[Path] | None = None) -> Path | None:
    """Merge a readable legacy identity without overwriting a valid current one."""
    current = _read_json(current_path)
    if current is None or _has_identity(current.get("api")) or current.get("api", {}).get("protected"):
        return None

    for candidate in candidates or legacy_config_candidates(current_path):
        legacy = _read_json(candidate)
        legacy_api = legacy.get("api") if legacy else None
        if not _has_identity(legacy_api):
            continue

        merged_api = dict(current.get("api") or {})
        for key, value in legacy_api.items():
            if key in IDENTITY_FIELDS or key.endswith("_endpoint") or key in {"endpoint", "auth_type", "verify_tls", "timeout_seconds"}:
                if value not in (None, ""):
                    merged_api[key] = value
        current["api"] = merged_api
        if not current.get("printers") and legacy.get("printers"):
            current["printers"] = legacy["printers"]
        temporary = current_path.with_suffix(".identity-migration.tmp")
        temporary.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, current_path)
        return candidate
    return None
