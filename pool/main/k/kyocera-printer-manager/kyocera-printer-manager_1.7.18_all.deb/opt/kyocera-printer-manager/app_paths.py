"""Runtime paths shared by source, packaged GUI, and Windows service."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path


APP_NAME = "Kyocera Printer Manager"
SOURCE_DIR = Path(__file__).resolve().parent
INSTALL_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else SOURCE_DIR
RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", SOURCE_DIR)) if getattr(sys, "frozen", False) else SOURCE_DIR
STORE_MSIX_MARKER = INSTALL_DIR / "msix-store.marker"
STORE_MSIX_BUILD = bool(getattr(sys, "frozen", False)) and STORE_MSIX_MARKER.exists()

if sys.platform == "win32" and getattr(sys, "frozen", False):
    DATA_DIR = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / APP_NAME
elif sys.platform.startswith("linux") and str(SOURCE_DIR).startswith("/opt/kyocera-printer-manager"):
    DATA_DIR = Path("/var/lib/kyocera-printer-manager")
else:
    DATA_DIR = SOURCE_DIR

CONFIG_PATH = DATA_DIR / "config.json"
SECRETS_PATH = DATA_DIR / "api-secrets.dat"
SECRET_KEY_PATH = DATA_DIR / "api-secrets.key"
STATUS_PATH = DATA_DIR / "service-status.json"
UPDATE_HEALTH_PATH = DATA_DIR / "update-health.json"
LOG_PATH = DATA_DIR / "printer-service.log"
QUEUE_DIR = DATA_DIR / "delivery-queue"
CONTROL_STATE_PATH = DATA_DIR / "remote-control-state.json"
CONTROL_SYNC_REQUEST_PATH = DATA_DIR / "remote-control-sync.request"
CONFIG_BACKUP_PATH = DATA_DIR / "config.last-known-good.json"
HOKIO_SECRET_PATH = DATA_DIR / "hokio-connector-secrets.dat"
HOKIO_SECRET_KEY_PATH = DATA_DIR / "hokio-connector-secrets.key"
HOKIO_STATE_PATH = DATA_DIR / "hokio-connector-state.json"
HOKIO_REPLAY_PATH = DATA_DIR / "hokio-wake-replay.json"


def ensure_data_dir() -> Path:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if STORE_MSIX_BUILD and not CONFIG_PATH.exists():
        template = INSTALL_DIR / "config.default.json"
        if template.is_file():
            try:
                with template.open("rb") as source, CONFIG_PATH.open("xb") as destination:
                    shutil.copyfileobj(source, destination)
            except FileExistsError:
                # The GUI and packaged service may initialize concurrently.
                pass
    return DATA_DIR


def ensure_store_msix_data_acl() -> None:
    """Allow the packaged GUI and LocalSystem service to share ProgramData state."""
    if not STORE_MSIX_BUILD or sys.platform != "win32":
        return
    ensure_data_dir()
    subprocess.run(
        [
            "icacls.exe",
            str(DATA_DIR),
            "/inheritance:r",
            "/grant:r",
            "*S-1-5-18:(OI)(CI)F",
            "*S-1-5-32-544:(OI)(CI)F",
            "*S-1-5-32-545:(OI)(CI)M",
            "/T",
            "/C",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
