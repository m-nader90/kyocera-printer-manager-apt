#!/usr/bin/env python3
"""Secure, durable synchronization with the API remote-control plane."""

from __future__ import annotations

import json
import ipaddress
import os
import random
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request

from app_paths import CONFIG_BACKUP_PATH, CONTROL_STATE_PATH
from printer_forwarder import (
    DeviceCredentialRecoveryRequiredError,
    DeviceNotRegisteredError,
    hardware_identity,
    make_opener,
)


class RemoteControlError(RuntimeError):
    pass


ALLOWED_COMMANDS = {
    "send_now", "scan_now", "test_printer", "restart_service", "check_update", "install_update",
    "sync_configuration",
}
TIME_PATTERN = re.compile(r"^(?:[01]\d|2[0-3]):[0-5]\d$")
TIMEZONE_PATTERN = re.compile(r"^(?:local|UTC|[+-](?:[01]\d|2[0-3]):[0-5]\d)$", re.IGNORECASE)
HOKIO_PENDING_STATES = {"pending", "provisioning", "processing", "retry_wait"}
HOKIO_ACTIVATION_RETRY_SECONDS = 15
MAX_CONTROL_FALLBACK_MINUTES = 15


@dataclass(frozen=True)
class HokioPendingState:
    state: str
    retry_after_seconds: int


def summarize_control_error(message: Any) -> str:
    """Return a short user-safe message without server paths or stack traces."""
    text = str(message or "").strip()
    if not text:
        return ""
    if "HTTP 404" in text or "control-sync could not be found" in text:
        return "Central control is not enabled on the API server yet (HTTP 404). Local settings remain active."
    if "HTTP 401" in text:
        return "The API rejected this device's credentials (HTTP 401)."
    if "HTTP 403" in text:
        return "This device is not allowed to use central control (HTTP 403)."
    if "HTTP 422" in text:
        return "The API rejected the synchronization data (HTTP 422)."
    if "HTTP 5" in text:
        return "The central control API is temporarily unavailable. Local settings remain active."
    if "Cannot connect to the control API" in text:
        return "Cannot reach the central control API. Local settings remain active."
    return text.splitlines()[0][:240]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _is_expired(value: Any) -> bool:
    if not value:
        return False
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed <= datetime.now(timezone.utc)
    except ValueError:
        return True


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def load_control_state(path: Path = CONTROL_STATE_PATH) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        return value if isinstance(value, dict) else {}
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return {}


def _endpoint(api: dict[str, Any], suffix: str) -> str:
    explicit = str(api.get("control_endpoint", "")).strip()
    if explicit:
        base = explicit.rstrip("/")
        return base if suffix == "control-sync" else f"{base.rsplit('/', 1)[0]}/{suffix}"
    meter = str(api.get("endpoint", "")).strip()
    parts = urlsplit(meter)
    return urlunsplit((parts.scheme, parts.netloc, f"/api/v1/device/{suffix}", "", ""))


def _headers(api: dict[str, Any]) -> dict[str, str]:
    token = str(api.get("access_token", "")).strip()
    device_id = str(api.get("device_id", "")).strip()
    if not token or not device_id:
        raise RemoteControlError("This computer has not been activated for remote control.")
    return {
        "Accept": "application/json", "Content-Type": "application/json",
        "Authorization": f"Bearer {token}", "X-Device-ID": device_id,
        "User-Agent": "KyoceraPrinterManager-Control/1.0",
    }


def _post(api: dict[str, Any], url: str, payload: dict[str, Any]) -> dict[str, Any]:
    if urlsplit(url).scheme != "https" and urlsplit(url).hostname not in {"localhost", "127.0.0.1"}:
        raise RemoteControlError("Remote control requires HTTPS outside local development.")
    request = Request(url, data=json.dumps(payload).encode("utf-8"), headers=_headers(api), method="POST")
    try:
        with make_opener(bool(api.get("verify_tls", True))).open(request, timeout=int(api.get("timeout_seconds", 20))) as response:
            body = response.read().decode("utf-8")
        value = json.loads(body or "{}")
        if not isinstance(value, dict):
            raise RemoteControlError("The control API returned an invalid response.")
        return value
    except HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        try:
            value = json.loads(body)
            detail = str(value.get("message", "")) if isinstance(value, dict) else ""
            error_code = str(value.get("code", "")) if isinstance(value, dict) else ""
        except json.JSONDecodeError:
            detail = ""
            error_code = ""
        if exc.code == 401 and error_code == "DEVICE_NOT_REGISTERED":
            raise DeviceNotRegisteredError("The device was deleted from central control and will be registered again.") from exc
        if exc.code == 401 and error_code == "DEVICE_CREDENTIAL_INVALID":
            raise DeviceCredentialRecoveryRequiredError(
                "The saved device credential is no longer valid and will be recovered automatically."
            ) from exc
        message = f"Control API returned HTTP {exc.code}"
        if detail:
            message += f": {detail[:240]}"
        raise RemoteControlError(summarize_control_error(message)) from exc
    except (URLError, OSError) as exc:
        raise RemoteControlError(f"Cannot connect to the control API: {getattr(exc, 'reason', exc)}") from exc
    except json.JSONDecodeError as exc:
        raise RemoteControlError("The control API returned invalid JSON.") from exc


def printer_inventory(config: dict[str, Any]) -> list[dict[str, Any]]:
    inventory: list[dict[str, Any]] = []
    for profile in config.get("printers", []):
        if not isinstance(profile, dict):
            continue
        connection = str(profile.get("connection_type", "network")).lower()
        serial = str(
            profile.get("usb", {}).get("serial_number")
            if connection == "usb"
            else profile.get("discovery", {}).get("serial_number") or profile.get("printer", {}).get("serial_number")
            or ""
        ).strip()
        if not serial:
            continue
        inventory.append({
            "serial_number": serial,
            "connection_type": connection,
            "model": str(profile.get("name") or profile.get("discovery", {}).get("model") or ""),
            "metadata": {"profile_id": str(profile.get("id") or ""), "enabled": bool(profile.get("enabled", True))},
        })
    return inventory


def hokio_pending_state(response: dict[str, Any]) -> HokioPendingState | None:
    """Return bounded pending state only from an authenticated control response."""
    extensions = response.get("extensions")
    extension = extensions.get("hokio") if isinstance(extensions, dict) else None
    if not isinstance(extension, dict) or extension.get("binding_id"):
        return None
    if str(extension.get("state", "")) not in HOKIO_PENDING_STATES:
        return None
    value = extension.get("retry_after_seconds", 15)
    if isinstance(value, bool):
        return None
    try:
        seconds = int(value)
    except (TypeError, ValueError):
        return None
    return HokioPendingState(
        state=str(extension["state"]),
        retry_after_seconds=max(5, min(300, seconds)),
    )


def hokio_retry_delay_seconds(response: dict[str, Any]) -> int | None:
    pending = hokio_pending_state(response)
    return pending.retry_after_seconds if pending else None


def hokio_activation_delay_seconds(
    response: dict[str, Any],
    runtime_status: dict[str, Any] | None,
) -> int | None:
    """Keep polling quickly until this installation owns a usable webhook URL."""
    if (
        isinstance(runtime_status, dict)
        and runtime_status.get("state") == "online"
        and str(runtime_status.get("webhook_url") or "").strip()
    ):
        return None
    pending = hokio_pending_state(response)
    if pending:
        return min(HOKIO_ACTIVATION_RETRY_SECONDS, pending.retry_after_seconds)
    return HOKIO_ACTIVATION_RETRY_SECONDS


def validate_settings(settings: Any) -> dict[str, Any]:
    if not isinstance(settings, dict):
        raise RemoteControlError("Remote configuration must be an object.")
    allowed = {"schedule", "discovery", "remote_control", "printers"}
    unknown = set(settings) - allowed
    if unknown:
        raise RemoteControlError(f"Remote configuration contains unsupported fields: {', '.join(sorted(unknown))}")

    schedule = settings.get("schedule", {})
    if schedule:
        if not isinstance(schedule, dict) or str(schedule.get("mode", "interval")) not in {"interval", "daily", "twice_daily"}:
            raise RemoteControlError("Remote schedule is invalid.")
        for value in schedule.get("daily_times", []):
            if not TIME_PATTERN.match(str(value)):
                raise RemoteControlError("Remote schedule contains an invalid daily time.")
        if "daily_time" in schedule and not TIME_PATTERN.match(str(schedule["daily_time"])):
            raise RemoteControlError("Remote schedule contains an invalid daily time.")
        if "timezone" in schedule and not TIMEZONE_PATTERN.match(str(schedule["timezone"])):
            raise RemoteControlError("Schedule timezone must be local, UTC, or an offset such as +03:00.")

    discovery = settings.get("discovery", {})
    if discovery and (not isinstance(discovery, dict) or not 5 <= int(discovery.get("interval_minutes", 30)) <= 1440):
        raise RemoteControlError("Discovery interval must be between 5 and 1440 minutes.")

    remote = settings.get("remote_control", {})
    if remote and (not isinstance(remote, dict) or not 15 <= int(remote.get("sync_interval_minutes", 60)) <= 1440):
        raise RemoteControlError("Control synchronization interval must be between 15 and 1440 minutes.")

    printers = settings.get("printers", {})
    if printers == []:
        printers = {}
        settings["printers"] = {}
    if printers and not isinstance(printers, dict):
        raise RemoteControlError("Printer overrides must be an object keyed by serial number or profile ID.")
    for key, value in printers.items():
        if not isinstance(value, dict) or set(value) - {"enabled", "ip_address", "name"}:
            raise RemoteControlError(f"Printer override {key} is invalid.")
        if "enabled" in value and not isinstance(value["enabled"], bool):
            raise RemoteControlError(f"Printer override {key} has an invalid enabled value.")
        if "ip_address" in value:
            try:
                ipaddress.ip_address(str(value["ip_address"]))
            except ValueError as exc:
                raise RemoteControlError(f"Printer override {key} has an invalid IP address.") from exc
    return settings


def _merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = value
    return result


def _normalized_printer_key(value: Any) -> str:
    """Normalize API/local printer identifiers without changing stored identity."""
    return re.sub(r"\s+", "", str(value or "")).casefold()


def apply_configuration(config_path: Path, settings: dict[str, Any]) -> None:
    validated = validate_settings(settings)
    raw = json.loads(config_path.read_text(encoding="utf-8-sig"))
    if not isinstance(raw, dict):
        raise RemoteControlError("Local configuration is invalid.")
    backup_path = config_path.with_name(CONFIG_BACKUP_PATH.name)
    backup_path.write_text(json.dumps(raw, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for section in ("schedule", "discovery", "remote_control"):
        if section in validated:
            raw[section] = _merge(raw.get(section, {}), validated[section])
    overrides = validated.get("printers", {})
    normalized_overrides = {
        _normalized_printer_key(key): value
        for key, value in overrides.items()
        if _normalized_printer_key(key)
    }
    for profile in raw.get("printers", []):
        if not isinstance(profile, dict):
            continue
        serial = str(profile.get("usb", {}).get("serial_number") or profile.get("discovery", {}).get("serial_number") or profile.get("printer", {}).get("serial_number") or "").strip()
        profile_id = str(profile.get("id") or "")
        override = (
            overrides.get(serial)
            or overrides.get(profile_id)
            or normalized_overrides.get(_normalized_printer_key(serial))
            or normalized_overrides.get(_normalized_printer_key(profile_id))
        )
        if override:
            if "enabled" in override:
                profile["enabled"] = override["enabled"]
            if "name" in override:
                profile["name"] = str(override["name"])[:255]
            if "ip_address" in override and profile.get("connection_type", "network") == "network":
                ip = str(override["ip_address"])
                profile.setdefault("snmp", {})["host"] = ip
                profile.setdefault("printer", {})["base_url"] = f"http://{ip}"
    _atomic_json(config_path, raw)


class RemoteControlClient:
    def __init__(self, config_path: Path, state_path: Path = CONTROL_STATE_PATH):
        self.config_path = config_path
        self.state_path = state_path

    def sync(
        self,
        config: dict[str, Any],
        *,
        app_version: str,
        service_status: dict[str, Any],
        handlers: dict[str, Callable[[dict[str, Any]], dict[str, Any]]],
        capabilities: tuple[str, ...] = (),
        hokio_extension_handler: Callable[[dict[str, Any]], dict[str, Any] | None] | None = None,
    ) -> dict[str, Any]:
        state = load_control_state(self.state_path)
        self._flush_configuration_ack(config["api"], state)
        payload = {
            "local_revision": int(state.get("revision", 0)),
            "app_version": app_version,
            "platform": "windows" if sys.platform == "win32" else "linux",
            "hardware_id": hardware_identity(),
            "service_status": service_status,
            "local_configuration": {key: config.get(key) for key in ("schedule", "discovery", "remote_control")},
            "printers": printer_inventory(config),
        }
        if capabilities:
            payload["capabilities"] = list(capabilities)
        response = _post(config["api"], _endpoint(config["api"], "control-sync"), payload)
        extension = response.get("extensions", {}).get("hokio") if isinstance(response.get("extensions"), dict) else None
        if isinstance(extension, dict) and extension.get("binding_id") and hokio_extension_handler is not None:
            acknowledgement = hokio_extension_handler(extension)
            if acknowledgement:
                _post(config["api"], _endpoint(config["api"], "hokio-credential-ack"), acknowledgement)
        state["managed"] = bool(response.get("managed", False))
        state["assignment_status"] = str(response.get("assignment_status", "unassigned"))
        state["last_sync_at"] = _now_iso()
        state["last_error"] = ""
        configuration = response.get("configuration")
        if isinstance(configuration, dict):
            revision = int(configuration.get("revision", 0))
            try:
                apply_configuration(self.config_path, configuration.get("settings", {}))
                state["revision"] = revision
                state["sources"] = configuration.get("sources", [])
                state["pending_configuration_ack"] = {"revision": revision, "status": "applied", "error": ""}
                _atomic_json(self.state_path, state)
                self._flush_configuration_ack(config["api"], state)
            except Exception as exc:
                state["last_error"] = str(exc)
                state["pending_configuration_ack"] = {"revision": revision, "status": "rejected", "error": str(exc)}
                _atomic_json(self.state_path, state)
                self._flush_configuration_ack(config["api"], state)
                raise

        executed = list(state.get("executed_commands", []))[-4999:]
        restart_requested = False
        for command in response.get("commands", []):
            command_id = str(command.get("command_id", ""))
            command_type = str(command.get("type", ""))
            if not command_id or command_id in executed:
                continue
            if _is_expired(command.get("expires_at")):
                result = {"ok": False, "error": "Command expired before execution."}
                status = "failed"
            elif command_type not in ALLOWED_COMMANDS or command_type not in handlers:
                result = {"ok": False, "error": "Unsupported command."}
                status = "failed"
            else:
                try:
                    result = handlers[command_type](command.get("payload") or {})
                    status = "succeeded" if result.get("ok", True) else "failed"
                except Exception as exc:
                    result, status = {"ok": False, "error": str(exc)}, "failed"
            state.setdefault("pending_results", []).append({"command_id": command_id, "status": status, "result": result})
            executed.append(command_id)
            state["executed_commands"] = executed[-5000:]
            _atomic_json(self.state_path, state)
            if command_type == "restart_service" and status == "succeeded":
                restart_requested = True

        self._flush_results(config["api"], state)
        _atomic_json(self.state_path, state)
        return {**response, "restart_requested": restart_requested}

    def flush_pending_results(self, config: dict[str, Any]) -> int:
        """Retry terminal command results without waiting for the next full sync."""
        state = load_control_state(self.state_path)
        if not state.get("pending_results"):
            return 0
        self._flush_results(config["api"], state)
        _atomic_json(self.state_path, state)
        return len(state.get("pending_results", []))

    def record_error(self, message: str) -> None:
        state = load_control_state(self.state_path)
        state.update({"last_error": message, "last_attempt_at": _now_iso()})
        _atomic_json(self.state_path, state)

    def _report_configuration(self, api: dict[str, Any], revision: int, status: str, error: str) -> None:
        _post(api, _endpoint(api, "configuration-ack"), {"revision": revision, "status": status, "error": error or None})

    def _flush_configuration_ack(self, api: dict[str, Any], state: dict[str, Any]) -> None:
        pending = state.get("pending_configuration_ack")
        if not isinstance(pending, dict):
            return
        try:
            self._report_configuration(api, int(pending["revision"]), str(pending["status"]), str(pending.get("error") or ""))
        except RemoteControlError as exc:
            if "HTTP 409" not in str(exc):
                raise
        state.pop("pending_configuration_ack", None)
        _atomic_json(self.state_path, state)

    def _flush_results(self, api: dict[str, Any], state: dict[str, Any]) -> None:
        remaining = []
        for item in state.get("pending_results", []):
            try:
                _post(api, _endpoint(api, f"commands/{item['command_id']}/result"), {"status": item["status"], "result": item["result"]})
            except RemoteControlError:
                remaining.append(item)
        state["pending_results"] = remaining


def next_sync_delay_seconds(config: dict[str, Any], *, jitter: bool = True) -> int:
    configured_minutes = max(15, min(1440, int(config.get("remote_control", {}).get("sync_interval_minutes", 60))))
    # Wake notifications are the fast path, but a lost wake must never leave a
    # command waiting for hours. Keep the periodic safety net bounded.
    minutes = min(configured_minutes, MAX_CONTROL_FALLBACK_MINUTES)
    return minutes * 60 + (random.randint(0, 300) if jitter else 0)


def submit_change_request(config: dict[str, Any], requested_settings: dict[str, Any]) -> dict[str, Any]:
    validate_settings(requested_settings)
    return _post(config["api"], _endpoint(config["api"], "change-requests"), {"requested_settings": requested_settings})
