#!/usr/bin/env python3
"""Cross-platform desktop manager for the Kyocera printer forwarder."""

from __future__ import annotations

import json
import platform
import queue
import socket
import subprocess
import threading
import time
import tkinter as tk
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import messagebox, ttk
from typing import Any, Callable
from urllib.parse import urlsplit

from delivery_queue import enqueue_payload, process_queue
from printer_forwarder import PrinterError, auto_activate_device, collect_all_printers, load_config, prepare_device_identity, send_to_api
from network_discovery import scan_local_printers
from app_paths import CONFIG_PATH, INSTALL_DIR, STATUS_PATH, ensure_data_dir
from secret_store import PLACEHOLDER, save_api_secrets


APP_DIR = INSTALL_DIR
SERVICE_STATUS_PATH = STATUS_PATH
APP_VERSION = "1.5.1"


class PrinterManager(tk.Tk):
    BG = "#08111f"
    PANEL = "#101c2f"
    PANEL_2 = "#14243b"
    TEXT = "#e8eef7"
    MUTED = "#91a3ba"
    ACCENT = "#28c7a5"
    BLUE = "#4b8dff"
    DANGER = "#ff6577"

    def __init__(self) -> None:
        ensure_data_dir()
        super().__init__()
        self.title("Printer Counter")
        self.geometry("1500x860")
        self.minsize(1120, 720)
        self.configure(bg=self.BG)
        self.option_add("*Font", ("Segoe UI", 10))

        self.jobs: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.last_payload: dict[str, Any] | None = None
        self.vars: dict[str, tk.Variable] = {}
        self.printer_profiles: list[dict[str, Any]] = []
        self.current_printer_index = 0
        self.loading_profile = False
        self.scroll_canvases: list[tk.Canvas] = []
        self.dashboard_cards: list[tk.Widget] = []
        self.current_view = "dashboard"
        self.printer_image: tk.PhotoImage | None = None

        self._configure_styles()
        self._build_ui()
        self.load_settings()
        self.after(150, self._process_jobs)
        self.after(350, self.ensure_device_activation)
        self.after(1000, self._scheduler_tick)

    def _configure_styles(self) -> None:
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background=self.BG)
        style.configure("Panel.TFrame", background=self.PANEL)
        style.configure("Card.TLabelframe", background=self.PANEL, foreground=self.TEXT, bordercolor="#243650")
        style.configure("Card.TLabelframe.Label", background=self.PANEL, foreground=self.TEXT, font=("Segoe UI", 11, "bold"))
        style.configure("TLabel", background=self.PANEL, foreground=self.TEXT)
        style.configure("Muted.TLabel", background=self.PANEL, foreground=self.MUTED)
        style.configure("Status.TLabel", background=self.PANEL_2, foreground=self.TEXT, padding=(12, 8))
        style.configure("TEntry", fieldbackground="#0c1728", foreground=self.TEXT, insertcolor=self.TEXT, bordercolor="#304767")
        style.configure("TCombobox", fieldbackground="#0c1728", foreground=self.TEXT, arrowcolor=self.TEXT)
        style.map("TCombobox", fieldbackground=[("readonly", "#0c1728")], foreground=[("readonly", self.TEXT)])
        style.configure("TCheckbutton", background=self.PANEL, foreground=self.TEXT)
        style.map("TCheckbutton", background=[("active", self.PANEL)], foreground=[("active", self.TEXT)])
        style.configure("Accent.TButton", background=self.ACCENT, foreground="#04120f", padding=(15, 10), font=("Segoe UI", 10, "bold"), borderwidth=0, relief="flat")
        style.map("Accent.TButton", background=[("active", "#54dec1")])
        style.configure("Blue.TButton", background=self.BLUE, foreground="white", padding=(15, 10), font=("Segoe UI", 10, "bold"), borderwidth=0, relief="flat")
        style.map("Blue.TButton", background=[("active", "#72a7ff")])
        style.configure("TButton", background="#213653", foreground=self.TEXT, padding=(13, 9), borderwidth=0, relief="flat")
        style.map("TButton", background=[("active", "#304b70")], foreground=[("active", "white")])
        style.configure("TNotebook", background=self.BG, borderwidth=0)
        style.configure("TNotebook.Tab", background="#142238", foreground=self.MUTED, padding=(18, 10))
        style.map("TNotebook.Tab", background=[("selected", self.PANEL)], foreground=[("selected", self.TEXT)])

    def _build_ui(self) -> None:
        shell = tk.Frame(self, bg=self.BG)
        shell.pack(fill="both", expand=True)

        sidebar = tk.Frame(shell, bg="#0b192c", width=225, padx=16, pady=22)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        brand = tk.Frame(sidebar, bg="#0b192c")
        brand.pack(fill="x", pady=(0, 34))
        icon_path = APP_DIR / "assets" / "app-icon.png"
        try:
            icon = tk.PhotoImage(file=str(icon_path)).subsample(28, 28)
            self.brand_icon = icon
            tk.Label(brand, image=icon, bg="#0b192c").pack(side="left", padx=(0, 10))
        except tk.TclError:
            pass
        tk.Label(brand, text="Printer Counter", bg="#0b192c", fg=self.TEXT, font=("Segoe UI", 13, "bold")).pack(side="left")

        self.nav_buttons: dict[str, tk.Button] = {}
        for key, label in (("dashboard", "Dashboard"), ("printers", "Printers"), ("activity", "Activity"), ("settings", "Settings")):
            button = tk.Button(
                sidebar, text=label, command=lambda name=key: self.show_view(name),
                bg="#0b192c", fg=self.MUTED, activebackground="#1b3152", activeforeground=self.TEXT,
                relief="flat", borderwidth=0, anchor="w", padx=18, pady=13,
                font=("Segoe UI", 11, "bold" if key == "dashboard" else "normal"), cursor="hand2",
            )
            button.pack(fill="x", pady=3)
            self.nav_buttons[key] = button
        tk.Label(sidebar, text="Simple printing insights\nfor a smoother workday.", justify="left", anchor="sw", bg="#0b192c", fg="#7186a3", font=("Segoe UI", 9)).pack(side="bottom", fill="x", pady=(20, 0))

        main = tk.Frame(shell, bg=self.BG)
        main.pack(side="left", fill="both", expand=True)
        header = tk.Frame(main, bg=self.BG, padx=28, pady=22)
        header.pack(fill="x")
        title_line = tk.Frame(header, bg=self.BG)
        title_line.pack(side="left")
        self.view_title = tk.Label(title_line, text="Printer Counter", bg=self.BG, fg=self.TEXT, font=("Segoe UI", 25, "bold"))
        self.view_title.pack(side="left")
        self.header_service = tk.Label(title_line, text="●  Service checking", bg=self.BG, fg=self.MUTED, font=("Segoe UI", 10, "bold"))
        self.header_service.pack(side="left", padx=(22, 0), pady=(8, 0))
        ttk.Button(header, text="Scan Network", style="Blue.TButton", command=self.scan_network).pack(side="right")
        ttk.Button(header, text="Add Manually", command=self.add_printer_dialog).pack(side="right", padx=(0, 10))

        self.content_host = tk.Frame(main, bg=self.BG, padx=28, pady=0)
        self.content_host.pack(fill="both", expand=True)
        self.dashboard_view = tk.Frame(self.content_host, bg=self.BG)
        self.settings_view = tk.Frame(self.content_host, bg=self.PANEL)
        self.activity_tab = tk.Frame(self.content_host, bg=self.PANEL, padx=18, pady=18)

        self.connection_tab = self._make_scrollable_tab(self.settings_view)
        self.api_tab = tk.Frame(self)
        self._build_dashboard()
        self._build_connection_tab()
        self._build_api_tab()
        self._build_activity_tab()
        self.show_view("dashboard")

    def _build_dashboard(self) -> None:
        metrics = tk.Frame(self.dashboard_view, bg=self.BG)
        metrics.pack(fill="x", pady=(0, 14))
        self.metric_labels: dict[str, tk.Label] = {}
        for index, (key, label, value, color) in enumerate((
            ("printers", "Printers", "0", self.BLUE),
            ("online", "Online", "—", self.ACCENT),
            ("queue", "Queue", "0", "#f4b942"),
            ("next", "Next delivery", "—", "#8fb5ff"),
        )):
            card = tk.Frame(metrics, bg=self.PANEL_2, padx=18, pady=13, highlightbackground="#263b59", highlightthickness=1)
            card.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 6, 0 if index == 3 else 6))
            metrics.columnconfigure(index, weight=1)
            tk.Label(card, text=label, bg=self.PANEL_2, fg=self.MUTED, font=("Segoe UI", 9)).pack(anchor="w")
            value_label = tk.Label(card, text=value, bg=self.PANEL_2, fg=color, font=("Segoe UI", 19, "bold"))
            value_label.pack(anchor="w", pady=(2, 0))
            self.metric_labels[key] = value_label

        cards_shell = tk.Frame(self.dashboard_view, bg=self.BG)
        cards_shell.pack(fill="both", expand=True)
        self.cards_canvas = tk.Canvas(cards_shell, bg=self.BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(cards_shell, orient="vertical", command=self.cards_canvas.yview)
        self.printer_cards_frame = tk.Frame(self.cards_canvas, bg=self.BG)
        self.cards_window = self.cards_canvas.create_window((0, 0), window=self.printer_cards_frame, anchor="nw")
        self.cards_canvas.configure(yscrollcommand=scrollbar.set)
        self.cards_canvas.pack(side="left", fill="both", expand=True)
        def update_card_scroll(_event=None) -> None:
            bounds = self.cards_canvas.bbox("all")
            self.cards_canvas.configure(scrollregion=bounds)
            content_height = (bounds[3] - bounds[1]) if bounds else 0
            if content_height > self.cards_canvas.winfo_height() + 2:
                if not scrollbar.winfo_ismapped():
                    scrollbar.pack(side="right", fill="y")
            elif scrollbar.winfo_ismapped():
                scrollbar.pack_forget()
        self.printer_cards_frame.bind("<Configure>", update_card_scroll)
        self.cards_canvas.bind("<Configure>", update_card_scroll, add="+")
        self.cards_canvas.bind("<Configure>", lambda event: self.cards_canvas.itemconfigure(self.cards_window, width=event.width))

        delivery = tk.Frame(self.dashboard_view, bg=self.PANEL_2, padx=20, pady=13, highlightbackground="#263b59", highlightthickness=1)
        delivery.pack(fill="x", pady=(14, 18))
        self.delivery_title = tk.Label(delivery, text="Waiting for the first report", bg=self.PANEL_2, fg=self.TEXT, font=("Segoe UI", 11, "bold"))
        self.delivery_title.pack(side="left")
        ttk.Button(delivery, text="Send now", style="Blue.TButton", command=self.send_now).pack(side="right")
        self.delivery_queue = tk.Label(delivery, text="Queue  0", bg=self.PANEL_2, fg=self.MUTED)
        self.delivery_queue.pack(side="right", padx=18)
        self.source_label = tk.Label(delivery, text="SNMP — | WEB —", bg=self.PANEL_2, fg=self.MUTED)
        self.source_label.pack(side="right", padx=18)
        self.status_label = tk.Label(delivery, text="Ready", bg=self.PANEL_2, fg=self.MUTED)
        self.status_label.pack(side="left", padx=(20, 0))

        image_path = APP_DIR / "assets" / "printer-card.png"
        try:
            self.printer_image = tk.PhotoImage(file=str(image_path)).subsample(6, 6)
        except tk.TclError:
            self.printer_image = None

    def show_view(self, name: str) -> None:
        self.current_view = name
        for frame in (self.dashboard_view, self.settings_view, self.activity_tab):
            frame.pack_forget()
        selected = "dashboard" if name in {"dashboard", "printers"} else name
        if selected == "activity":
            self.activity_tab.pack(fill="both", expand=True)
            self.view_title.configure(text="Activity")
        elif selected == "settings":
            self.settings_view.pack(fill="both", expand=True)
            self.view_title.configure(text="Settings")
        else:
            self.dashboard_view.pack(fill="both", expand=True)
            self.view_title.configure(text="Printer Counter" if name == "dashboard" else "Printers")
        for key, button in self.nav_buttons.items():
            active = key == name
            button.configure(bg="#1b3152" if active else "#0b192c", fg=self.TEXT if active else self.MUTED)

    def _make_scrollable_tab(self, page: ttk.Frame) -> ttk.Frame:
        canvas = tk.Canvas(page, bg=self.PANEL, highlightthickness=0, borderwidth=0)
        scrollbar = ttk.Scrollbar(page, orient="vertical", command=canvas.yview)
        content = ttk.Frame(canvas, style="Panel.TFrame", padding=18)
        window_id = canvas.create_window((0, 0), window=content, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def update_region(_event=None) -> None:
            canvas.configure(scrollregion=canvas.bbox("all"))

        def fit_width(event) -> None:
            canvas.itemconfigure(window_id, width=event.width)

        content.bind("<Configure>", update_region)
        canvas.bind("<Configure>", fit_width)
        self.scroll_canvases.append(canvas)
        return content

    def _scroll_active_tab(self, event) -> None:
        tab_index = self.notebook.index("current")
        if tab_index >= len(self.scroll_canvases):
            return
        canvas = self.scroll_canvases[tab_index]
        if event.delta:
            canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")
        elif getattr(event, "num", None) == 4:
            canvas.yview_scroll(-1, "units")
        elif getattr(event, "num", None) == 5:
            canvas.yview_scroll(1, "units")

    def _variable(self, key: str, value: Any = "") -> tk.Variable:
        variable = tk.BooleanVar(value=value) if isinstance(value, bool) else tk.StringVar(value=str(value))
        self.vars[key] = variable
        return variable

    def _row(self, parent, row: int, label: str, key: str, default: Any = "", *, secret: bool = False, width: int = 36) -> ttk.Entry:
        ttk.Label(parent, text=label, anchor="w").grid(row=row, column=0, sticky="w", padx=(0, 12), pady=7)
        entry = ttk.Entry(parent, textvariable=self._variable(key, default), width=width, show="•" if secret else "")
        entry.grid(row=row, column=1, sticky="ew", pady=7)
        parent.columnconfigure(1, weight=1)
        return entry

    def _build_connection_tab(self) -> None:
        profiles = ttk.LabelFrame(self.connection_tab, text="Printers", style="Card.TLabelframe", padding=20)
        profiles.pack(fill="x", pady=(0, 14))
        ttk.Label(profiles, text="Printer").grid(row=0, column=0, sticky="w", padx=(0, 12), pady=7)
        self.profile_selector = ttk.Combobox(profiles, state="readonly", width=38)
        self.profile_selector.grid(row=0, column=1, sticky="ew", pady=7)
        self.profile_selector.bind("<<ComboboxSelected>>", self._on_profile_selected)
        ttk.Button(profiles, text="Scan Network", style="Blue.TButton", command=self.scan_network).grid(row=0, column=2, padx=(12, 6))
        ttk.Button(profiles, text="Add Printer", command=self.add_printer).grid(row=0, column=3, padx=6)
        ttk.Button(profiles, text="Remove", command=self.remove_printer).grid(row=0, column=4)
        ttk.Label(profiles, text="IP address").grid(row=1, column=0, sticky="w", padx=(0, 12), pady=7)
        ttk.Entry(profiles, textvariable=self._variable("printer.ip", ""), width=38).grid(row=1, column=1, sticky="ew", pady=7)
        profiles.columnconfigure(1, weight=1)

        note = ttk.LabelFrame(self.connection_tab, text="Automatic Settings", style="Card.TLabelframe", padding=20)
        note.pack(fill="x", pady=(0, 14))
        ttk.Label(note, text="SNMP  UDP 161   ·   Web  HTTP 80   ·   Community  public", style="Muted.TLabel").pack(anchor="w")

        service = ttk.LabelFrame(self.connection_tab, text="Background Service", style="Card.TLabelframe", padding=20)
        service.pack(fill="x")
        self.service_state_label = ttk.Label(service, text="Checking service...", style="Muted.TLabel")
        self.service_state_label.pack(fill="x")

        self.activation_state = ttk.Label(service, text="API activation: checking automatically...", style="Muted.TLabel")
        self.activation_state.pack(fill="x", pady=(8, 0))

        actions = ttk.Frame(self.connection_tab, style="Panel.TFrame")
        actions.pack(fill="x", pady=(14, 4))
        ttk.Button(actions, text="Save", style="Accent.TButton", command=self.save_settings).pack(side="left")
        ttk.Button(actions, text="Test all printers", style="Blue.TButton", command=self.test_collection).pack(side="left", padx=8)
        self.scheduler_button = ttk.Button(actions, text="Install Auto Start", command=self.install_background_service)
        self.scheduler_button.pack(side="right")
        ttk.Button(actions, text="Refresh Service", command=self.refresh_service_status).pack(side="right", padx=8)

    def _build_api_tab(self) -> None:
        # Delivery settings are intentionally hidden from the simplified UI.
        self._variable("api.endpoint", "")
        self._variable("api.method", "POST")
        self._variable("api.auth_type", "none")
        self._variable("api.bearer_token", "")
        self._variable("api.api_key_header", "X-API-Key")
        self._variable("api.api_key_value", "")
        self._variable("api.activation_endpoint", "")
        self._variable("api.auto_activation_endpoint", "")
        self._variable("api.device_id", "")
        self._variable("api.installation_id", "")
        self._variable("api.access_token", "")
        self._variable("api.activated", False)
        self._variable("schedule.enabled", True)
        self._variable("schedule.mode", "twice_daily")
        self._variable("schedule.interval_minutes", 15)
        self._variable("schedule.daily_time", "12:00")
        self._variable("schedule.second_daily_time", "15:00")

    def _build_activity_tab(self) -> None:
        summary = ttk.LabelFrame(self.activity_tab, text="Latest Result", style="Card.TLabelframe", padding=14)
        summary.pack(fill="x", pady=(0, 12))
        self.summary_label = ttk.Label(summary, text="No collection test has been run yet.", style="Muted.TLabel", anchor="w", justify="left")
        self.summary_label.pack(fill="x")

        self.log_text = tk.Text(
            self.activity_tab,
            bg="#08101d",
            fg="#c9d7e8",
            insertbackground="white",
            relief="flat",
            padx=14,
            pady=12,
            height=18,
            font=("Consolas", 10),
            wrap="word",
        )
        self.log_text.pack(fill="both", expand=True)
        self.log_text.configure(state="disabled")

    def _get_nested(self, data: dict[str, Any], dotted: str, default: Any = "") -> Any:
        current: Any = data
        for part in dotted.split("."):
            if not isinstance(current, dict):
                return default
            current = current.get(part, default)
        return current

    def load_settings(self) -> None:
        try:
            data = load_config(CONFIG_PATH)
        except (FileNotFoundError, json.JSONDecodeError, PrinterError):
            self._log("Could not read config.json; using default values.")
            return
        profiles = data.get("printers")
        if not profiles:
            profiles = [{
                "id": "printer-1",
                "name": data.get("printer", {}).get("name", "Printer 1"),
                "snmp": data.get("snmp", {}),
                "printer": data.get("printer", {}),
            }]
        self.printer_profiles = [dict(profile) for profile in profiles]
        self._refresh_profile_selector()
        self._load_profile(0)
        for key, variable in self.vars.items():
            if key.startswith(("profile.", "snmp.", "printer.")):
                continue
            variable.set(self._get_nested(data, key, variable.get()))
        daily_times = data.get("schedule", {}).get("daily_times", [])
        if len(daily_times) >= 2:
            self.vars["schedule.daily_time"].set(daily_times[0])
            self.vars["schedule.second_daily_time"].set(daily_times[1])
        self._log("Settings loaded.")
        if bool(self.vars["api.activated"].get()) and str(self.vars["api.device_id"].get()).strip():
            self.activation_state.configure(text="Device activated securely.", foreground=self.ACCENT)
        self.refresh_service_status()
        self.refresh_dashboard()

    def _profile_from_vars(self, profile_id: str | None = None) -> dict[str, Any]:
        ip_address = str(self.vars["printer.ip"].get()).strip()
        parts = ip_address.split(".")
        if len(parts) != 4 or any(not part.isdigit() or not 0 <= int(part) <= 255 for part in parts):
            raise ValueError("Enter a valid printer IP address, for example 192.168.1.50")
        profile_number = self.current_printer_index + 1
        web_port = 80
        if self.printer_profiles and self.current_printer_index < len(self.printer_profiles):
            current_url = str(self._get_nested(self.printer_profiles[self.current_printer_index], "printer.base_url", ""))
            try:
                web_port = urlsplit(current_url).port or 80
            except ValueError:
                web_port = 80
        web_url = f"http://{ip_address}" if web_port == 80 else f"http://{ip_address}:{web_port}"

        return {
            "id": profile_id or f"printer-{int(time.time() * 1000)}",
            "name": f"Printer {profile_number}",
            "snmp": {
                "enabled": True,
                "host": ip_address,
                "port": 161,
                "community": "public",
                "timeout_seconds": 5,
            },
            "printer": {
                "base_url": web_url,
                "timeout_seconds": 15,
                "wake_retries": 5,
                "wake_retry_delay_seconds": 2,
                "verify_tls": True,
            },
        }

    def _save_current_profile(self) -> None:
        if self.loading_profile or not self.printer_profiles:
            return
        current_id = str(self.printer_profiles[self.current_printer_index].get("id") or "")
        self.printer_profiles[self.current_printer_index] = self._profile_from_vars(current_id)
        self._refresh_profile_selector(select=self.current_printer_index)

    def _load_profile(self, index: int) -> None:
        if not self.printer_profiles:
            return
        self.loading_profile = True
        self.current_printer_index = max(0, min(index, len(self.printer_profiles) - 1))
        profile = self.printer_profiles[self.current_printer_index]
        self.vars["printer.ip"].set(self._get_nested(profile, "snmp.host", ""))
        self.profile_selector.current(self.current_printer_index)
        self.loading_profile = False

    def _refresh_profile_selector(self, select: int | None = None) -> None:
        names = [
            f"Printer {i + 1}  —  {self._get_nested(profile, 'snmp.host', 'No IP')}"
            for i, profile in enumerate(self.printer_profiles)
        ]
        self.profile_selector.configure(values=names)
        if names:
            self.profile_selector.current(self.current_printer_index if select is None else select)

    def _on_profile_selected(self, _event=None) -> None:
        new_index = self.profile_selector.current()
        if new_index < 0 or new_index == self.current_printer_index:
            return
        self._save_current_profile()
        self._load_profile(new_index)

    def add_printer(self) -> None:
        self._save_current_profile()
        number = len(self.printer_profiles) + 1
        self.printer_profiles.append({
            "id": f"printer-{int(time.time() * 1000)}",
            "name": f"Printer {number}",
            "snmp": {"enabled": True, "host": "", "port": 161, "community": "public", "timeout_seconds": 5},
            "printer": {"base_url": "", "timeout_seconds": 15, "wake_retries": 5, "wake_retry_delay_seconds": 2, "verify_tls": True},
        })
        self._refresh_profile_selector(select=number - 1)
        self._load_profile(number - 1)
        self._log(f"Added Printer {number}.")
        self.refresh_dashboard()

    def add_printer_dialog(self) -> None:
        dialog = tk.Toplevel(self)
        dialog.title("Add Printer Manually")
        dialog.geometry("430x220")
        dialog.resizable(False, False)
        dialog.configure(bg=self.PANEL)
        dialog.transient(self)
        dialog.grab_set()
        tk.Label(dialog, text="Add Printer Manually", bg=self.PANEL, fg=self.TEXT, font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=24, pady=(22, 6))
        tk.Label(dialog, text="Enter the printer IP address. Network settings are automatic.", bg=self.PANEL, fg=self.MUTED).pack(anchor="w", padx=24)
        value = tk.StringVar()
        entry = ttk.Entry(dialog, textvariable=value, font=("Segoe UI", 12))
        entry.pack(fill="x", padx=24, pady=18)
        entry.focus_set()
        buttons = tk.Frame(dialog, bg=self.PANEL)
        buttons.pack(fill="x", padx=24)

        def confirm() -> None:
            ip_address = value.get().strip()
            parts = ip_address.split(".")
            if len(parts) != 4 or any(not part.isdigit() or not 0 <= int(part) <= 255 for part in parts):
                messagebox.showerror("Invalid IP address", "Enter a valid IPv4 address, for example 192.168.1.50", parent=dialog)
                return
            existing = {str(self._get_nested(profile, "snmp.host", "")).strip() for profile in self.printer_profiles}
            if ip_address in existing:
                messagebox.showinfo("Already added", "This printer is already in the list.", parent=dialog)
                return
            profile = {
                "id": f"printer-{int(time.time() * 1000)}",
                "name": f"Printer {len(self.printer_profiles) + 1}",
                "snmp": {"enabled": True, "host": ip_address, "port": 161, "community": "public", "timeout_seconds": 5},
                "printer": {"base_url": f"http://{ip_address}", "timeout_seconds": 15, "wake_retries": 5, "wake_retry_delay_seconds": 2, "verify_tls": True},
            }
            blank_only = len(self.printer_profiles) == 1 and not str(self._get_nested(self.printer_profiles[0], "snmp.host", "")).strip()
            if blank_only:
                self.printer_profiles[0] = profile
            else:
                self.printer_profiles.append(profile)
            self.current_printer_index = len(self.printer_profiles) - 1
            self._refresh_profile_selector(select=self.current_printer_index)
            self._load_profile(self.current_printer_index)
            self.save_settings(quiet=True)
            self.refresh_dashboard()
            dialog.destroy()

        ttk.Button(buttons, text="Cancel", command=dialog.destroy).pack(side="right")
        ttk.Button(buttons, text="Add Printer", style="Accent.TButton", command=confirm).pack(side="right", padx=(0, 8))
        entry.bind("<Return>", lambda _event: confirm())

    def scan_network(self) -> None:
        self._set_status("Scanning local networks...", self.BLUE)
        self._log("Detecting local IPv4 networks and searching for printers...")
        self._run_background("network_scan", scan_local_printers)

    def _show_discovered_printers(self, result: dict[str, Any]) -> None:
        printers = result.get("printers", [])
        networks = result.get("networks", [])
        if not printers:
            self._set_status("No printers found", self.MUTED)
            messagebox.showinfo(
                "Network scan",
                f"No printers were found across {', '.join(networks) or 'the active local networks'}.\n"
                "You can still add a printer by entering its IP address manually.",
            )
            return

        dialog = tk.Toplevel(self)
        dialog.title("Discovered Printers")
        dialog.geometry("820x430")
        dialog.configure(bg=self.BG)
        dialog.transient(self)
        dialog.grab_set()
        ttk.Label(dialog, text=f"Found {len(printers)} printer(s) on {', '.join(networks)}", style="Status.TLabel").pack(fill="x", padx=16, pady=16)
        columns = ("ip", "model", "serial", "method")
        tree = ttk.Treeview(dialog, columns=columns, show="headings", selectmode="extended", height=12)
        for key, heading, width in (("ip", "IP address", 130), ("model", "Model", 300), ("serial", "Serial number", 160), ("method", "Detected by", 130)):
            tree.heading(key, text=heading)
            tree.column(key, width=width, anchor="w")
        tree.pack(fill="both", expand=True, padx=16)
        for index, printer in enumerate(printers):
            tree.insert("", "end", iid=str(index), values=(printer["ip"], printer.get("model", ""), printer.get("serial_number", ""), printer.get("detected_by", "")))
        tree.selection_set(tree.get_children())

        buttons = ttk.Frame(dialog)
        buttons.pack(fill="x", padx=16, pady=16)

        def add_selected() -> None:
            selected = [printers[int(item)] for item in tree.selection()]
            existing_ips = {str(self._get_nested(profile, "snmp.host", "")).strip() for profile in self.printer_profiles}
            added = 0
            for discovered in selected:
                ip_address = str(discovered["ip"])
                if ip_address in existing_ips:
                    continue
                profile = {
                    "id": f"printer-{int(time.time() * 1000)}-{added}",
                    "name": str(discovered.get("model") or f"Printer {len(self.printer_profiles) + 1}"),
                    "snmp": {"enabled": True, "host": ip_address, "port": 161, "community": "public", "timeout_seconds": 5},
                    "printer": {"base_url": f"http://{ip_address}", "timeout_seconds": 15, "wake_retries": 5, "wake_retry_delay_seconds": 2, "verify_tls": True},
                }
                blank_only = len(self.printer_profiles) == 1 and not str(self._get_nested(self.printer_profiles[0], "snmp.host", "")).strip()
                if blank_only:
                    self.printer_profiles[0] = profile
                else:
                    self.printer_profiles.append(profile)
                existing_ips.add(ip_address)
                added += 1
            if added:
                self.current_printer_index = 0
                self._refresh_profile_selector(select=0)
                self._load_profile(0)
                self.save_settings(quiet=True)
                self.refresh_dashboard()
            self._log(f"Network scan added {added} new printer(s); duplicates were skipped.")
            self._set_status(f"Added {added} printer(s)", self.ACCENT)
            dialog.destroy()

        ttk.Button(buttons, text="Add Selected", style="Accent.TButton", command=add_selected).pack(side="right")
        ttk.Button(buttons, text="Cancel", command=dialog.destroy).pack(side="right", padx=(0, 8))

    def remove_printer(self) -> None:
        if len(self.printer_profiles) <= 1:
            messagebox.showwarning("Cannot remove", "At least one printer profile is required.")
            return
        name = str(self.printer_profiles[self.current_printer_index].get("name", "this printer"))
        if not messagebox.askyesno("Remove printer", f"Remove {name} from the configuration?"):
            return
        self.printer_profiles.pop(self.current_printer_index)
        self.current_printer_index = min(self.current_printer_index, len(self.printer_profiles) - 1)
        self._refresh_profile_selector(select=self.current_printer_index)
        self._load_profile(self.current_printer_index)
        self._log(f"Removed {name}.")
        self.refresh_dashboard()

    def _api_from_vars(self) -> dict[str, Any]:
        return {
            "endpoint": str(self.vars["api.endpoint"].get()).strip(),
            "method": str(self.vars["api.method"].get()),
            "auth_type": str(self.vars["api.auth_type"].get()),
            "bearer_token": str(self.vars["api.bearer_token"].get()),
            "api_key_header": str(self.vars["api.api_key_header"].get()).strip(),
            "api_key_value": str(self.vars["api.api_key_value"].get()),
            "activation_endpoint": str(self.vars["api.activation_endpoint"].get()).strip(),
            "auto_activation_endpoint": str(self.vars["api.auto_activation_endpoint"].get()).strip(),
            "device_id": str(self.vars["api.device_id"].get()).strip(),
            "installation_id": str(self.vars["api.installation_id"].get()).strip(),
            "access_token": str(self.vars["api.access_token"].get()),
            "activated": bool(self.vars["api.activated"].get()),
            "headers": {},
            "timeout_seconds": 20,
            "verify_tls": True,
        }

    def _latest_api(self) -> dict[str, Any]:
        """Prefer credentials most recently written by the background service."""
        api = self._api_from_vars()
        try:
            stored_api = load_config(CONFIG_PATH).get("api", {})
        except (OSError, ValueError, TypeError):
            stored_api = {}

        if isinstance(stored_api, dict):
            stored_token = str(stored_api.get("access_token", "")).strip()
            if bool(stored_api.get("activated")) and stored_token:
                api.update(stored_api)
                for key, value_item in stored_api.items():
                    variable = self.vars.get(f"api.{key}")
                    if variable is not None:
                        variable.set(value_item)
        return api

    def build_config(self) -> dict[str, Any]:
        self._save_current_profile()
        def integer(key: str, minimum: int = 0) -> int:
            value = int(str(self.vars[key].get()).strip())
            if value < minimum:
                raise ValueError(f"{key} must be at least {minimum}")
            return value

        daily_time = str(self.vars["schedule.daily_time"].get()).strip()
        second_daily_time = str(self.vars["schedule.second_daily_time"].get()).strip()
        try:
            datetime.strptime(daily_time, "%H:%M")
            datetime.strptime(second_daily_time, "%H:%M")
        except ValueError as exc:
            raise ValueError("Daily delivery times must use HH:MM format") from exc

        return {
            "printers": self.printer_profiles,
            "api": self._latest_api(),
            "schedule": {
                "enabled": bool(self.vars["schedule.enabled"].get()),
                "mode": str(self.vars["schedule.mode"].get()),
                "interval_minutes": integer("schedule.interval_minutes", 1),
                "daily_time": daily_time,
                "daily_times": [daily_time, second_daily_time],
            },
        }

    def ensure_device_activation(self) -> None:
        latest_api = self._latest_api()
        if bool(latest_api.get("activated")) and str(latest_api.get("access_token", "")).strip():
            self.activation_state.configure(text="API activation: active", foreground=self.ACCENT)
            return
        try:
            config = self.build_config()
        except ValueError as exc:
            self.activation_state.configure(text=f"API activation pending: {exc}", foreground=self.MUTED)
            return
        prepared = prepare_device_identity(config["api"])
        for key, value_item in prepared.items():
            variable = self.vars.get(f"api.{key}")
            if variable is not None:
                variable.set(value_item)
        save_api_secrets(prepared)
        self.activation_state.configure(text="API activation: connecting securely...", foreground=self.BLUE)

        def action() -> dict[str, Any]:
            return auto_activate_device(
                prepared,
                device_name=socket.gethostname(),
                platform_name="windows" if platform.system() == "Windows" else "linux",
                app_version=APP_VERSION,
            )
        self._run_background("auto_activate", action)

    def save_settings(self, quiet: bool = False) -> bool:
        try:
            config = self.build_config()
            save_api_secrets(config["api"])
            config["api"] = dict(PLACEHOLDER)
            CONFIG_PATH.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            self._log("Settings saved.")
            self._set_status("Settings saved", self.ACCENT)
            if not quiet:
                messagebox.showinfo("Success", "Settings saved successfully.")
            return True
        except (ValueError, OSError) as exc:
            self._set_status("Could not save settings", self.DANGER)
            messagebox.showerror("Invalid settings", str(exc))
            return False

    def _run_background(self, name: str, action: Callable[[], Any]) -> None:
        def runner() -> None:
            try:
                self.jobs.put((name + ":ok", action()))
            except Exception as exc:  # UI boundary: display all operational errors.
                self.jobs.put((name + ":error", exc))
        threading.Thread(target=runner, daemon=True).start()

    def test_collection(self) -> None:
        if not self.save_settings(quiet=True):
            return
        try:
            config = self.build_config()
        except ValueError as exc:
            messagebox.showerror("Error", str(exc))
            return
        self._set_status("Reading printer...", self.BLUE)
        self._log("Starting SNMP and web collection test...")
        self._run_background("collect", lambda: collect_all_printers(config))

    def send_now(self, scheduled: bool = False) -> None:
        if not scheduled and not self.save_settings(quiet=True):
            return
        try:
            config = self.build_config()
        except ValueError as exc:
            messagebox.showerror("Error", str(exc))
            return
        if not config["api"]["endpoint"]:
            messagebox.showwarning("API not configured", "Enter the API endpoint URL first.")
            return
        self._set_status("Collecting and sending...", self.BLUE)
        self._log("Collecting printer data and sending it to the API...")

        def action():
            payload = collect_all_printers(config)
            enqueue_payload(payload)
            result = process_queue(config, send_to_api)
            return payload, result

        self._run_background("send", action)

    def _process_jobs(self) -> None:
        try:
            while True:
                event, value = self.jobs.get_nowait()
                if event == "collect:ok":
                    self._show_payload(value)
                    self._set_status("Printer data collected successfully", self.ACCENT)
                    self._log("Collection test succeeded.")
                elif event == "send:ok":
                    payload, result = value
                    self._show_payload(payload)
                    if result["pending"]:
                        self._set_status(f"Saved to queue — {result['pending']} pending", self.BLUE)
                        self._log(f"API unavailable. Report safely queued. Next retry is automatic. {result.get('last_error', '')}")
                    else:
                        status = result.get("http_status", 200)
                        self._set_status(f"Sent successfully — HTTP {status}", self.ACCENT)
                        self._log(f"Delivery succeeded: HTTP {status} {result.get('api_response', '')[:180]}")
                elif event == "auto_activate:ok":
                    for key, value_item in value.items():
                        variable = self.vars.get(f"api.{key}")
                        if variable is not None:
                            variable.set(value_item)
                    save_api_secrets(value)
                    config = self.build_config()
                    config["api"] = dict(PLACEHOLDER)
                    CONFIG_PATH.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                    self.activation_state.configure(text="API activation: active", foreground=self.ACCENT)
                    self._set_status("Device activated", self.ACCENT)
                    self._log("Device activation succeeded. Credentials were stored by the operating system.")
                elif event == "auto_activate:error":
                    self.activation_state.configure(text="API activation: waiting for the trusted server", foreground=self.MUTED)
                    self._log(f"Automatic activation is pending: {value}")
                elif event == "network_scan:ok":
                    self._log(f"Network scan checked {value.get('scanned', 0)} address(es) on {', '.join(value.get('networks', []))}.")
                    self._show_discovered_printers(value)
                elif event.endswith(":error"):
                    self._set_status("Operation failed", self.DANGER)
                    self._log(f"Error: {value}")
                    messagebox.showerror("Operation failed", str(value))
        except queue.Empty:
            pass
        self.after(150, self._process_jobs)

    def _show_payload(self, payload: dict[str, Any]) -> None:
        self.last_payload = payload
        summary = payload.get("summary", {})
        printers = payload.get("printers", [])
        snmp_count = sum(1 for item in printers if item.get("sources", {}).get("snmp", {}).get("ok"))
        web_count = sum(1 for item in printers if item.get("sources", {}).get("web", {}).get("ok"))
        self.source_label.configure(text=f"SNMP {snmp_count}/{len(printers)} | WEB {web_count}/{len(printers)}")
        lines = []
        for item in printers[:4]:
            printer = item.get("printer", {})
            counters = item.get("counters", {})
            printed = counters.get("printed_pages", {}).get("total", "—")
            state = "OK" if item.get("ok") else f"FAILED: {item.get('error', 'Unknown error')}"
            lines.append(f"{item.get('name')}: {state} | {printer.get('serial_number', '—')} | Printed {printed}")
        if len(printers) > 4:
            lines.append(f"...and {len(printers) - 4} more")
        self.summary_label.configure(
            text=f"Successful {summary.get('successful', 0)} of {summary.get('configured', len(printers))}\n" + "\n".join(lines),
            foreground=self.TEXT,
        )
        self._log(json.dumps(payload, ensure_ascii=False, indent=2))
        self.refresh_dashboard()

    def refresh_dashboard(self) -> None:
        if not hasattr(self, "printer_cards_frame"):
            return
        for child in self.printer_cards_frame.winfo_children():
            child.destroy()

        payload_items = (self.last_payload or {}).get("printers", [])
        by_id = {str(item.get("id", "")): item for item in payload_items}
        by_ip = {
            str(item.get("printer", {}).get("ipv4_address") or item.get("snmp", {}).get("host") or ""): item
            for item in payload_items
        }
        online = 0
        for column in range(3):
            self.printer_cards_frame.columnconfigure(column, weight=1, uniform="printer-card")
        for index, profile in enumerate(self.printer_profiles):
            ip_address = str(self._get_nested(profile, "snmp.host", "")).strip() or "Not configured"
            result = by_id.get(str(profile.get("id", ""))) or by_ip.get(ip_address) or {}
            ok = result.get("ok")
            if ok is True:
                status, status_color = "Online", self.ACCENT
                online += 1
            elif ok is False:
                status, status_color = "Offline", self.DANGER
            else:
                status, status_color = "Ready", "#f4b942"
            printer = result.get("printer", {})
            counters = result.get("counters", {})
            name = str(printer.get("model") or profile.get("name") or f"Printer {index + 1}")
            serial = str(printer.get("serial_number") or "—")
            total = counters.get("copy_printer_fax_total")
            if total is None:
                total = counters.get("printed_pages", {}).get("total", "—")

            card = tk.Frame(self.printer_cards_frame, bg=self.PANEL_2, padx=20, pady=16, highlightbackground="#28405f", highlightthickness=1)
            card.grid(row=index // 3, column=index % 3, sticky="nsew", padx=(0 if index % 3 == 0 else 6, 0 if index % 3 == 2 else 6), pady=6)
            if self.printer_image is not None:
                tk.Label(card, image=self.printer_image, bg=self.PANEL_2).pack(pady=(0, 6))
            tk.Label(card, text=name, bg=self.PANEL_2, fg=self.TEXT, font=("Segoe UI", 13, "bold"), anchor="w").pack(fill="x")
            status_row = tk.Frame(card, bg=self.PANEL_2)
            status_row.pack(fill="x", pady=(5, 10))
            dot = tk.Canvas(status_row, width=13, height=13, bg=self.PANEL_2, highlightthickness=0)
            dot.create_oval(2, 2, 11, 11, fill=status_color, outline=status_color)
            dot.pack(side="left", padx=(0, 6))
            tk.Label(status_row, text=status, bg=self.PANEL_2, fg=status_color, font=("Segoe UI", 10, "bold")).pack(side="left")

            details = tk.Frame(card, bg=self.PANEL_2)
            details.pack(fill="x")
            for row, (label, value) in enumerate((("IP address", ip_address), ("Serial number", serial), ("Copy + Printer + Fax", "Total"))):
                tk.Label(details, text=label, bg=self.PANEL_2, fg=self.MUTED, font=("Segoe UI", 10)).grid(row=row, column=0, sticky="w", pady=3)
                tk.Label(details, text=value, bg=self.PANEL_2, fg=self.TEXT, font=("Segoe UI", 10)).grid(row=row, column=1, sticky="e", pady=3)
            details.columnconfigure(1, weight=1)
            tk.Label(card, text=f"{total:,}" if isinstance(total, int) else str(total), bg=self.PANEL_2, fg=self.TEXT, font=("Segoe UI", 22, "bold"), anchor="e").pack(fill="x", pady=(2, 10))
            buttons = tk.Frame(card, bg=self.PANEL_2)
            buttons.pack(fill="x")
            ttk.Button(buttons, text="Test", command=self.test_collection).pack(side="left", fill="x", expand=True)
            ttk.Button(buttons, text="Manage", command=lambda selected=index: self._open_printer_settings(selected)).pack(side="left", padx=(7, 0))

        if 0 < len(self.printer_profiles) < 3:
            index = len(self.printer_profiles)
            add_card = tk.Frame(self.printer_cards_frame, bg="#101b2d", padx=24, pady=24, highlightbackground="#263b59", highlightthickness=1)
            add_card.grid(row=index // 3, column=index % 3, sticky="nsew", padx=(0 if index % 3 == 0 else 6, 0 if index % 3 == 2 else 6), pady=6)
            tk.Label(add_card, text="Add another printer", bg="#101b2d", fg=self.TEXT, font=("Segoe UI", 14, "bold")).pack(pady=(95, 8))
            tk.Label(add_card, text="Enter an IP address or search the local network.", bg="#101b2d", fg=self.MUTED, wraplength=250, justify="center").pack(pady=(0, 18))
            ttk.Button(add_card, text="Add Manually", command=self.add_printer_dialog).pack(fill="x", pady=4)
            ttk.Button(add_card, text="Scan Network", style="Blue.TButton", command=self.scan_network).pack(fill="x", pady=4)

        if not self.printer_profiles:
            tk.Label(self.printer_cards_frame, text="No printers yet. Add one manually or scan the network.", bg=self.BG, fg=self.MUTED, font=("Segoe UI", 12)).pack(pady=70)
        self.metric_labels["printers"].configure(text=str(len([p for p in self.printer_profiles if self._get_nested(p, "snmp.host", "")])))
        self.metric_labels["online"].configure(text=str(online) if payload_items else "—")

    def _open_printer_settings(self, index: int) -> None:
        self.current_printer_index = max(0, min(index, len(self.printer_profiles) - 1))
        self._load_profile(self.current_printer_index)
        self.show_view("settings")

    def _set_status(self, text: str, color: str) -> None:
        self.status_label.configure(text=text, fg=color)

    def _log(self, text: str) -> None:
        if not hasattr(self, "log_text"):
            return
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.configure(state="normal")
        self.log_text.insert("end", f"[{timestamp}] {text}\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def install_background_service(self) -> None:
        if not self.save_settings(quiet=True):
            return
        try:
            if platform.system() == "Windows":
                service_exe = str(APP_DIR / "KyoceraPrinterService.exe")
                if not Path(service_exe).exists():
                    raise OSError("Windows service executable was not found. Install the packaged application first.")
                escaped = service_exe.replace("'", "''")
                command = (
                    "$p=Start-Process -FilePath '" + escaped + "' -ArgumentList '--startup auto install' "
                    "-Verb RunAs -Wait -PassThru; if($p.ExitCode -eq 0){"
                    "Start-Process -FilePath '" + escaped + "' -ArgumentList 'start' -Verb RunAs -Wait}"
                )
                subprocess.Popen(["powershell.exe", "-NoProfile", "-Command", command])
                self._log("Windows requested administrator approval to install the auto-start service.")
            else:
                if str(APP_DIR).startswith("/opt/kyocera-printer-manager"):
                    subprocess.Popen(["systemctl", "enable", "--now", "kyocera-printer-manager.service"])
                    self._log("The systemd service was enabled and started.")
                else:
                    subprocess.Popen(["pkexec", "sh", str(APP_DIR / "install-linux-service.sh")])
                    self._log("Linux requested administrator approval to install the systemd service.")
            self._set_status("Auto-start installation requested", self.BLUE)
            self.after(4000, self.refresh_service_status)
        except OSError as exc:
            messagebox.showerror("Service installation failed", str(exc))

    def refresh_service_status(self) -> None:
        try:
            status = json.loads(SERVICE_STATUS_PATH.read_text(encoding="utf-8"))
            heartbeat = datetime.fromisoformat(str(status["heartbeat"]).replace("Z", "+00:00"))
            age = max(0, (datetime.now(heartbeat.tzinfo) - heartbeat).total_seconds())
            live = age < 35
            state = str(status.get("state", "unknown")).upper()
            message = str(status.get("message", ""))
            next_run = status.get("next_run")
            text = f"{'RUNNING' if live else 'OFFLINE'} · {state} · {message}"
            if next_run:
                text += f" · Next: {next_run}"
            self.service_state_label.configure(text=text, foreground=self.ACCENT if live else self.DANGER)
            self.header_service.configure(text=f"●  {'Service running' if live else 'Service offline'}", fg=self.ACCENT if live else self.DANGER)
            pending = int(status.get("queue_pending", 0) or 0)
            self.metric_labels["queue"].configure(text=str(pending))
            self.delivery_queue.configure(text=f"Queue  {pending}")
            if next_run:
                try:
                    next_value = datetime.fromisoformat(str(next_run)).strftime("%I:%M %p").lstrip("0")
                except ValueError:
                    next_value = str(next_run)
                self.metric_labels["next"].configure(text=next_value)
            last_result = status.get("last_result", {})
            if last_result.get("ok"):
                self.delivery_title.configure(text="Last report sent successfully", fg=self.TEXT)
            elif pending:
                self.delivery_title.configure(text="Report safely queued for retry", fg="#f4b942")
        except (FileNotFoundError, json.JSONDecodeError, KeyError, ValueError, OSError):
            self.service_state_label.configure(
                text="OFFLINE · Install Auto Start to run the background worker.",
                foreground=self.DANGER,
            )
            self.header_service.configure(text="●  Service offline", fg=self.DANGER)

    def _scheduler_tick(self) -> None:
        self.refresh_service_status()
        self.after(5000, self._scheduler_tick)


if __name__ == "__main__":
    PrinterManager().mainloop()
