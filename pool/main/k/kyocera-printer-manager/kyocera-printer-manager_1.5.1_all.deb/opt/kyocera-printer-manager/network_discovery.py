"""Cross-platform discovery of printers on locally reachable IPv4 networks."""

from __future__ import annotations

import ipaddress
import json
import platform
import socket
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any
from urllib.error import URLError
from urllib.request import Request, urlopen

from printer_forwarder import SnmpError, snmp_get
from usb_collector import discover_usb_printers


DISCOVERY_TIMEOUT = 0.35
MAX_ADDRESSES_PER_NETWORK = 4094
PRINTER_WORDS = ("printer", "kyocera", "ecosys", "taskalfa", "triumph-adler", "copier", "multifunction")
SYS_DESCRIPTION_OID = "1.3.6.1.2.1.1.1.0"
SERIAL_NUMBER_OID = "1.3.6.1.2.1.43.5.1.1.17.1"


def _run_json(command: list[str]) -> Any:
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    completed = subprocess.run(command, capture_output=True, text=True, timeout=15, creationflags=flags)
    if completed.returncode:
        return []
    try:
        return json.loads(completed.stdout or "[]")
    except json.JSONDecodeError:
        return []


def local_ipv4_networks() -> list[ipaddress.IPv4Network]:
    """Return active directly connected private networks without fixed IP assumptions."""
    addresses: list[tuple[str, int, str]] = []
    if platform.system() == "Windows":
        script = (
            "Get-NetIPAddress -AddressFamily IPv4 | "
            "Where-Object {$_.AddressState -eq 'Preferred' -and $_.IPAddress -ne '127.0.0.1'} | "
            "Select-Object IPAddress,PrefixLength,InterfaceAlias | ConvertTo-Json -Compress"
        )
        value = _run_json(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script])
        for item in value if isinstance(value, list) else [value]:
            if isinstance(item, dict):
                addresses.append((str(item.get("IPAddress", "")), int(item.get("PrefixLength", 32)), str(item.get("InterfaceAlias", ""))))
    else:
        value = _run_json(["ip", "-j", "-4", "address", "show", "up"])
        for interface in value if isinstance(value, list) else []:
            if str(interface.get("ifname", "")).lower() == "lo":
                continue
            for item in interface.get("addr_info", []):
                if item.get("family") == "inet":
                    addresses.append((str(item.get("local", "")), int(item.get("prefixlen", 32)), str(interface.get("ifname", ""))))
        if not addresses:
            try:
                fallback = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=5)
                for address in fallback.stdout.split():
                    addresses.append((address, 24, "hostname-fallback"))
            except (OSError, subprocess.SubprocessError):
                pass

    networks: set[ipaddress.IPv4Network] = set()
    virtual_markers = ("loopback", "vethernet", "default switch", "docker", "veth", "br-", "vmware", "virtualbox")
    for address, prefix, interface_name in addresses:
        if any(marker in interface_name.lower() for marker in virtual_markers):
            continue
        try:
            ip = ipaddress.ip_address(address)
            network = ipaddress.ip_network(f"{ip}/{prefix}", strict=False)
        except ValueError:
            continue
        if ip.is_loopback or ip.is_link_local or not ip.is_private:
            continue
        # Scanning a whole /16 or larger is unsafe and slow. Search the local
        # /24 containing this interface; direct manual entry remains available.
        if network.num_addresses - 2 > MAX_ADDRESSES_PER_NETWORK:
            network = ipaddress.ip_network(f"{ip}/24", strict=False)
        networks.add(network)
    return sorted(networks, key=lambda item: (int(item.network_address), item.prefixlen))


def _tcp_open(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=DISCOVERY_TIMEOUT):
            return True
    except OSError:
        return False


def _web_looks_like_printer(host: str, https: bool = False) -> bool:
    scheme = "https" if https else "http"
    try:
        request = Request(f"{scheme}://{host}/", headers={"User-Agent": "KyoceraPrinterManager-Discovery"})
        with urlopen(request, timeout=1.2) as response:
            sample = response.read(131072).decode("utf-8", errors="ignore").lower()
        return any(word in sample for word in PRINTER_WORDS)
    except (OSError, URLError, ValueError):
        return False


def probe_printer(host: str) -> dict[str, Any] | None:
    description = ""
    serial_number = ""
    try:
        values = snmp_get(host, 161, "public", [SYS_DESCRIPTION_OID], DISCOVERY_TIMEOUT)
        description = str(values.get(SYS_DESCRIPTION_OID) or "").strip()
        try:
            serial = snmp_get(host, 161, "public", [SERIAL_NUMBER_OID], DISCOVERY_TIMEOUT)
            serial_number = str(serial.get(SERIAL_NUMBER_OID) or "").strip()
        except SnmpError:
            pass
    except SnmpError:
        pass

    text = description.lower()
    snmp_printer = bool(serial_number or any(word in text for word in PRINTER_WORDS))
    raw_printing = _tcp_open(host, 9100)
    web_printer = False
    if not snmp_printer and not raw_printing:
        if _tcp_open(host, 80):
            web_printer = _web_looks_like_printer(host)
        elif _tcp_open(host, 443):
            web_printer = _web_looks_like_printer(host, https=True)
    if not (snmp_printer or raw_printing or web_printer):
        return None
    methods = []
    if snmp_printer:
        methods.append("SNMP")
    if raw_printing:
        methods.append("RAW 9100")
    if web_printer:
        methods.append("WEB")
    return {
        "ip": host,
        "model": description or "Network printer",
        "serial_number": serial_number,
        "detected_by": " + ".join(methods),
    }


def scan_local_printers() -> dict[str, Any]:
    networks = local_ipv4_networks()
    hosts = sorted({str(host) for network in networks for host in network.hosts()}, key=ipaddress.ip_address)
    results: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=min(96, max(1, len(hosts)))) as executor:
        futures = {executor.submit(probe_printer, host): host for host in hosts}
        for future in as_completed(futures):
            try:
                result = future.result()
            except Exception:
                result = None
            if result:
                results.append(result)
    results.sort(key=lambda item: ipaddress.ip_address(item["ip"]))
    return {"networks": [str(network) for network in networks], "scanned": len(hosts), "printers": results}


def scan_all_printers() -> dict[str, Any]:
    """Discover network and locally attached USB printers in one operation."""
    result = scan_local_printers()
    for item in result["printers"]:
        item["connection_type"] = "network"
    try:
        usb = discover_usb_printers()
    except Exception as exc:
        usb = []
        result["usb_error"] = str(exc)
    result["usb_printers"] = usb
    result["printers"] = [*result["printers"], *usb]
    return result
