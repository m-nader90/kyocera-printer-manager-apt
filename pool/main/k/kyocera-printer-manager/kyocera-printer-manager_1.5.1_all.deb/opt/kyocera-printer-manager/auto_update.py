#!/usr/bin/env python3
"""Signed automatic updates from the public GitHub releases repository."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from app_paths import DATA_DIR, UPDATE_HEALTH_PATH


RELEASE_API = "https://api.github.com/repos/m-nader90/kyocera-printer-manager-releases/releases/latest"
PUBLIC_KEY_B64 = "ha4h+AkmsHQeTCvO1kthtlCO6SWEtSwXVBoWMlnNUqg="
UPDATE_DIR = DATA_DIR / "updates"
HTTP_TIMEOUT = 30


class UpdateError(RuntimeError):
    pass


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _write_update_health(**values: Any) -> None:
    """Persist an atomic, non-secret audit trail for the update lifecycle."""
    current: dict[str, Any] = {}
    try:
        current = json.loads(UPDATE_HEALTH_PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    current.update(values)
    UPDATE_HEALTH_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary = UPDATE_HEALTH_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, UPDATE_HEALTH_PATH)


def mark_update_healthy(running_version: str) -> None:
    """Confirm that the newly installed service reached its Python entry point."""
    _write_update_health(
        state="healthy",
        running_version=running_version,
        healthy_at=_now_iso(),
        error="",
    )


def _request_json(url: str) -> dict[str, Any]:
    request = Request(url, headers={"Accept": "application/vnd.github+json", "User-Agent": "KyoceraPrinterManager-Updater"})
    with urlopen(request, timeout=HTTP_TIMEOUT) as response:
        value = json.loads(response.read().decode("utf-8"))
    if not isinstance(value, dict):
        raise UpdateError("The update server returned an invalid document.")
    return value


def _download(url: str, destination: Path) -> None:
    request = Request(url, headers={"Accept": "application/octet-stream", "User-Agent": "KyoceraPrinterManager-Updater"})
    temporary = destination.with_suffix(destination.suffix + ".part")
    with urlopen(request, timeout=HTTP_TIMEOUT) as response, temporary.open("wb") as output:
        while chunk := response.read(1024 * 1024):
            output.write(chunk)
    os.replace(temporary, destination)


def _canonical_manifest(manifest: dict[str, Any]) -> bytes:
    unsigned = {key: value for key, value in manifest.items() if key != "signature"}
    return json.dumps(unsigned, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def verify_manifest(manifest: dict[str, Any]) -> None:
    signature_text = str(manifest.get("signature", ""))
    try:
        public_key = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64, validate=True))
        public_key.verify(base64.b64decode(signature_text, validate=True), _canonical_manifest(manifest))
    except (ValueError, InvalidSignature) as exc:
        raise UpdateError("The release manifest signature is invalid.") from exc


def _version_tuple(value: str) -> tuple[int, ...]:
    try:
        return tuple(int(part) for part in value.strip().lstrip("v").split("."))
    except ValueError as exc:
        raise UpdateError("The update server returned an invalid version.") from exc


def _asset_map(release: dict[str, Any]) -> dict[str, str]:
    return {
        str(asset.get("name")): str(asset.get("browser_download_url"))
        for asset in release.get("assets", [])
        if isinstance(asset, dict) and asset.get("name") and asset.get("browser_download_url")
    }


def check_for_update(current_version: str, *, install: bool = False, silent: bool = False) -> dict[str, Any]:
    release = _request_json(RELEASE_API)
    assets = _asset_map(release)
    manifest_url = assets.get("release-manifest.json")
    if not manifest_url:
        raise UpdateError("The latest release does not contain a manifest.")
    manifest = _request_json(manifest_url)
    verify_manifest(manifest)
    latest_version = str(manifest.get("version", ""))
    if _version_tuple(latest_version) <= _version_tuple(current_version):
        return {"available": False, "current_version": current_version, "latest_version": latest_version}

    platform_key = "windows" if sys.platform == "win32" else "linux" if sys.platform.startswith("linux") else ""
    asset = manifest.get("assets", {}).get(platform_key, {}) if platform_key else {}
    filename = str(asset.get("file", ""))
    expected_hash = str(asset.get("sha256", "")).lower()
    download_url = assets.get(filename)
    if not filename or len(expected_hash) != 64 or not download_url:
        raise UpdateError(f"Release {latest_version} has no valid package for this operating system.")
    result = {
        "available": True,
        "current_version": current_version,
        "latest_version": latest_version,
        "file": filename,
    }
    if not install:
        return result

    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    destination = UPDATE_DIR / filename
    _download(download_url, destination)
    actual_hash = hashlib.sha256(destination.read_bytes()).hexdigest().lower()
    if actual_hash != expected_hash:
        destination.unlink(missing_ok=True)
        raise UpdateError("The downloaded update failed SHA256 verification.")

    _write_update_health(
        state="installing",
        previous_version=current_version,
        pending_version=latest_version,
        package=str(destination),
        launched_at=_now_iso(),
        error="",
    )

    try:
        if sys.platform == "win32":
            creation_flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
            installer_mode = "/VERYSILENT" if silent else "/SILENT"
            subprocess.Popen(
                [str(destination), installer_mode, "/SUPPRESSMSGBOXES", "/NORESTART", "/CLOSEAPPLICATIONS"],
                creationflags=creation_flags,
                close_fds=True,
            )
        elif sys.platform.startswith("linux"):
            # Resolve dependencies introduced by future releases instead of
            # leaving the package half-configured as a bare `dpkg -i` can.
            subprocess.Popen([
                "systemd-run", "--unit=kyocera-printer-manager-update", "--collect", "--on-active=3s",
                "/usr/bin/apt-get", "install", "--yes", str(destination),
            ], close_fds=True)
    except OSError as exc:
        _write_update_health(state="launch_failed", error=str(exc), failed_at=_now_iso())
        raise UpdateError("The verified update could not be launched.") from exc
    return {**result, "launched": True, "silent": silent}

