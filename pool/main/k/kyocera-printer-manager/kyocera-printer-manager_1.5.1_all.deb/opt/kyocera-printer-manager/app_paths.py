"""Runtime paths shared by source, packaged GUI, and Windows service."""

from __future__ import annotations

import os
import sys
from pathlib import Path


APP_NAME = "Kyocera Printer Manager"
SOURCE_DIR = Path(__file__).resolve().parent
INSTALL_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else SOURCE_DIR
RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", SOURCE_DIR)) if getattr(sys, "frozen", False) else SOURCE_DIR

if sys.platform == "win32" and getattr(sys, "frozen", False):
    DATA_DIR = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / APP_NAME
elif sys.platform.startswith("linux") and str(SOURCE_DIR).startswith("/opt/kyocera-printer-manager"):
    DATA_DIR = Path("/var/lib/kyocera-printer-manager")
else:
    DATA_DIR = SOURCE_DIR

CONFIG_PATH = DATA_DIR / "config.json"
SECRETS_PATH = DATA_DIR / "api-secrets.dat"
SECRET_KEY_PATH = DATA_DIR / "api-secrets.key"
STATUS_PATH = DATA_DIR / "service-status.json"
UPDATE_HEALTH_PATH = DATA_DIR / "update-health.json"
LOG_PATH = DATA_DIR / "printer-service.log"
QUEUE_DIR = DATA_DIR / "delivery-queue"


def ensure_data_dir() -> Path:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return DATA_DIR
