"""Windows DPAPI-backed storage for API configuration secrets."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import secrets
import shutil
from pathlib import Path
from typing import Any

from app_paths import CONFIG_PATH, SECRETS_PATH, SECRET_KEY_PATH, ensure_data_dir


ENTROPY = b"KyoceraPrinterManager/API/v1"
PLACEHOLDER = {"protected": True, "storage": "os-protected"}


class SecretStoreError(RuntimeError):
    pass


def _win32crypt():
    if sys.platform != "win32":
        raise SecretStoreError("Protected API storage is available on Windows only.")
    import win32crypt
    return win32crypt


def save_api_secrets(api: dict[str, Any], path: Path = SECRETS_PATH) -> None:
    ensure_data_dir()
    raw = json.dumps(api, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if sys.platform == "win32":
        encrypted = _win32crypt().CryptProtectData(
            raw,
            "Kyocera Printer Manager API configuration",
            ENTROPY,
            None,
            None,
            0x4,  # CRYPTPROTECT_LOCAL_MACHINE
        )
    elif sys.platform.startswith("linux"):
        # systemd-creds machine-bound secrets can normally only be decrypted by
        # root. The desktop UI intentionally runs as the signed-in user, so use
        # an app-specific AES key protected by the package's scoped filesystem
        # ACLs. Existing systemd-creds data is migrated during package upgrade.
        try:
            if not SECRET_KEY_PATH.exists():
                SECRET_KEY_PATH.write_text(secrets.token_hex(32), encoding="ascii")
                # Keep the ACL mask writable. The containing data directory is
                # private, while named desktop-user ACL entries need this mask
                # to decrypt and update credentials written by the root service.
                os.chmod(SECRET_KEY_PATH, 0o660)
            result = subprocess.run(
                ["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-salt", "-pass", f"file:{SECRET_KEY_PATH}"],
                input=raw,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
            encrypted = b"KPM-OPENSSL-AES256\n" + result.stdout
        except (OSError, subprocess.CalledProcessError) as exc:
            raise SecretStoreError("OpenSSL could not encrypt the API configuration.") from exc
    else:
        raise SecretStoreError("Protected API storage is not supported on this operating system.")
    temporary = path.with_suffix(".tmp")
    temporary.write_bytes(encrypted)
    if sys.platform.startswith("linux"):
        os.chmod(temporary, 0o660)
    os.replace(temporary, path)
    if sys.platform.startswith("linux"):
        os.chmod(path, 0o660)


def load_api_secrets(path: Path = SECRETS_PATH) -> dict[str, Any]:
    try:
        encrypted = path.read_bytes()
    except FileNotFoundError as exc:
        raise SecretStoreError("Protected API configuration was not found.") from exc
    try:
        if sys.platform == "win32":
            raw = _win32crypt().CryptUnprotectData(encrypted, ENTROPY, None, None, 0)[1]
        elif sys.platform.startswith("linux") and encrypted.startswith(b"KPM-SYSTEMD-CREDS\n"):
            result = subprocess.run(
                ["systemd-creds", "decrypt", "--name=kyocera-api", "-", "-"],
                input=encrypted.split(b"\n", 1)[1],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
            raw = result.stdout
        elif sys.platform.startswith("linux") and encrypted.startswith(b"KPM-OPENSSL-AES256\n"):
            result = subprocess.run(
                ["openssl", "enc", "-d", "-aes-256-cbc", "-pbkdf2", "-pass", f"file:{SECRET_KEY_PATH}"],
                input=encrypted.split(b"\n", 1)[1],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
            raw = result.stdout
        else:
            raise SecretStoreError("Protected API storage is not supported on this operating system.")
        value = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise SecretStoreError("Protected API configuration could not be decrypted on this computer.") from exc
    if not isinstance(value, dict):
        raise SecretStoreError("Protected API configuration is invalid.")
    return value


def protect_config(config_path: Path = CONFIG_PATH) -> bool:
    """Move a plaintext API section from config.json into DPAPI storage."""
    config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    api = config.get("api")
    if not isinstance(api, dict) or api.get("protected"):
        return False
    save_api_secrets(api)
    config["api"] = dict(PLACEHOLDER)
    temporary = config_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, config_path)
    return True


def migrate_linux_secrets(path: Path = SECRETS_PATH) -> bool:
    """Convert root-only systemd-creds data to the shared Linux app store."""
    if not sys.platform.startswith("linux") or not path.exists():
        return False
    if not path.read_bytes().startswith(b"KPM-SYSTEMD-CREDS\n"):
        return False
    save_api_secrets(load_api_secrets(path), path)
    return True
