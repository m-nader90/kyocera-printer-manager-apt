#!/usr/bin/env python3
"""Read Kyocera Command Center RX data and forward it to an HTTP API."""

from __future__ import annotations

import argparse
import json
import logging
import re
import secrets
import socket
import ssl
import sys
import time
import uuid
from datetime import datetime, timezone
from http.cookiejar import CookieJar
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit, urlunsplit
from urllib.request import HTTPCookieProcessor, HTTPSHandler, Request, build_opener

from app_paths import CONFIG_PATH
from secret_store import SecretStoreError, load_api_secrets, save_api_secrets
from usb_collector import UsbPrinterError, collect_usb_printer


LOG = logging.getLogger("printer-forwarder")
DEFAULT_CONFIG = CONFIG_PATH


class PrinterError(RuntimeError):
    pass


class DeviceAuthenticationError(PrinterError):
    """The server rejected this device token; automatic re-enrollment is required."""


class SnmpError(PrinterError):
    pass


def ber_length(length: int) -> bytes:
    if length < 0x80:
        return bytes([length])
    encoded = length.to_bytes((length.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(encoded)]) + encoded


def ber_tlv(tag: int, value: bytes) -> bytes:
    return bytes([tag]) + ber_length(len(value)) + value


def ber_integer(value: int) -> bytes:
    size = max(1, (value.bit_length() + 8) // 8)
    return ber_tlv(0x02, value.to_bytes(size, "big", signed=True))


def ber_oid(oid: str) -> bytes:
    parts = [int(part) for part in oid.strip(".").split(".")]
    if len(parts) < 2:
        raise ValueError(f"Invalid OID: {oid}")
    encoded = bytearray([parts[0] * 40 + parts[1]])
    for number in parts[2:]:
        chunks = [number & 0x7F]
        number >>= 7
        while number:
            chunks.append(0x80 | (number & 0x7F))
            number >>= 7
        encoded.extend(reversed(chunks))
    return ber_tlv(0x06, bytes(encoded))


def read_tlv(data: bytes, offset: int = 0) -> tuple[int, bytes, int]:
    if offset + 2 > len(data):
        raise SnmpError("Truncated SNMP response")
    tag = data[offset]
    length_byte = data[offset + 1]
    cursor = offset + 2
    if length_byte & 0x80:
        count = length_byte & 0x7F
        if not count or cursor + count > len(data):
            raise SnmpError("Invalid SNMP BER length")
        length = int.from_bytes(data[cursor : cursor + count], "big")
        cursor += count
    else:
        length = length_byte
    end = cursor + length
    if end > len(data):
        raise SnmpError("Truncated SNMP BER value")
    return tag, data[cursor:end], end


def decode_snmp_value(tag: int, value: bytes) -> Any:
    if tag in (0x02, 0x41, 0x42, 0x43, 0x46):
        return int.from_bytes(value, "big", signed=tag == 0x02)
    if tag == 0x04:
        return value.decode("utf-8", errors="replace").strip("\x00 ")
    if tag in (0x80, 0x81, 0x82):
        return None
    return value.hex()


def snmp_get(host: str, port: int, community: str, oids: list[str], timeout: float) -> dict[str, Any]:
    request_id = secrets.randbelow(0x3FFFFFFF) + 1
    varbinds = b"".join(ber_tlv(0x30, ber_oid(oid) + ber_tlv(0x05, b"")) for oid in oids)
    pdu = ber_tlv(
        0xA0,
        ber_integer(request_id) + ber_integer(0) + ber_integer(0) + ber_tlv(0x30, varbinds),
    )
    packet = ber_tlv(0x30, ber_integer(1) + ber_tlv(0x04, community.encode("utf-8")) + pdu)

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
        client.settimeout(timeout)
        try:
            client.sendto(packet, (host, port))
            response, _ = client.recvfrom(65535)
        except (TimeoutError, socket.timeout) as exc:
            raise SnmpError(f"SNMP timeout from {host}:{port}") from exc
        except OSError as exc:
            raise SnmpError(f"SNMP connection failed: {exc}") from exc

    outer_tag, outer, _ = read_tlv(response)
    if outer_tag != 0x30:
        raise SnmpError("Invalid SNMP response envelope")
    _, _, cursor = read_tlv(outer, 0)
    _, _, cursor = read_tlv(outer, cursor)
    pdu_tag, pdu_value, _ = read_tlv(outer, cursor)
    if pdu_tag != 0xA2:
        raise SnmpError("Unexpected SNMP response type")
    _, response_id_bytes, cursor = read_tlv(pdu_value, 0)
    if int.from_bytes(response_id_bytes, "big", signed=True) != request_id:
        raise SnmpError("SNMP request ID mismatch")
    _, error_bytes, cursor = read_tlv(pdu_value, cursor)
    error_status = int.from_bytes(error_bytes, "big", signed=True)
    _, _, cursor = read_tlv(pdu_value, cursor)
    if error_status:
        raise SnmpError(f"SNMP agent returned error status {error_status}")
    list_tag, varbind_list, _ = read_tlv(pdu_value, cursor)
    if list_tag != 0x30:
        raise SnmpError("Invalid SNMP variable list")

    values: dict[str, Any] = {}
    cursor = 0
    for oid in oids:
        varbind_tag, varbind, cursor = read_tlv(varbind_list, cursor)
        if varbind_tag != 0x30:
            raise SnmpError("Invalid SNMP variable binding")
        _, _, value_cursor = read_tlv(varbind, 0)
        value_tag, value, _ = read_tlv(varbind, value_cursor)
        values[oid] = decode_snmp_value(value_tag, value)
    return values


def collect_snmp_data(config: dict[str, Any]) -> dict[str, Any]:
    snmp = config.get("snmp", {})
    host = str(snmp.get("host", "")).strip()
    if not host:
        raise SnmpError("snmp.host is empty")
    oid_map = {
        "description": "1.3.6.1.2.1.1.1.0",
        "host_name": "1.3.6.1.2.1.1.5.0",
        "serial_number": "1.3.6.1.2.1.43.5.1.1.17.1",
        "total_impressions": "1.3.6.1.2.1.43.10.2.1.4.1.1",
        # KYOCERA KMCOMMON-MIB function counters.
        "printer_pages": "1.3.6.1.4.1.1347.42.3.1.1.1.1.1",
        "copy_pages": "1.3.6.1.4.1.1347.42.3.1.1.1.1.2",
        "other_pages": "1.3.6.1.4.1.1347.42.3.1.1.1.1.3",
        "fax_pages": "1.3.6.1.4.1.1347.42.3.1.1.1.1.4",
    }
    values = snmp_get(
        host,
        int(snmp.get("port", 161)),
        str(snmp.get("community", "public")),
        list(oid_map.values()),
        float(snmp.get("timeout_seconds", 5)),
    )
    result = {
        key: values[oid]
        for key, oid in oid_map.items()
        if values.get(oid) not in (None, "")
    }
    function_keys = ("copy_pages", "printer_pages", "fax_pages")
    if all(isinstance(result.get(key), int) for key in function_keys):
        printed_pages = {
            "copy": result.pop("copy_pages"),
            "printer": result.pop("printer_pages"),
            "fax": result.pop("fax_pages"),
        }
        printed_pages["total"] = sum(printed_pages.values())
        result["printed_pages"] = printed_pages
        # The business meter is strictly Copy + Printer + Fax. The generic
        # Printer-MIB impression counter can include additional impressions.
        result["total_impressions"] = printed_pages["total"]
    else:
        # Query separately: several printer-only agents return noSuchInstance
        # for every varbind after an unsupported multifunction OID.
        bucket_oids = [
            f"1.3.6.1.4.1.1347.42.2.1.1.1.6.1.{index}"
            for index in range(1, 11)
        ]
        bucket_result = snmp_get(
            host,
            int(snmp.get("port", 161)),
            str(snmp.get("community", "public")),
            bucket_oids,
            float(snmp.get("timeout_seconds", 5)),
        )
        bucket_values = [bucket_result.get(oid) for oid in bucket_oids]
        available_buckets = [
            value for value in bucket_values
            if isinstance(value, int) and not isinstance(value, bool)
        ]
        if available_buckets:
            printer_total = sum(available_buckets)
            result["printed_pages"] = {
                "copy": 0,
                "printer": printer_total,
                "fax": 0,
                "total": printer_total,
            }
            result["total_impressions"] = printer_total
    return result


def load_config(path: Path) -> dict[str, Any]:
    try:
        config = json.loads(path.read_text(encoding="utf-8-sig"))
        if isinstance(config.get("api"), dict) and config["api"].get("protected"):
            config["api"] = load_api_secrets()
        return config
    except FileNotFoundError as exc:
        raise PrinterError(
            f"Configuration file not found: {path}. Copy config.example.json to config.json."
        ) from exc
    except json.JSONDecodeError as exc:
        raise PrinterError(f"Invalid JSON in {path}: {exc}") from exc
    except SecretStoreError as exc:
        if sys.platform.startswith("linux"):
            # Credentials created by an older root-only package can become
            # unreadable after the desktop UI is moved to an unprivileged
            # session. Preserve printer/schedule settings and safely enroll a
            # fresh device instead of making the application unusable.
            recovered_api = {
                "endpoint": "https://horus-center.org/api/v1/meter-consumptions",
                "activation_endpoint": "https://horus-center.org/api/v1/devices/activate",
                "auto_activation_endpoint": "https://horus-center.org/api/v1/devices/auto-activate",
                "auth_type": "device_bearer",
                "device_id": "",
                "installation_id": "",
                "access_token": "",
                "bearer_token": "",
                "activated": False,
                "verify_tls": True,
                "credential_schema_version": 2,
            }
            save_api_secrets(recovered_api)
            config["api"] = recovered_api
            LOG.warning("Unreadable Linux device credentials were replaced for automatic re-enrollment: %s", exc)
            return config
        raise PrinterError(str(exc)) from exc


def make_opener(verify_tls: bool):
    context = ssl.create_default_context()
    if not verify_tls:
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    return build_opener(HTTPCookieProcessor(CookieJar()), HTTPSHandler(context=context))


def request_text(opener, url: str, *, timeout: int, data=None, headers=None) -> str:
    request = Request(url, data=data, headers=headers or {})
    try:
        with opener.open(request, timeout=timeout) as response:
            return response.read().decode("utf-8", errors="replace")
    except HTTPError as exc:
        raise PrinterError(f"HTTP {exc.code} from {url}") from exc
    except URLError as exc:
        raise PrinterError(f"Cannot connect to {url}: {exc.reason}") from exc


def is_deep_sleep(source: str) -> bool:
    return 'src="DeepSleep.htm"' in source or "src='DeepSleep.htm'" in source


def wake_printer(opener, base_url: str, timeout: int, headers: dict[str, str]) -> None:
    body = urlencode(
        {"okhtmfile": "DeepSleepApply.htm", "func": "wakeup", "submit001": "Start"}
    ).encode("ascii")
    request_text(
        opener,
        f"{base_url}/esu/set.cgi",
        timeout=timeout,
        data=body,
        headers={
            **headers,
            "Content-Type": "application/x-www-form-urlencoded",
            "Referer": f"{base_url}/DeepSleep.htm",
        },
    )


def js_value(source: str, label_expression: str) -> str | None:
    pattern = (
        r"ComnAddLabelProperty\(\s*['\"]\d['\"]\s*,\s*"
        + label_expression
        + r"\s*,\s*['\"]([^'\"]*)['\"]"
    )
    match = re.search(pattern, source)
    return match.group(1).strip() if match else None


def js_integer(source: str, expression: str) -> int | None:
    match = re.search(expression + r"\s*=\s*['\"]?(\d+)['\"]?\s*;", source)
    return int(match.group(1)) if match else None


def model_value(source: str, name: str) -> str | None:
    match = re.search(
        rf"_pp\.{re.escape(name)}\s*=\s*(?:\()?['\"]([^'\"]*)['\"]",
        source,
    )
    return match.group(1).strip() if match else None


def model_integer(source: str, name: str) -> int | None:
    value = model_value(source, name)
    return int(value) if value and value.isdigit() else None


def collect_counters(opener, base_url: str, timeout: int, headers: dict[str, str]) -> dict[str, Any]:
    referer = f"{base_url}/startwlm/Start_Wlm.htm"
    printed_source = request_text(
        opener,
        f"{base_url}/dvcinfo/dvccounter/DvcInfo_Counter_PrnCounter.htm",
        timeout=timeout,
        headers={**headers, "Referer": referer},
    )
    printed = {
        "copy": js_integer(printed_source, r"counterBlackWhite\[0\]"),
        "printer": js_integer(printed_source, r"counterBlackWhite\[1\]"),
        "fax": js_integer(printed_source, r"counterBlackWhite\[2\]"),
    }
    if not any(value is not None for value in printed.values()):
        model_source = request_text(
            opener,
            f"{base_url}/js/jssrc/model/dvcinfo/dvccounter/DvcInfo_Counter_PrnCounter.model.htm",
            timeout=timeout,
            headers={**headers, "Referer": f"{base_url}/dvcinfo/dvccounter/DvcInfo_Counter_PrnCounter.htm"},
        )
        printed = {
            "copy": model_integer(model_source, "copytotal"),
            "printer": model_integer(model_source, "printertotal"),
            "fax": model_integer(model_source, "faxTotal"),
        }
    printed = {key: value for key, value in printed.items() if value is not None}
    printed["total"] = sum(printed.values())

    if len(printed) == 1:
        raise PrinterError("The printer responded, but its counters could not be parsed.")

    result: dict[str, Any] = {"printed_pages": printed}
    try:
        scanned_source = request_text(
            opener,
            f"{base_url}/dvcinfo/dvccounter/DvcInfo_Counter_ScanCounter.htm",
            timeout=timeout,
            headers={**headers, "Referer": referer},
        )
        scanned = {
            "copy": js_integer(scanned_source, r"scanCopy"),
            "fax": js_integer(scanned_source, r"scanBlackWhite"),
            "other": js_integer(scanned_source, r"scanOther"),
        }
        scanned = {key: value for key, value in scanned.items() if value is not None}
        if scanned:
            scanned["total"] = sum(scanned.values())
            result["scanned_pages"] = scanned
    except PrinterError:
        # Printer-only models legitimately do not expose a scan-counter page.
        pass
    return result


def collect_web_data(config: dict[str, Any]) -> dict[str, Any]:
    printer = config["printer"]
    base_url = printer["base_url"].rstrip("/")
    timeout = int(printer.get("timeout_seconds", 15))
    opener = make_opener(bool(printer.get("verify_tls", True)))
    common_headers = {"User-Agent": "KyoceraPrinterForwarder/1.0"}

    # These first two requests create the session expected by older Command Center RX firmware.
    root_source = request_text(opener, f"{base_url}/", timeout=timeout, headers=common_headers)
    woke_from_sleep = False
    if is_deep_sleep(root_source):
        LOG.info("Printer is in Deep Sleep; requesting a web-interface wake-up.")
        wake_printer(opener, base_url, timeout, common_headers)
        woke_from_sleep = True
        retries = int(printer.get("wake_retries", 5))
        delay = float(printer.get("wake_retry_delay_seconds", 2))
        for attempt in range(1, retries + 1):
            time.sleep(delay)
            root_source = request_text(opener, f"{base_url}/", timeout=timeout, headers=common_headers)
            if not is_deep_sleep(root_source):
                LOG.info("Printer web interface woke up after attempt %s.", attempt)
                break
        else:
            raise PrinterError("Printer is still in Deep Sleep after the configured wake-up retries.")

    start_error: PrinterError | None = None
    for start_path in ("/startwlm/Start_Wlm.htm", "/startwlm/Start_Wlm.htm?arg11=%22%22"):
        try:
            request_text(
                opener,
                f"{base_url}{start_path}",
                timeout=timeout,
                headers={**common_headers, "Referer": f"{base_url}/"},
            )
            start_error = None
            break
        except PrinterError as exc:
            start_error = exc
    if start_error is not None:
        raise start_error

    config_sources: list[str] = []
    for config_path in ("/dvcinfo/dvcconfig/DvcConfig_Config.htm", "/startwlm/DvcConfig_Config.htm"):
        try:
            config_sources.append(request_text(
                opener,
                f"{base_url}{config_path}",
                timeout=timeout,
                headers={**common_headers, "Referer": f"{base_url}/startwlm/Start_Wlm.htm"},
            ))
            break
        except PrinterError:
            continue
    if not config_sources:
        raise PrinterError("The printer panel does not expose a supported configuration page.")
    source = config_sources[0]

    fields = {
        "model": js_value(source, r"mes\[0\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "host_name": js_value(source, r"mes\[1\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "location": js_value(source, r"mes\[2\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "serial_number": js_value(source, r"mes\[174\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "mac_address": js_value(source, r"mes\[175\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "memory": js_value(source, r"mes\[2106\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "system_version": js_value(source, r"mes\[193\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "engine_version": js_value(source, r"mes\[194\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "panel_version": js_value(source, r"mes\[195\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "ipv4_address": js_value(source, r"['\"]&nbsp;&nbsp;&nbsp;['\"]\s*\+\s*mes\[199\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "subnet_mask": js_value(source, r"['\"]&nbsp;&nbsp;&nbsp;['\"]\s*\+\s*mes\[972\]\s*\+\s*['\"]\s*:\s*['\"]"),
        "default_gateway": js_value(source, r"['\"]&nbsp;&nbsp;&nbsp;['\"]\s*\+\s*mes\[973\]\s*\+\s*['\"]\s*:\s*['\"]"),
    }
    fields = {key: value for key, value in fields.items() if value is not None}

    if not fields.get("serial_number"):
        try:
            model_source = request_text(
                opener,
                f"{base_url}/js/jssrc/model/dvcinfo/dvcconfig/DvcConfig_Config.model.htm",
                timeout=timeout,
                headers={**common_headers, "Referer": f"{base_url}/dvcinfo/dvcconfig/DvcConfig_Config.htm"},
            )
            fields.update({key: value for key, value in {
                "model": model_value(model_source, "model"),
                "host_name": model_value(model_source, "hostName"),
                "location": model_value(model_source, "location"),
                "serial_number": model_value(model_source, "serialNumber"),
                "mac_address": model_value(model_source, "macAddress"),
                "ipv4_address": model_value(model_source, "ipv4IPAddressWired"),
            }.items() if value is not None})
        except PrinterError:
            pass

    if not fields.get("serial_number"):
        legacy_serial = re.search(r"mes\[174\]\s*;\s*sData\[nTmp\]\s*=\s*['\"]([^'\"]+)", source)
        legacy_model = re.search(r"mes\[0\]\s*;\s*sData\[nTmp\]\s*=\s*['\"]([^'\"]+)", source)
        if legacy_serial:
            fields["serial_number"] = legacy_serial.group(1).strip()
        if legacy_model:
            fields["model"] = legacy_model.group(1).strip()

    if not fields.get("serial_number"):
        raise PrinterError("The printer responded, but its serial number could not be parsed.")

    try:
        counters = collect_counters(opener, base_url, timeout, common_headers)
        panel_counters_available = True
    except PrinterError:
        # Some older Triumph-Adler printer panels publish identity/status only.
        counters = {}
        panel_counters_available = False

    return {
        "printer": fields,
        "counters": counters,
        "panel_counters_available": panel_counters_available,
        "woke_from_deep_sleep": woke_from_sleep,
    }


def collect_printer_data(config: dict[str, Any]) -> dict[str, Any]:
    source_status: dict[str, Any] = {}
    snmp_data: dict[str, Any] = {}
    web_data: dict[str, Any] = {}

    if config.get("snmp", {}).get("enabled", True):
        try:
            snmp_data = collect_snmp_data(config)
            source_status["snmp"] = {"ok": True}
        except SnmpError as exc:
            source_status["snmp"] = {"ok": False, "error": str(exc)}
            LOG.warning("SNMP collection failed; continuing with web fallback: %s", exc)

    try:
        web_data = collect_web_data(config)
        source_status["web"] = {
            "ok": True,
            "counters_available": bool(web_data.get("panel_counters_available")),
        }
    except PrinterError as exc:
        source_status["web"] = {"ok": False, "error": str(exc)}
        LOG.warning("Web collection failed: %s", exc)

    if not snmp_data and not web_data:
        raise PrinterError("Both SNMP and web collection failed")

    printer_data = dict(web_data.get("printer", {}))
    for key in ("host_name", "serial_number"):
        if snmp_data.get(key):
            printer_data[key] = snmp_data[key]

    counters = dict(web_data.get("counters", {}))
    if isinstance(snmp_data.get("printed_pages"), dict):
        # Prefer the vendor counters so SNMP-only and web-assisted collection
        # expose the same Copy + Printer + Fax definition.
        counters["printed_pages"] = dict(snmp_data["printed_pages"])
    if isinstance(counters.get("printed_pages"), dict):
        counters["copy_printer_fax_total"] = counters["printed_pages"].get("total")
    if "total_impressions" in snmp_data:
        counters["snmp_total_impressions"] = snmp_data["total_impressions"]

    result: dict[str, Any] = {
        "printer": printer_data,
        "counters": counters,
        "snmp": snmp_data,
        "sources": source_status,
        "source_url": config["printer"]["base_url"].rstrip("/"),
        "collected_at": datetime.now(timezone.utc).isoformat(),
    }
    if "woke_from_deep_sleep" in web_data:
        result["woke_from_deep_sleep"] = web_data["woke_from_deep_sleep"]
    return result


def collect_all_printers(config: dict[str, Any]) -> dict[str, Any]:
    profiles = config.get("printers")
    if not profiles:
        profiles = [
            {
                "id": "printer-1",
                "name": config.get("printer", {}).get("name", "Printer 1"),
                "snmp": config.get("snmp", {}),
                "printer": config.get("printer", {}),
            }
        ]

    results: list[dict[str, Any]] = []
    successful = 0
    for index, profile in enumerate(profiles, start=1):
        printer_id = str(profile.get("id") or f"printer-{index}")
        printer_name = str(profile.get("name") or f"Printer {index}")
        try:
            if str(profile.get("connection_type", "network")).lower() == "usb":
                payload = collect_usb_printer(profile)
            else:
                profile_config = {
                    "snmp": profile.get("snmp", {}),
                    "printer": profile.get("printer", {}),
                }
                payload = collect_printer_data(profile_config)
            payload["id"] = printer_id
            payload["name"] = printer_name
            payload["ok"] = True
            successful += 1
        except (KeyError, TypeError, ValueError, PrinterError, UsbPrinterError) as exc:
            payload = {
                "id": printer_id,
                "name": printer_name,
                "ok": False,
                "error": str(exc),
                "collected_at": datetime.now(timezone.utc).isoformat(),
            }
        results.append(payload)

    if not successful:
        raise PrinterError("Collection failed for every configured printer")

    return {
        "printers": results,
        "summary": {
            "configured": len(results),
            "successful": successful,
            "failed": len(results) - successful,
        },
        "collected_at": datetime.now(timezone.utc).isoformat(),
    }


def _activation_endpoint(api: dict[str, Any]) -> str:
    explicit = str(api.get("activation_endpoint", "")).strip()
    if explicit:
        return explicit
    meter_endpoint = str(api.get("endpoint", "")).strip()
    parts = urlsplit(meter_endpoint)
    return urlunsplit((parts.scheme, parts.netloc, "/api/v1/devices/activate", "", ""))


def _auto_activation_endpoint(api: dict[str, Any]) -> str:
    explicit = str(api.get("auto_activation_endpoint", "")).strip()
    if explicit:
        return explicit
    meter_endpoint = str(api.get("endpoint", "")).strip()
    parts = urlsplit(meter_endpoint)
    return urlunsplit((parts.scheme, parts.netloc, "/api/v1/devices/auto-activate", "", ""))


def prepare_device_identity(api: dict[str, Any]) -> dict[str, Any]:
    prepared = dict(api)
    prepared["device_id"] = str(prepared.get("device_id") or uuid.uuid4())
    prepared["installation_id"] = str(prepared.get("installation_id") or uuid.uuid4())
    prepared["auth_type"] = "device_bearer"
    return prepared


def auto_activate_device(api: dict[str, Any], *, device_name: str, platform_name: str, app_version: str) -> dict[str, Any]:
    prepared = prepare_device_identity(api)
    if prepared.get("activated") and prepared.get("access_token"):
        return prepared
    endpoint = _auto_activation_endpoint(prepared)
    parts = urlsplit(endpoint)
    if parts.scheme != "https" and parts.hostname not in {"127.0.0.1", "localhost", "::1"}:
        raise PrinterError("Automatic activation requires HTTPS outside local development.")
    def request_activation() -> dict[str, Any]:
        body = json.dumps({
            "device_id": prepared["device_id"],
            "installation_id": prepared["installation_id"],
            "device_name": device_name,
            "platform": platform_name,
            "app_version": app_version,
        }, ensure_ascii=False).encode("utf-8")
        request = Request(endpoint, data=body, headers={
            "Accept": "application/json",
            "Content-Type": "application/json; charset=utf-8",
            "Idempotency-Key": prepared["installation_id"],
            "User-Agent": f"KyoceraPrinterManager/{app_version}",
        }, method="POST")
        with make_opener(True).open(request, timeout=int(prepared.get("timeout_seconds", 20))) as response:
            return json.loads(response.read().decode("utf-8"))

    try:
        result = request_activation()
    except HTTPError as exc:
        if exc.code != 409:
            raise PrinterError(f"Automatic device activation was rejected (HTTP {exc.code}).") from exc
        # The server already owns this identity but the local token was lost.
        # Retry once as a fresh installation without exposing server details.
        prepared["device_id"] = str(uuid.uuid4())
        prepared["installation_id"] = str(uuid.uuid4())
        try:
            result = request_activation()
        except HTTPError as retry_exc:
            raise PrinterError(f"Automatic device activation was rejected (HTTP {retry_exc.code}).") from retry_exc
        except (URLError, json.JSONDecodeError) as retry_exc:
            raise PrinterError("Automatic device activation failed because the server response was unavailable or invalid.") from retry_exc
    except (URLError, json.JSONDecodeError) as exc:
        raise PrinterError("Automatic device activation failed because the server response was unavailable or invalid.") from exc
    token = str(result.get("access_token", "")).strip()
    returned_device_id = str(result.get("device_id") or prepared["device_id"]).strip()
    if not token or not returned_device_id:
        raise PrinterError("Automatic activation succeeded without valid device credentials.")
    prepared.update({
        "device_id": returned_device_id, "access_token": token,
        "bearer_token": "", "api_key_value": "", "activated": True,
    })
    return prepared


def activate_device(api: dict[str, Any], activation_code: str, *, device_name: str, platform_name: str, app_version: str) -> dict[str, Any]:
    endpoint = _activation_endpoint(api)
    parts = urlsplit(endpoint)
    if parts.scheme != "https" and parts.hostname not in {"127.0.0.1", "localhost", "::1"}:
        raise PrinterError("Device activation requires HTTPS outside local development.")
    device_id = str(api.get("device_id") or uuid.uuid4())
    body = json.dumps({
        "activation_code": activation_code.strip().upper(),
        "device_id": device_id,
        "device_name": device_name,
        "platform": platform_name,
        "app_version": app_version,
    }, ensure_ascii=False).encode("utf-8")
    request = Request(endpoint, data=body, headers={
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
        "User-Agent": f"KyoceraPrinterManager/{app_version}",
    }, method="POST")
    try:
        with make_opener(True).open(request, timeout=int(api.get("timeout_seconds", 20))) as response:
            result = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        # Do not copy the server body into logs; it may contain sensitive details.
        raise PrinterError(f"Device activation was rejected (HTTP {exc.code}).") from exc
    except (URLError, json.JSONDecodeError) as exc:
        raise PrinterError("Device activation failed because the server response was unavailable or invalid.") from exc
    token = str(result.get("access_token", "")).strip()
    returned_device_id = str(result.get("device_id") or device_id).strip()
    if not token or not returned_device_id:
        raise PrinterError("Activation succeeded without valid device credentials.")
    protected = dict(api)
    protected.update({
        "auth_type": "device_bearer",
        "device_id": returned_device_id,
        "access_token": token,
        "bearer_token": "",
        "api_key_value": "",
        "activated": True,
    })
    return protected


def normalize_meter_totals(payload: dict[str, Any]) -> dict[str, Any]:
    """Enforce Copy + Printer + Fax for new and already-queued reports."""
    for item in payload.get("printers", []):
        if not isinstance(item, dict):
            continue
        counters = item.get("counters")
        if not isinstance(counters, dict):
            continue
        printed = counters.get("printed_pages")
        if not isinstance(printed, dict):
            continue
        values = [printed.get(key) for key in ("copy", "printer", "fax")]
        if not all(isinstance(value, int) and not isinstance(value, bool) for value in values):
            continue
        total = sum(values)
        printed["total"] = total
        counters["copy_printer_fax_total"] = total
        # The current meter-consumptions batch contract reads this legacy
        # field for both network and USB printers. Populate it at send time so
        # already-queued USB reports are repaired before their next retry.
        counters["snmp_total_impressions"] = total
        snmp = item.get("snmp")
        if isinstance(snmp, dict):
            snmp["total_impressions"] = total
    return payload


def send_to_api(config: dict[str, Any], payload: dict[str, Any], idempotency_key: str | None = None) -> tuple[int, str]:
    api = config["api"]
    endpoint = str(api.get("endpoint", "")).strip()
    if not endpoint:
        raise PrinterError("api.endpoint is empty in config.json")

    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
        "User-Agent": "KyoceraPrinterForwarder/1.0",
    }
    auth_type = str(api.get("auth_type", "bearer" if api.get("bearer_token") else "none"))
    token = str(api.get("bearer_token", "")).strip()
    if auth_type == "bearer" and token:
        headers["Authorization"] = f"Bearer {token}"
    if auth_type == "api_key":
        key_header = str(api.get("api_key_header", "X-API-Key")).strip()
        key_value = str(api.get("api_key_value", ""))
        if key_header and key_value:
            headers[key_header] = key_value
    if auth_type == "device_bearer":
        token = str(api.get("access_token", "")).strip()
        device_id = str(api.get("device_id", "")).strip()
        if not token or not device_id:
            raise PrinterError("This computer has not been activated.")
        headers["Authorization"] = f"Bearer {token}"
        headers["X-Device-ID"] = device_id
        headers["Idempotency-Key"] = idempotency_key or str(uuid.uuid4())
    headers.update({str(k): str(v) for k, v in api.get("headers", {}).items()})

    payload = normalize_meter_totals(payload)
    request = Request(
        endpoint,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers=headers,
        method=str(api.get("method", "POST")).upper(),
    )
    opener = make_opener(bool(api.get("verify_tls", True)))
    try:
        with opener.open(request, timeout=int(api.get("timeout_seconds", 20))) as response:
            body = response.read().decode("utf-8", errors="replace")
            return response.status, body
    except HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        if exc.code == 401:
            raise DeviceAuthenticationError("The device credential is invalid or inactive.") from exc
        raise PrinterError(f"API returned HTTP {exc.code}: {body[:500]}") from exc
    except URLError as exc:
        raise PrinterError(f"Cannot connect to API: {exc.reason}") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description="Collect Kyocera printer data and forward it to an API")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--dry-run", action="store_true", help="Print JSON without sending it")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    try:
        config = load_config(args.config)
        payload = collect_all_printers(config)
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        if args.dry_run:
            LOG.info("Dry run completed; nothing was sent.")
            return 0
        from delivery_queue import enqueue_payload, process_queue

        queue_path = enqueue_payload(payload)
        LOG.info("Report saved to delivery queue: %s", queue_path.name)
        result = process_queue(config, send_to_api)
        if result["pending"]:
            LOG.error("Delivery queued; %s report(s) pending. %s", result["pending"], result.get("last_error", ""))
            return 1
        LOG.info("API accepted queued payload(s) with HTTP %s", result.get("http_status", 200))
        if result.get("api_response"):
            LOG.info("API response: %s", result["api_response"][:500])
        return 0
    except (KeyError, TypeError, ValueError, PrinterError) as exc:
        LOG.error("%s", exc)
        return 1


if __name__ == "__main__":
    sys.exit(main())
