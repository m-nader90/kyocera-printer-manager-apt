#!/usr/bin/env python3
"""Apply the public production API endpoints while preserving device credentials."""

from __future__ import annotations

from app_paths import CONFIG_PATH
from printer_forwarder import load_config
from secret_store import save_api_secrets


API_ROOT = "https://horus-center.org/api/v1"


def configure_api_endpoints() -> None:
    config = load_config(CONFIG_PATH)
    api = dict(config["api"])
    if int(api.get("credential_schema_version", 0)) < 2:
        # Tokens issued by the earlier local API are not valid on the production server.
        api.update({"access_token": "", "bearer_token": "", "activated": False})
    api.update({
        "endpoint": f"{API_ROOT}/meter-consumptions",
        "activation_endpoint": f"{API_ROOT}/devices/activate",
        "auto_activation_endpoint": f"{API_ROOT}/devices/auto-activate",
        "verify_tls": True,
        "credential_schema_version": 2,
    })
    save_api_secrets(api)


if __name__ == "__main__":
    configure_api_endpoints()
