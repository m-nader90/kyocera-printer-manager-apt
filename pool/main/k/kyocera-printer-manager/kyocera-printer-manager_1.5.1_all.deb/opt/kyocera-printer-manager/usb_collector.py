"""Cross-platform USB printer discovery and PJL page-counter collection."""

from __future__ import annotations

import json
import os
import platform
import re
import select
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlsplit

from app_paths import INSTALL_DIR, SOURCE_DIR


PJL_QUERY = (
    b"\x1b%-12345X@PJL\r\n"
    b"@PJL ECHO USB_METER_PROBE\r\n"
    b"@PJL INFO ID\r\n"
    b"@PJL INFO CONFIG\r\n"
    b"@PJL INFO PAGECOUNT\r\n"
    b"\x1b%-12345X"
)


class UsbPrinterError(RuntimeError):
    pass


def _field(text: str, *names: str) -> str:
    for name in names:
        match = re.search(rf"(?im)^\s*{re.escape(name)}\s*[:=]\s*[\"']?([^\r\n\"';]+)", text)
        if match:
            return match.group(1).strip()
    return ""


def parse_device_id(value: str | None) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in (value or "").split(";"):
        if ":" not in item:
            continue
        key, raw = item.split(":", 1)
        result[key.strip().upper()] = raw.strip()
    return result


def parse_pjl_response(text: str | None, device_id: str | None = None) -> dict[str, Any]:
    source = text or ""
    ieee = parse_device_id(device_id)
    page_count: int | None = None
    lines = [line.strip() for line in re.split(r"[\r\n\f]+", source) if line.strip()]
    for index, line in enumerate(lines):
        if "PAGECOUNT" not in line.upper():
            continue
        inline = re.search(r"PAGECOUNT\s*[:=]\s*(\d+)", line, re.I)
        if inline:
            page_count = int(inline.group(1))
            break
        for candidate in lines[index + 1:index + 4]:
            if re.fullmatch(r"\d+", candidate):
                page_count = int(candidate)
                break
        if page_count is not None:
            break

    model = _field(source, "MODEL", "MODELNAME") or ieee.get("MDL", "")
    serial = _field(source, "SERIAL NUMBER", "SERIALNUMBER", "SERIAL", "SERN") or ieee.get("SN", "")
    if not model:
        quoted = re.search(r'(?im)^\s*@PJL INFO ID\s*\r?\n\s*["\']?([^\r\n"\']+)', source)
        model = quoted.group(1).strip() if quoted else "USB printer"
    return {"model": model, "serial_number": serial, "page_count": page_count}


def _helper_path() -> Path:
    candidates = [
        INSTALL_DIR / "UsbMeterProbe.exe",
        Path(getattr(sys, "_MEIPASS", INSTALL_DIR)) / "UsbMeterProbe.exe",
        SOURCE_DIR / "build" / "usb-meter-probe" / "UsbMeterProbe.exe",
        SOURCE_DIR / "usb-meter-probe" / "bin" / "Release" / "net8.0-windows" / "win-x64" / "publish" / "UsbMeterProbe.exe",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise UsbPrinterError("The Windows USB meter helper is not installed.")


def _windows_devices(timeout_seconds: float) -> list[dict[str, Any]]:
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    completed = subprocess.run(
        [str(_helper_path()), "--raw", "--timeout-ms", str(max(500, int(timeout_seconds * 1000)))],
        capture_output=True, text=True, timeout=max(15, timeout_seconds + 10), creationflags=flags,
    )
    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise UsbPrinterError("The Windows USB meter helper returned invalid data.") from exc
    results = []
    for device in payload.get("devices", []):
        parsed = parse_pjl_response(device.get("PjlResponse"), device.get("DeviceId"))
        results.append({
            "device_id": device.get("DevicePath", ""),
            "ieee1284_id": device.get("DeviceId", ""),
            "port": "USB",
            "model": parsed["model"],
            "serial_number": parsed["serial_number"],
            "page_count": device.get("PageCount") if device.get("PageCount") is not None else parsed["page_count"],
            "error": device.get("Error"),
        })
    return results


def _cups_busy() -> bool:
    executable = shutil.which("lpstat")
    if not executable:
        return False


def parse_cups_usb_devices(output: str) -> list[dict[str, Any]]:
    """Extract USB printer identity from `lpstat -v` output."""
    devices: list[dict[str, Any]] = []
    for line in output.splitlines():
        match = re.match(r"^device for\s+([^:]+):\s+(usb://\S+)", line.strip(), re.I)
        if not match:
            continue
        queue, uri = match.groups()
        parts = urlsplit(uri)
        model = unquote(parts.path.strip("/")) or unquote(parts.netloc) or queue
        serial = parse_qs(parts.query).get("serial", [""])[0]
        devices.append({
            "device_id": uri,
            "port": uri,
            "model": model,
            "serial_number": unquote(serial),
            "page_count": None,
            "error": None,
            "cups_queue": queue,
        })
    return devices


def _cups_usb_devices() -> list[dict[str, Any]]:
    executable = shutil.which("lpstat")
    if not executable:
        return []
    try:
        result = subprocess.run([executable, "-v"], capture_output=True, text=True, timeout=6)
        return parse_cups_usb_devices(result.stdout) if result.returncode == 0 else []
    except (OSError, subprocess.SubprocessError):
        return []
    try:
        result = subprocess.run([executable, "-o"], capture_output=True, text=True, timeout=4)
        return bool(result.stdout.strip())
    except (OSError, subprocess.SubprocessError):
        return False


def _linux_query(path: Path, timeout_seconds: float) -> str:
    if _cups_busy():
        raise UsbPrinterError("USB collection postponed because CUPS has an active print job.")
    descriptor = os.open(path, os.O_RDWR | os.O_NONBLOCK)
    try:
        os.write(descriptor, PJL_QUERY)
        deadline = time.monotonic() + timeout_seconds
        data = bytearray()
        while time.monotonic() < deadline:
            readable, _, _ = select.select([descriptor], [], [], min(0.5, deadline - time.monotonic()))
            if not readable:
                if data:
                    break
                continue
            try:
                chunk = os.read(descriptor, 8192)
            except BlockingIOError:
                continue
            if chunk:
                data.extend(chunk)
                deadline = min(deadline, time.monotonic() + 0.75)
        if not data:
            raise UsbPrinterError(f"The printer on {path} returned no PJL response.")
        return data.decode("latin-1", errors="replace").strip("\x00")
    finally:
        os.close(descriptor)


def _linux_devices(timeout_seconds: float) -> list[dict[str, Any]]:
    devices = []
    for path in sorted(Path("/dev/usb").glob("lp*")):
        try:
            response = _linux_query(path, timeout_seconds)
            parsed = parse_pjl_response(response)
            error = None
        except (OSError, UsbPrinterError) as exc:
            parsed = {"model": "USB printer", "serial_number": "", "page_count": None}
            error = str(exc)
        devices.append({
            "device_id": str(path), "port": str(path), "model": parsed["model"],
            "serial_number": parsed["serial_number"], "page_count": parsed["page_count"], "error": error,
        })
    cups_devices = _cups_usb_devices()
    if len(devices) == 1 and len(cups_devices) == 1:
        # CUPS normally has the best IEEE-1284 identity while /dev/usb/lpN is
        # required for the bidirectional PJL counter query.
        devices[0]["model"] = cups_devices[0].get("model") or devices[0]["model"]
        devices[0]["serial_number"] = cups_devices[0].get("serial_number") or devices[0]["serial_number"]
        devices[0]["cups_queue"] = cups_devices[0].get("cups_queue")
    elif not devices:
        devices.extend(cups_devices)
    return devices


def discover_usb_printers(timeout_seconds: float = 8) -> list[dict[str, Any]]:
    system = platform.system()
    if system == "Windows":
        devices = _windows_devices(timeout_seconds)
    elif system == "Linux":
        devices = _linux_devices(timeout_seconds)
    else:
        return []
    return [{**device, "connection_type": "usb", "detected_by": "PJL over USB"} for device in devices]


def usb_profile(device: dict[str, Any], index: int) -> dict[str, Any]:
    identity = str(device.get("serial_number") or device.get("device_id") or index)
    safe_identity = re.sub(r"[^a-zA-Z0-9_-]+", "-", identity).strip("-")[-64:]
    return {
        "id": f"usb-{safe_identity or index}",
        "name": str(device.get("model") or f"USB Printer {index + 1}"),
        "connection_type": "usb",
        "usb": {
            "device_id": str(device.get("device_id") or ""),
            "port": str(device.get("port") or "USB"),
            "serial_number": str(device.get("serial_number") or ""),
            "model": str(device.get("model") or "USB printer"),
            "timeout_seconds": 8,
        },
    }


def collect_usb_printer(profile: dict[str, Any]) -> dict[str, Any]:
    usb = profile.get("usb", {})
    wanted_device = str(usb.get("device_id") or "")
    wanted_serial = str(usb.get("serial_number") or "")
    devices = discover_usb_printers(float(usb.get("timeout_seconds", 8)))
    device = next((item for item in devices if wanted_serial and item.get("serial_number") == wanted_serial), None)
    if device is None:
        device = next((item for item in devices if wanted_device and item.get("device_id") == wanted_device), None)
    if device is None and len(devices) == 1:
        device = devices[0]
    if device is None:
        raise UsbPrinterError("The configured USB printer is not connected.")
    if device.get("error"):
        raise UsbPrinterError(str(device["error"]))
    total = device.get("page_count")
    if not isinstance(total, int) or isinstance(total, bool):
        if str(device.get("device_id", "")).startswith("usb://"):
            raise UsbPrinterError(
                "CUPS detected the USB printer, but the bidirectional /dev/usb/lp device is unavailable for reading its counter. Reconnect the printer after installing the latest package, then scan again."
            )
        raise UsbPrinterError("The USB printer responded, but its page counter was unavailable.")
    return {
        "printer": {
            "model": device.get("model") or usb.get("model") or profile.get("name"),
            "serial_number": device.get("serial_number") or wanted_serial,
            "connection_type": "usb",
            "usb_port": device.get("port"),
        },
        "counters": {
            "printed_pages": {"copy": 0, "printer": total, "fax": 0, "total": total},
            "copy_printer_fax_total": total,
            # Compatibility field consumed by the meter API for every printer
            # type. For USB this is the PJL page count, not an SNMP reading.
            "snmp_total_impressions": total,
        },
        "sources": {"usb": {"ok": True, "method": "PJL"}},
        "source_url": f"usb://{device.get('serial_number') or device.get('port') or 'printer'}",
        "connection_type": "usb",
        "collected_at": datetime.now(timezone.utc).isoformat(),
    }
