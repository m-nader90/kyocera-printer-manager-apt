#!/usr/bin/env python3
"""Encrypt initial Linux API configuration during package installation."""

from app_paths import CONFIG_PATH
from secret_store import migrate_linux_secrets, protect_config


if __name__ == "__main__":
    protect_config(CONFIG_PATH)
    migrate_linux_secrets()
