"""Verified TLS contexts that also work in frozen Windows builds."""

from __future__ import annotations

import ssl


def create_verified_ssl_context() -> ssl.SSLContext:
    """Use the bundled Mozilla CA store when it is available.

    Frozen Python applications do not consistently inherit the Windows trust
    store.  Certifi is bundled in the Windows packages so outbound HTTPS and
    WSS connections keep certificate verification enabled without depending on
    machine-specific OpenSSL paths.
    """

    try:
        import certifi
    except ImportError:
        return ssl.create_default_context()
    return ssl.create_default_context(cafile=certifi.where())
