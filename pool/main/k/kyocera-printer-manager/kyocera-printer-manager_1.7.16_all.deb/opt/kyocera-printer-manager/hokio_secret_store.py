"""Machine-bound protected storage for the independent Hokio connector credential."""

from __future__ import annotations

import json
import os
import secrets
import subprocess
import sys
from pathlib import Path
from typing import Any

from app_paths import HOKIO_SECRET_KEY_PATH, HOKIO_SECRET_PATH, ensure_data_dir


ENTROPY = b"KyoceraPrinterManager/HokioConnector/v1"
LINUX_HEADER = b"KPM-HOKIO-OPENSSL-AES256\n"


class HokioSecretStoreError(RuntimeError):
    pass


def _win32crypt():
    if sys.platform != "win32":
        raise HokioSecretStoreError("Hokio protected storage is available on Windows only.")
    import win32crypt

    return win32crypt


def save_connector_secret(value: dict[str, Any], path: Path = HOKIO_SECRET_PATH) -> None:
    required = {"binding_id", "credential_version", "connector_token"}
    if not isinstance(value, dict) or not required <= set(value):
        raise HokioSecretStoreError("The Hokio connector credential is invalid.")
    raw = json.dumps(value, separators=(",", ":"), sort_keys=True).encode("utf-8")
    if sys.platform == "win32":
        encrypted = _win32crypt().CryptProtectData(
            raw,
            "Kyocera Printer Manager Hokio connector",
            ENTROPY,
            None,
            None,
            0x4,
        )
    elif sys.platform.startswith("linux"):
        try:
            key_path = HOKIO_SECRET_KEY_PATH
            key_path.parent.mkdir(parents=True, exist_ok=True)
            if not key_path.exists():
                key_path.write_text(secrets.token_hex(32), encoding="ascii")
                os.chmod(key_path, 0o600)
            result = subprocess.run(
                ["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-salt", "-pass", f"file:{key_path}"],
                input=raw,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
            encrypted = LINUX_HEADER + result.stdout
        except (OSError, subprocess.CalledProcessError) as exc:
            raise HokioSecretStoreError("OpenSSL could not encrypt the Hokio connector credential.") from exc
    else:
        raise HokioSecretStoreError("Hokio protected storage is not supported on this operating system.")
    if path == HOKIO_SECRET_PATH:
        ensure_data_dir()
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(encrypted)
    if sys.platform.startswith("linux"):
        os.chmod(temporary, 0o600)
    os.replace(temporary, path)
    if sys.platform.startswith("linux"):
        os.chmod(path, 0o600)


def load_connector_secret(path: Path = HOKIO_SECRET_PATH) -> dict[str, Any]:
    try:
        encrypted = path.read_bytes()
        if sys.platform == "win32":
            raw = _win32crypt().CryptUnprotectData(encrypted, ENTROPY, None, None, 0)[1]
        elif sys.platform.startswith("linux") and encrypted.startswith(LINUX_HEADER):
            result = subprocess.run(
                [
                    "openssl", "enc", "-d", "-aes-256-cbc", "-pbkdf2",
                    "-pass", f"file:{HOKIO_SECRET_KEY_PATH}",
                ],
                input=encrypted[len(LINUX_HEADER):],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
            raw = result.stdout
        else:
            raise HokioSecretStoreError("Hokio protected storage is not supported on this operating system.")
        value = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise HokioSecretStoreError("The Hokio connector credential could not be decrypted on this computer.") from exc
    if not isinstance(value, dict):
        raise HokioSecretStoreError("The Hokio connector credential is invalid.")
    return value


def delete_connector_secret(path: Path = HOKIO_SECRET_PATH) -> None:
    path.unlink(missing_ok=True)
