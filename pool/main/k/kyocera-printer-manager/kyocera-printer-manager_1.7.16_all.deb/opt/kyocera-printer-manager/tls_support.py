"""Verified TLS contexts that also work in frozen Windows builds."""

from __future__ import annotations

import ssl


def create_verified_ssl_context() -> ssl.SSLContext:
    """Merge the operating-system and bundled Mozilla CA stores.

    Windows deployments may use a locally trusted enterprise TLS issuer while
    frozen Python applications also need a portable public CA bundle.  Loading
    certifi *as* ``cafile`` in ``create_default_context`` replaces the platform
    defaults and rejects those locally trusted issuers.  Start with the system
    roots, then add certifi so both certificate chains remain available while
    hostname and peer verification stay mandatory.
    """

    context = ssl.create_default_context()
    try:
        import certifi
    except ImportError:
        return context

    try:
        context.load_verify_locations(cafile=certifi.where())
    except (OSError, ssl.SSLError):
        # The system store is still verified and usable if a damaged optional
        # bundled CA file cannot be loaded.
        pass
    return context
