"""Bounded loopback-only listener for authenticated Hokio wake notifications."""

from __future__ import annotations

import json
import os
import socket
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable

from app_paths import HOKIO_REPLAY_PATH
from hokio_contract import HokioContractError, verify_wake


MAX_WAKE_BODY = 64 * 1024
MAX_WAKE_HEADER_BYTES = 16 * 1024
MAX_REPLAY_RECORDS = 5000
SOCKET_TIMEOUT_SECONDS = 5


class BoundedThreadingHTTPServer(ThreadingHTTPServer):
    """Reject excess loopback connections before creating worker threads."""

    # A wake listener must own its port exclusively. HTTPServer enables
    # SO_REUSEADDR by default, which can let WSL port forwarding and the
    # Windows service both bind the same loopback port. Requests are then
    # distributed between unrelated listeners and valid signed wakes fail
    # intermittently. Fall back to the next approved port instead.
    allow_reuse_address = False

    def server_bind(self) -> None:
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(
                socket.SOL_SOCKET,
                socket.SO_EXCLUSIVEADDRUSE,
                1,
            )
        super().server_bind()

    def __init__(self, server_address, handler_class, *, max_workers: int):
        self._worker_slots = threading.BoundedSemaphore(max(1, min(32, max_workers)))
        super().__init__(server_address, handler_class)

    def process_request(self, request, client_address) -> None:
        if not self._worker_slots.acquire(blocking=False):
            request.close()
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._worker_slots.release()
            raise

    def process_request_thread(self, request, client_address) -> None:
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._worker_slots.release()


class WakeReplayStore:
    def __init__(self, path: Path = HOKIO_REPLAY_PATH):
        self.path = path
        self._lock = threading.Lock()

    def accept_once(self, wake_id: str, binding_id: str, expires_at: str) -> bool:
        now = datetime.now(timezone.utc)
        with self._lock:
            records = self._load()
            records = [
                item for item in records
                if self._parse(item.get("expires_at")) > now
            ]
            if any(item.get("wake_id") == wake_id and item.get("binding_id") == binding_id for item in records):
                return False
            records.append({"wake_id": wake_id, "binding_id": binding_id, "expires_at": expires_at})
            records = records[-MAX_REPLAY_RECORDS:]
            self._save(records)
            return True

    def _load(self) -> list[dict[str, str]]:
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
            return value if isinstance(value, list) else []
        except (FileNotFoundError, OSError, json.JSONDecodeError):
            return []

    def _save(self, value: list[dict[str, str]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(json.dumps(value, separators=(",", ":")), encoding="utf-8")
        os.replace(temporary, self.path)

    @staticmethod
    def _parse(value: Any) -> datetime:
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            return parsed.astimezone(timezone.utc) if parsed.tzinfo else datetime.min.replace(tzinfo=timezone.utc)
        except ValueError:
            return datetime.min.replace(tzinfo=timezone.utc)


class HokioWakeListener:
    def __init__(
        self,
        *,
        binding_id: str,
        trust: dict[str, Any],
        on_wake: Callable[[], None],
        replay_store: WakeReplayStore | None = None,
        concurrency: int = 8,
    ):
        self.binding_id = binding_id
        self.trust = trust
        self.on_wake = on_wake
        self.replay_store = replay_store or WakeReplayStore()
        self._concurrency = max(1, min(32, concurrency))
        self._semaphore = threading.BoundedSemaphore(self._concurrency)
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    @property
    def port(self) -> int | None:
        return self._server.server_port if self._server else None

    def start(self, preferred: int, fallback_start: int, fallback_end: int) -> int:
        if self._server:
            return int(self._server.server_port)
        ports = [preferred, *[port for port in range(fallback_start, fallback_end + 1) if port != preferred]]
        handler = self._handler()
        last_error: OSError | None = None
        for port in ports:
            try:
                server = BoundedThreadingHTTPServer(
                    ("127.0.0.1", port),
                    handler,
                    max_workers=self._concurrency,
                )
                server.daemon_threads = True
                self._server = server
                self._thread = threading.Thread(target=server.serve_forever, name="hokio-wake-listener", daemon=True)
                self._thread.start()
                return int(server.server_port)
            except OSError as exc:
                last_error = exc
        raise OSError("No approved loopback port is available.") from last_error

    def stop(self) -> None:
        server, thread = self._server, self._thread
        self._server = None
        self._thread = None
        if server:
            server.shutdown()
            server.server_close()
        if thread and thread.is_alive():
            thread.join(timeout=3)

    def _handler(self):
        owner = self

        class WakeHandler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def setup(self) -> None:
                super().setup()
                self.connection.settimeout(SOCKET_TIMEOUT_SECONDS)

            def do_POST(self) -> None:  # noqa: N802
                if self.path != "/wake" or not owner._semaphore.acquire(blocking=False):
                    self._reply(404 if self.path != "/wake" else 503)
                    return
                try:
                    header_bytes = sum(len(str(name)) + len(str(value)) + 4 for name, value in self.headers.items())
                    content_type = self.headers.get_content_type()
                    content_length = self.headers.get("Content-Length")
                    if self.headers.get("Transfer-Encoding") or content_length is None:
                        self._reply(400)
                        return
                    length = int(content_length)
                    if not 1 <= length <= MAX_WAKE_BODY:
                        self._reply(413)
                        return
                    body = self.rfile.read(length)
                    # Drain the bounded request body before returning an early
                    # validation response. On Windows an unread body can turn
                    # the intended HTTP response into a TCP reset.
                    if header_bytes > MAX_WAKE_HEADER_BYTES or content_type != "application/json":
                        self._reply(431 if header_bytes > MAX_WAKE_HEADER_BYTES else 415)
                        return
                    payload = json.loads(body.decode("utf-8"))
                    signed = verify_wake(payload, binding_id=owner.binding_id, trust=owner.trust)
                    if not owner.replay_store.accept_once(
                        str(signed["wake_id"]), owner.binding_id, str(signed["expires_at"])
                    ):
                        self._reply(409)
                        return
                    owner.on_wake()
                    self._reply(202)
                except (ValueError, UnicodeDecodeError, json.JSONDecodeError, HokioContractError):
                    self._reply(400)
                finally:
                    owner._semaphore.release()

            def do_GET(self) -> None:  # noqa: N802
                self._reply(405)

            def _reply(self, status: int) -> None:
                body = b'{"accepted":true}' if status == 202 else b'{"accepted":false}'
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, _format: str, *_args: object) -> None:
                return

        return WakeHandler
