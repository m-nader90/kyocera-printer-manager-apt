"""Automatic printer enrollment shared by installers and the service."""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Any, Callable

from network_discovery import scan_all_printers
from usb_collector import usb_profile


_CONFIG_LOCK = threading.Lock()


def network_profile(device: dict[str, Any], index: int) -> dict[str, Any]:
    ip = str(device.get("ip") or "").strip()
    return {
        "id": f"printer-{int(time.time() * 1000)}-{index}",
        "name": str(device.get("model") or f"Printer {index + 1}"),
        "connection_type": "network",
        "snmp": {
            "enabled": True,
            "host": ip,
            "port": 161,
            "community": "public",
            "timeout_seconds": 5,
        },
        "printer": {
            "base_url": f"http://{ip}",
            "timeout_seconds": 15,
            "wake_retries": 5,
            "wake_retry_delay_seconds": 2,
            "verify_tls": True,
        },
        "discovery": {
            "model": str(device.get("model") or ""),
            "serial_number": str(device.get("serial_number") or ""),
        },
    }


def _serial(profile: dict[str, Any]) -> str:
    if profile.get("connection_type") == "usb":
        return str(profile.get("usb", {}).get("serial_number") or "").strip().casefold()
    return str(
        profile.get("discovery", {}).get("serial_number")
        or profile.get("printer", {}).get("serial_number")
        or ""
    ).strip().casefold()


def merge_discovered_printers(
    profiles: list[dict[str, Any]], discovered: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], int]:
    """Append new devices while preserving configured/offline printers."""
    result = [profile for profile in profiles if isinstance(profile, dict)]
    existing_serials = {value for value in (_serial(profile) for profile in result) if value}
    existing_ips = {
        str(profile.get("snmp", {}).get("host") or "").strip()
        for profile in result
        if profile.get("connection_type", "network") == "network"
    }
    existing_usb = {
        str(profile.get("usb", {}).get("device_id") or profile.get("usb", {}).get("port") or "").strip().casefold()
        for profile in result
        if profile.get("connection_type") == "usb"
    }
    added = 0
    for device in discovered:
        if not isinstance(device, dict):
            continue
        serial = str(device.get("serial_number") or "").strip().casefold()
        if serial and serial in existing_serials:
            continue
        if device.get("connection_type") == "usb":
            fallback = str(device.get("device_id") or device.get("port") or "").strip().casefold()
            if not serial and (not fallback or fallback in existing_usb):
                continue
            profile = usb_profile(device, len(result))
            existing_usb.add(fallback)
        else:
            ip = str(device.get("ip") or "").strip()
            if not ip or ip in existing_ips:
                continue
            profile = network_profile(device, len(result))
            existing_ips.add(ip)
        result.append(profile)
        if serial:
            existing_serials.add(serial)
        added += 1

    # Remove only the unused template profile shipped in a fresh package.
    if added and len(result) > 1:
        result = [
            profile for profile in result
            if profile.get("connection_type") == "usb"
            or str(profile.get("snmp", {}).get("host") or "").strip()
        ]
    return result, added


def configure_automatic_operation(config_path: Path, *, fresh_install: bool = False) -> dict[str, Any]:
    """Enable discovery/delivery and enroll currently reachable printers."""
    with _CONFIG_LOCK:
        existing_config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    existing_discovery = dict(existing_config.get("discovery") or {})
    # A missing section means the installation predates automatic discovery,
    # not that an administrator disabled it. Explicitly disabled installations
    # keep their choice during upgrades and do not get an unexpected scan.
    should_scan = fresh_install or bool(existing_discovery.get("enabled", True))
    scan_error = ""
    if should_scan:
        try:
            scan_result = scan_all_printers()
        except Exception as exc:  # Installation must continue when a network is unavailable.
            scan_result = {"printers": []}
            scan_error = str(exc)
    else:
        scan_result = {"printers": [], "networks": []}

    with _CONFIG_LOCK:
        config = json.loads(config_path.read_text(encoding="utf-8-sig"))
        discovery = dict(config.get("discovery") or {})
        discovery.setdefault("enabled", True)
        discovery.setdefault("scan_on_start", True)
        discovery.setdefault("auto_add", True)
        discovery["interval_minutes"] = max(5, int(discovery.get("interval_minutes", 30)))
        if fresh_install:
            discovery.update({"enabled": True, "scan_on_start": True, "auto_add": True})
        config["discovery"] = discovery
        if fresh_install:
            schedule = dict(config.get("schedule") or {})
            schedule["enabled"] = True
            config["schedule"] = schedule
        profiles, added = merge_discovered_printers(
            list(config.get("printers") or []), list(scan_result.get("printers") or [])
        )
        config["printers"] = profiles
        temporary = config_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        temporary.replace(config_path)
    return {
        "added": added,
        "found": len(scan_result.get("printers") or []),
        "networks": scan_result.get("networks", []),
        "usb_error": scan_result.get("usb_error", ""),
        "error": scan_error,
        "skipped": not should_scan,
    }
