"""Strict validation for Hokio control-sync state and signed wake notifications."""

from __future__ import annotations

import base64
import json
import re
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import urlsplit

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


WAKE_PURPOSE = "horus.device.command-wakeup.v1"
KEYSET_PURPOSE = "horus.device.wakeup-keyset.v1"
KEY_ID = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
METHOD = re.compile(r"^[A-Z]{1,16}$")


class HokioContractError(ValueError):
    pass


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")


def _base64url(value: str, expected: int) -> bytes:
    if not isinstance(value, str) or len(value) > 256:
        raise HokioContractError("Invalid signed data encoding.")
    try:
        decoded = base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
    except (ValueError, TypeError) as exc:
        raise HokioContractError("Invalid signed data encoding.") from exc
    if len(decoded) != expected:
        raise HokioContractError("Invalid signed data length.")
    return decoded


def _timestamp(value: Any) -> datetime:
    if not isinstance(value, str) or len(value) > 64:
        raise HokioContractError("Invalid timestamp.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise HokioContractError("Invalid timestamp.") from exc
    if parsed.tzinfo is None:
        raise HokioContractError("Timestamp must include a timezone.")
    return parsed.astimezone(timezone.utc)


def _https_url(value: Any, scheme: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 2048:
        raise HokioContractError("Invalid Hokio URL.")
    parts = urlsplit(value)
    if parts.scheme.lower() != scheme or not parts.hostname or parts.username or parts.password or parts.fragment:
        raise HokioContractError("Invalid Hokio URL.")
    return value


def validate_extension(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or int(value.get("schema_version", 0)) != 1:
        raise HokioContractError("Unsupported Hokio extension.")
    binding_id = str(value.get("binding_id", ""))
    try:
        uuid.UUID(binding_id)
    except ValueError as exc:
        raise HokioContractError("Invalid Hokio binding.") from exc
    webhook_url = _https_url(value.get("webhook_url"), "https")
    connector = value.get("connector")
    endpoint = value.get("endpoint_policy")
    policy = value.get("port_policy")
    if not isinstance(connector, dict) or not isinstance(endpoint, dict) or not isinstance(policy, dict):
        raise HokioContractError("Incomplete Hokio connector policy.")
    device_id = str(connector.get("device_id", ""))
    if not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", device_id):
        raise HokioContractError("Invalid Hokio connector identity.")
    relay_url = _https_url(connector.get("relay_url"), "wss")
    methods = endpoint.get("allowed_methods")
    paths = endpoint.get("allowed_paths")
    if not isinstance(methods, list) or not 1 <= len(methods) <= 16 or any(not isinstance(x, str) or not METHOD.fullmatch(x) for x in methods):
        raise HokioContractError("Invalid Hokio method policy.")
    if not isinstance(paths, list) or not 1 <= len(paths) <= 32 or any(not isinstance(x, str) or not x.startswith("/") or ".." in x or "?" in x or "#" in x for x in paths):
        raise HokioContractError("Invalid Hokio path policy.")
    if "POST" not in methods or "/wake" not in paths:
        raise HokioContractError("The Hokio wake route is not permitted by policy.")
    preferred = _bounded_int(policy.get("preferred"), 1024, 65535)
    start = _bounded_int(policy.get("fallback_start"), 1024, 65535)
    end = _bounded_int(policy.get("fallback_end"), 1024, 65535)
    if policy.get("host") != "127.0.0.1" or not start <= preferred <= end or end - start + 1 > 100:
        raise HokioContractError("Invalid Hokio port policy.")
    credential_version = _bounded_int(value.get("credential_version"), 1, 2**63 - 1)
    assignment_version = _bounded_int(value.get("assignment_version"), 1, 2**63 - 1)
    policy_version = _bounded_int(policy.get("version", 1), 1, 2**63 - 1)
    delivery = value.get("delivery")
    clean_delivery = None
    if delivery is not None:
        if not isinstance(delivery, dict):
            raise HokioContractError("Invalid Hokio credential delivery.")
        try:
            uuid.UUID(str(delivery.get("delivery_id", "")))
        except ValueError as exc:
            raise HokioContractError("Invalid Hokio credential delivery.") from exc
        token = str(delivery.get("connector_token", ""))
        if not 32 <= len(token) <= 4096 or _timestamp(delivery.get("expires_at")) <= datetime.now(timezone.utc):
            raise HokioContractError("Invalid Hokio credential delivery.")
        clean_delivery = {
            "delivery_id": str(delivery["delivery_id"]),
            "connector_token": token,
            "expires_at": str(delivery["expires_at"]),
        }
    trust = value.get("wakeup_trust")
    clean_trust = validate_keyset(trust) if trust is not None else None
    return {
        "schema_version": 1,
        "state": str(value.get("state", "ready"))[:40],
        "binding_id": binding_id,
        "webhook_url": webhook_url,
        "connector": {"device_id": device_id, "relay_url": relay_url},
        "endpoint_policy": {
            "allowed_methods": methods,
            "allowed_paths": paths,
            "max_concurrency": _bounded_int(endpoint.get("max_concurrency"), 1, 256),
            "max_response_body": _bounded_int(endpoint.get("max_response_body"), 1024, 10 * 1024 * 1024),
            "local_timeout": _bounded_int(endpoint.get("local_timeout"), 1, 300),
        },
        "credential_version": credential_version,
        "assignment_version": assignment_version,
        "port_policy": {"version": policy_version, "preferred": preferred, "fallback_start": start, "fallback_end": end, "host": "127.0.0.1"},
        "delivery": clean_delivery,
        "wakeup_trust": clean_trust,
    }


def validate_keyset(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or value.get("purpose") != KEYSET_PURPOSE:
        raise HokioContractError("Invalid Hokio wake trust.")
    _bounded_int(value.get("version"), 1, 2**63 - 1)
    active = value.get("active_key_id")
    signer = value.get("key_id")
    keys = value.get("keys")
    if not isinstance(active, str) or not KEY_ID.fullmatch(active) or not isinstance(signer, str) or not KEY_ID.fullmatch(signer):
        raise HokioContractError("Invalid Hokio wake trust.")
    if not isinstance(keys, list) or not 1 <= len(keys) <= 8:
        raise HokioContractError("Invalid Hokio wake trust.")
    issued = _timestamp(value.get("issued_at"))
    expires = _timestamp(value.get("expires_at"))
    if expires <= issued or expires <= datetime.now(timezone.utc):
        raise HokioContractError("Expired Hokio wake trust.")
    clean_keys = []
    public_keys: dict[str, bytes] = {}
    for key in keys:
        if not isinstance(key, dict) or key.get("algorithm") != "Ed25519" or not isinstance(key.get("key_id"), str) or not KEY_ID.fullmatch(key["key_id"]):
            raise HokioContractError("Invalid Hokio wake trust key.")
        not_before = _timestamp(key.get("not_before"))
        not_after = _timestamp(key.get("not_after"))
        if not_after <= not_before:
            raise HokioContractError("Invalid Hokio wake trust key.")
        public = _base64url(key.get("public_key"), 32)
        public_keys[key["key_id"]] = public
        clean_keys.append(dict(key))
    if active not in public_keys or signer not in public_keys:
        raise HokioContractError("Invalid Hokio wake trust signer.")
    signed = dict(value)
    signature = _base64url(str(signed.pop("signature", "")), 64)
    try:
        Ed25519PublicKey.from_public_bytes(public_keys[signer]).verify(signature, canonical_json(signed))
    except InvalidSignature as exc:
        raise HokioContractError("Invalid Hokio wake trust signature.") from exc
    return {**signed, "signature": value["signature"], "keys": clean_keys}


def verify_wake(value: Any, *, binding_id: str, trust: dict[str, Any], now: datetime | None = None) -> dict[str, Any]:
    if not isinstance(value, dict) or value.get("version") != 1 or value.get("purpose") != WAKE_PURPOSE:
        raise HokioContractError("Invalid wake request.")
    if set(value) != {"version", "purpose", "wake_id", "binding_id", "command_id", "issued_at", "expires_at", "nonce", "key_id", "signature"}:
        raise HokioContractError("Invalid wake request.")
    if value.get("binding_id") != binding_id:
        raise HokioContractError("Invalid wake request.")
    for field in ("wake_id", "command_id"):
        try:
            uuid.UUID(str(value.get(field, "")))
        except ValueError as exc:
            raise HokioContractError("Invalid wake request.") from exc
    issued = _timestamp(value.get("issued_at"))
    expires = _timestamp(value.get("expires_at"))
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    nonce = value.get("nonce")
    if not isinstance(nonce, str) or not 8 <= len(nonce) <= 128:
        raise HokioContractError("Invalid wake request.")
    if issued > current + timedelta(seconds=30) or expires <= current or (expires - issued).total_seconds() > 300:
        raise HokioContractError("Invalid wake request.")
    key_id = value.get("key_id")
    key = next((item for item in trust.get("keys", []) if item.get("key_id") == key_id), None)
    if not isinstance(key, dict) or not _timestamp(key["not_before"]) <= current < _timestamp(key["not_after"]):
        raise HokioContractError("Invalid wake request.")
    signed = dict(value)
    signature = _base64url(str(signed.pop("signature", "")), 64)
    try:
        Ed25519PublicKey.from_public_bytes(_base64url(key["public_key"], 32)).verify(signature, canonical_json(signed))
    except InvalidSignature as exc:
        raise HokioContractError("Invalid wake request.") from exc
    return signed


def _bounded_int(value: Any, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise HokioContractError("Invalid bounded integer.")
    return value
