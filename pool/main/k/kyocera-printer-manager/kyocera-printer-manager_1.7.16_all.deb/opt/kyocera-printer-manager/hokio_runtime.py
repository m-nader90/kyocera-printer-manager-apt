"""Lifecycle coordinator for protected enrollment, wake listener, and relay connector."""

from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Any, Callable

from app_paths import (
    CONTROL_SYNC_REQUEST_PATH,
    HOKIO_REPLAY_PATH,
    HOKIO_SECRET_KEY_PATH,
    HOKIO_SECRET_PATH,
    HOKIO_STATE_PATH,
)
from hokio_connector import HokioConnectorSupervisor
from hokio_contract import HokioContractError, validate_extension, validate_keyset
from hokio_listener import HokioWakeListener
from hokio_secret_store import load_connector_secret, save_connector_secret


class HokioRuntimeError(RuntimeError):
    pass


class HokioRuntime:
    def __init__(
        self,
        *,
        state_path: Path = HOKIO_STATE_PATH,
        secret_path: Path = HOKIO_SECRET_PATH,
        sync_request_path: Path = CONTROL_SYNC_REQUEST_PATH,
        status_callback: Callable[[dict[str, Any]], None] | None = None,
        save_secret: Callable[[dict[str, Any], Path], None] = save_connector_secret,
        load_secret: Callable[[Path], dict[str, Any]] = load_connector_secret,
    ):
        self.state_path = state_path
        self.secret_path = secret_path
        self.sync_request_path = sync_request_path
        self.status_callback = status_callback or (lambda _status: None)
        self.save_secret = save_secret
        self.load_secret = load_secret
        self.listener: HokioWakeListener | None = None
        self.connector = HokioConnectorSupervisor()
        self._lock = threading.RLock()

    def apply_extension(self, raw: dict[str, Any]) -> dict[str, Any] | None:
        try:
            extension = validate_extension(raw)
        except HokioContractError as exc:
            raise HokioRuntimeError("The Hokio connector response is invalid.") from exc
        with self._lock:
            current = self._load_state()
            self._assert_monotonic(current, extension)
            delivery = extension.pop("delivery", None)
            if delivery:
                secret = {
                    "binding_id": extension["binding_id"],
                    "credential_version": extension["credential_version"],
                    "connector_token": delivery["connector_token"],
                }
                self.save_secret(secret, self.secret_path)
                read_back = self.load_secret(self.secret_path)
                if read_back != secret:
                    raise HokioRuntimeError("The Hokio connector credential could not be verified after storage.")
            clean_state = {**extension, "selected_port": current.get("selected_port")}
            self._atomic_json(clean_state)
            self._start(clean_state)
            selected = self.listener.port if self.listener else None
            clean_state["selected_port"] = selected
            self._atomic_json(clean_state)
            if not delivery:
                return None
            return {
                "schema_version": 1,
                "delivery_id": delivery["delivery_id"],
                "credential_version": extension["credential_version"],
                "assignment_version": extension["assignment_version"],
                "status": "stored",
            }

    def start_from_storage(self) -> bool:
        with self._lock:
            state = self._load_state()
            if not state:
                return False
            try:
                state["wakeup_trust"] = validate_keyset(state.get("wakeup_trust"))
                self._start(state)
                return True
            except Exception:
                self._status("error", "HOKIO_LOCAL_STATE_INVALID")
                return False

    def stop(self) -> None:
        with self._lock:
            self.connector.stop()
            if self.listener:
                self.listener.stop()
            self.listener = None
            self._status("stopped", "")

    def reset_for_device_reenrollment(self) -> None:
        """Release old connector ownership after the API deletes a device."""
        with self._lock:
            self.connector.stop()
            if self.listener:
                self.listener.stop()
            self.listener = None
            paths = [self.state_path, self.secret_path, HOKIO_REPLAY_PATH]
            if self.secret_path == HOKIO_SECRET_PATH:
                paths.append(HOKIO_SECRET_KEY_PATH)
            for path in paths:
                path.unlink(missing_ok=True)
            self._status("unconfigured", "")

    def public_status(self) -> dict[str, Any]:
        state = self._load_state()
        return {
            "state": "online" if self.listener and self.listener.port else ("configured" if state else "unconfigured"),
            "binding_id": state.get("binding_id"),
            "webhook_url": state.get("webhook_url"),
            "selected_port": self.listener.port if self.listener else state.get("selected_port"),
            "credential_version": state.get("credential_version"),
            "assignment_version": state.get("assignment_version"),
        }

    def _start(self, state: dict[str, Any]) -> None:
        trust = state.get("wakeup_trust")
        if not isinstance(trust, dict):
            raise HokioRuntimeError("Hokio wake trust is unavailable.")
        secret = self.load_secret(self.secret_path)
        if secret.get("binding_id") != state.get("binding_id") or int(secret.get("credential_version", 0)) != int(state.get("credential_version", 0)):
            raise HokioRuntimeError("The Hokio connector credential does not match the current binding.")
        policy = state["port_policy"]
        restart_listener = (
            self.listener is None
            or self.listener.binding_id != state["binding_id"]
            or self.listener.port not in range(policy["fallback_start"], policy["fallback_end"] + 1)
        )
        if restart_listener:
            if self.listener:
                self.listener.stop()
            self.listener = HokioWakeListener(
                binding_id=state["binding_id"],
                trust=trust,
                on_wake=self._signal_sync,
                concurrency=min(8, state["endpoint_policy"]["max_concurrency"]),
            )
            self.listener.start(policy["preferred"], policy["fallback_start"], policy["fallback_end"])
        else:
            self.listener.trust = trust
        local_port = int(self.listener.port)
        connector_config = {
            "device_id": state["connector"]["device_id"],
            "token": secret["connector_token"],
            "relay_url": state["connector"]["relay_url"],
            "local_port": local_port,
            "allowed_methods": tuple(state["endpoint_policy"]["allowed_methods"]),
            "allowed_paths": tuple(state["endpoint_policy"]["allowed_paths"]),
            "max_concurrency": state["endpoint_policy"]["max_concurrency"],
            "max_response_body": state["endpoint_policy"]["max_response_body"],
            "local_timeout": float(state["endpoint_policy"]["local_timeout"]),
        }
        self.connector.start(connector_config, lambda status, code: self._status(status, code))

    def _signal_sync(self) -> None:
        self.sync_request_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.sync_request_path.with_suffix(".tmp")
        temporary.write_text("wake\n", encoding="ascii")
        os.replace(temporary, self.sync_request_path)

    def _assert_monotonic(self, current: dict[str, Any], incoming: dict[str, Any]) -> None:
        if not current:
            return
        if current.get("binding_id") != incoming.get("binding_id"):
            raise HokioRuntimeError("The Hokio binding cannot be replaced by synchronization.")
        if current.get("webhook_url") != incoming.get("webhook_url"):
            raise HokioRuntimeError("The permanent Hokio webhook URL changed unexpectedly.")
        for field in ("credential_version", "assignment_version"):
            if int(incoming.get(field, 0)) < int(current.get(field, 0)):
                raise HokioRuntimeError("Stale Hokio connector state was rejected.")
        if int(incoming["port_policy"]["version"]) < int(current.get("port_policy", {}).get("version", 0)):
            raise HokioRuntimeError("Stale Hokio port policy was rejected.")
        incoming_trust = incoming.get("wakeup_trust") or {}
        current_trust = current.get("wakeup_trust") or {}
        if int(incoming_trust.get("version", 0)) < int(current_trust.get("version", 0)):
            raise HokioRuntimeError("Stale Hokio wake trust was rejected.")

    def _load_state(self) -> dict[str, Any]:
        try:
            value = json.loads(self.state_path.read_text(encoding="utf-8-sig"))
            return value if isinstance(value, dict) else {}
        except (FileNotFoundError, OSError, json.JSONDecodeError):
            return {}

    def _atomic_json(self, value: dict[str, Any]) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.state_path.with_suffix(self.state_path.suffix + ".tmp")
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, self.state_path)

    def _status(self, state: str, error_code: str) -> None:
        public = self.public_status()
        public.update({"state": state, "last_error_code": error_code})
        self.status_callback(public)
