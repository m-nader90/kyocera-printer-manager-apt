#!/usr/bin/env python3
"""Long-running background worker for scheduled printer collection and delivery."""

from __future__ import annotations

import argparse
import json
import logging
import os
import signal
import socket
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

from delivery_queue import enqueue_payload, process_queue, queue_count
from printer_forwarder import PrinterError, auto_activate_device, collect_all_printers, load_config, prepare_device_identity, send_to_api
from secret_store import save_api_secrets
from app_paths import CONFIG_PATH, LOG_PATH, STATUS_PATH, ensure_data_dir
from auto_update import UpdateError, check_for_update, mark_update_healthy


DEFAULT_CONFIG = CONFIG_PATH
STOP_REQUESTED = False
APP_VERSION = "1.5.0"
NORMAL_POLL_SECONDS = 10
ERROR_RETRY_SECONDS = 15 * 60
UPDATE_CHECK_SECONDS = 6 * 60 * 60


def ensure_auto_activation(config: dict[str, Any]) -> dict[str, Any]:
    api = config.get("api", {})
    if str(api.get("auth_type", "")) != "device_bearer" or (api.get("activated") and api.get("access_token")):
        return config
    prepared = prepare_device_identity(api)
    save_api_secrets(prepared)
    activated = auto_activate_device(
        prepared,
        device_name=socket.gethostname(),
        platform_name="windows" if sys.platform == "win32" else "linux",
        app_version=APP_VERSION,
    )
    save_api_secrets(activated)
    config["api"] = activated
    logging.info("Device activation completed automatically.")
    return config


def invalidate_device_credential(config: dict[str, Any]) -> dict[str, Any]:
    api = dict(config.get("api", {}))
    api["access_token"] = ""
    api["bearer_token"] = ""
    api["activated"] = False
    save_api_secrets(api)
    config["api"] = api
    logging.warning("The rejected device credential was removed; automatic activation will run again.")
    return config


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_status(**values: Any) -> None:
    current: dict[str, Any] = {}
    try:
        current = json.loads(STATUS_PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    current.update(values)
    current.update({"pid": os.getpid(), "heartbeat": now_iso()})
    temporary = STATUS_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(STATUS_PATH)


def calculate_next_run(schedule: dict[str, Any], now: datetime | None = None) -> datetime:
    now = now or datetime.now()
    if str(schedule.get("mode", "interval")) == "twice_daily":
        configured_times = schedule.get("daily_times", ["12:00", "15:00"])
        candidates: list[datetime] = []
        for value in configured_times:
            target_time = datetime.strptime(str(value), "%H:%M").time()
            target = datetime.combine(now.date(), target_time)
            candidates.append(target if target > now else target + timedelta(days=1))
        return min(candidates)
    if str(schedule.get("mode", "interval")) == "daily":
        target_time = datetime.strptime(str(schedule.get("daily_time", "09:00")), "%H:%M").time()
        target = datetime.combine(now.date(), target_time)
        return target if target > now else target + timedelta(days=1)
    return now + timedelta(minutes=max(1, int(schedule.get("interval_minutes", 15))))


def collect_and_queue(config: dict[str, Any]) -> tuple[dict[str, Any], Path]:
    payload = collect_all_printers(config)
    return payload, enqueue_payload(payload)


def configure_logging() -> None:
    ensure_data_dir()
    handler = RotatingFileHandler(LOG_PATH, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", handlers=[handler, logging.StreamHandler()])


def request_stop(_signum=None, _frame=None) -> None:
    global STOP_REQUESTED
    STOP_REQUESTED = True


def run_once(config_path: Path) -> int:
    try:
        config = ensure_auto_activation(load_config(config_path))
        write_status(state="running", message="Collecting printer data", last_run_started=now_iso())
        payload, queue_path = collect_and_queue(config)
        logging.info("Report saved to delivery queue: %s", queue_path.name)
        result = process_queue(config, send_to_api)
        if result.get("authentication_failed"):
            config = ensure_auto_activation(invalidate_device_credential(config))
            result = process_queue(config, send_to_api)
        delivered = result["pending"] == 0 and result["failed"] == 0
        message = (
            f"Delivery succeeded (HTTP {result.get('http_status', 200)})"
            if delivered
            else f"Delivery queued; {result['pending']} report(s) pending"
        )
        write_status(
            state="idle" if delivered else "retrying",
            message=message,
            last_run_finished=now_iso(),
            queue_pending=result["pending"],
            last_result={"ok": delivered, "summary": payload.get("summary", {}), **result},
        )
        logging.info("%s", message)
        return 0 if delivered else 1
    except Exception as exc:
        write_status(state="error", message=str(exc), last_run_finished=now_iso(), last_result={"ok": False, "error": str(exc)})
        logging.exception("Delivery failed")
        return 1


def run_service(config_path: Path) -> int:
    if threading.current_thread() is threading.main_thread():
        signal.signal(signal.SIGINT, request_stop)
        if hasattr(signal, "SIGTERM"):
            signal.signal(signal.SIGTERM, request_stop)
    logging.info("Background worker started with PID %s", os.getpid())
    mark_update_healthy(APP_VERSION)
    next_run: datetime | None = None
    last_schedule_signature: str | None = None
    last_update_check = 0.0

    while not STOP_REQUESTED:
        cycle_delay = NORMAL_POLL_SECONDS
        try:
            # Updating must not depend on API enrollment. A rejected or offline
            # activation endpoint must never block delivery of a security fix.
            if time.monotonic() - last_update_check >= UPDATE_CHECK_SECONDS:
                last_update_check = time.monotonic()
                try:
                    # The service detects releases and exposes the result to the
                    # GUI. Installation requires an explicit user confirmation.
                    update_result = check_for_update(APP_VERSION, install=False)
                    write_status(update=update_result)
                    if update_result.get("available"):
                        logging.info("Version %s is available and awaiting user confirmation.", update_result.get("latest_version"))
                except UpdateError as exc:
                    logging.warning("Automatic update check skipped: %s", exc)
                    write_status(update={"ok": False, "error": str(exc), "checked_at": now_iso()})
            config = ensure_auto_activation(load_config(config_path))
            retry_result = process_queue(config, send_to_api)
            if retry_result.get("authentication_failed"):
                config = ensure_auto_activation(invalidate_device_credential(config))
                retry_result = process_queue(config, send_to_api)
            if retry_result["sent"]:
                logging.info("Delivered %s queued report(s)", retry_result["sent"])
            if retry_result["failed"]:
                logging.warning("Queued delivery failed; %s report(s) remain pending", retry_result["pending"])
            schedule = config.get("schedule", {})
            signature = json.dumps(schedule, sort_keys=True)
            if not bool(schedule.get("enabled", False)):
                next_run = None
                last_schedule_signature = signature
                write_status(state="waiting", message="Automatic delivery is disabled", next_run=None, queue_pending=queue_count())
            else:
                if next_run is None or signature != last_schedule_signature:
                    next_run = calculate_next_run(schedule)
                    last_schedule_signature = signature
                write_status(state="waiting", message="Waiting for the next scheduled delivery", next_run=next_run.isoformat(), queue_pending=queue_count())
                if datetime.now() >= next_run:
                    run_once(config_path)
                    config = load_config(config_path)
                    next_run = calculate_next_run(config.get("schedule", {}))
                    write_status(state="waiting", message="Waiting for the next scheduled delivery", next_run=next_run.isoformat(), queue_pending=queue_count())
        except (OSError, ValueError, TypeError, KeyError, PrinterError) as exc:
            logging.exception("Worker cycle failed")
            write_status(state="error", message=str(exc), next_run=None)
            next_run = None
            cycle_delay = ERROR_RETRY_SECONDS
        for _ in range(cycle_delay):
            if STOP_REQUESTED:
                break
            time.sleep(1)

    write_status(state="stopped", message="Background worker stopped", next_run=None)
    logging.info("Background worker stopped")
    return 0


def main() -> int:
    ensure_data_dir()
    parser = argparse.ArgumentParser(description="Kyocera Printer Manager background worker")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--once", action="store_true", help="Collect and send immediately, then exit")
    args = parser.parse_args()
    configure_logging()
    return run_once(args.config) if args.once else run_service(args.config)


if __name__ == "__main__":
    sys.exit(main())
