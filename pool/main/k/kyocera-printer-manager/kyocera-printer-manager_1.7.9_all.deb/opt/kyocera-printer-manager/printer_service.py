#!/usr/bin/env python3
"""Long-running background worker for scheduled printer collection and delivery."""

from __future__ import annotations

import argparse
import json
import importlib
import logging
import os
import signal
import socket
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from delivery_queue import enqueue_payload, process_queue, queue_count
from printer_forwarder import DeviceNotRegisteredError, PrinterError, auto_activate_device, collect_all_printers, load_config, prepare_device_identity, send_to_api
from secret_store import save_api_secrets
from app_paths import CONFIG_PATH, CONTROL_SYNC_REQUEST_PATH, INSTALL_DIR, LOG_PATH, STATUS_PATH, ensure_data_dir
from auto_update import UpdateError, check_for_update, mark_update_healthy
from automatic_discovery import configure_automatic_operation, merge_discovered_printers
from network_discovery import scan_all_printers
from remote_control import (
    HokioPendingState,
    RemoteControlClient,
    RemoteControlError,
    hokio_activation_delay_seconds,
    hokio_pending_state,
    next_sync_delay_seconds,
)


DEFAULT_CONFIG = CONFIG_PATH
STOP_REQUESTED = False
NORMAL_POLL_SECONDS = 10
ERROR_RETRY_SECONDS = 60
UPDATE_CHECK_SECONDS = 6 * 60 * 60
CONTROL_RETRY_SECONDS = 5 * 60
CONTROL_CONNECTIVITY_PROBE_SECONDS = 30
COMMAND_RESULT_RETRY_SECONDS = 15
LEGACY_WINDOWS_BUILD = bool(getattr(sys, "frozen", False)) and (INSTALL_DIR / "windows7-legacy.marker").exists()
APP_VERSION = "1.6.7" if LEGACY_WINDOWS_BUILD else "1.7.9"
_STATUS_LOCK = threading.RLock()


def ensure_auto_activation(config: dict[str, Any]) -> dict[str, Any]:
    api = config.get("api", {})
    if str(api.get("auth_type", "")) != "device_bearer" or (api.get("activated") and api.get("access_token")):
        return config
    prepared = prepare_device_identity(api)
    prepared["identity_serial_numbers"] = [
        serial for serial in (
            str(profile.get("usb", {}).get("serial_number") or profile.get("discovery", {}).get("serial_number") or profile.get("printer", {}).get("serial_number") or "").strip()
            for profile in config.get("printers", []) if isinstance(profile, dict)
        ) if serial
    ]
    save_api_secrets(prepared)
    activated = auto_activate_device(
        prepared,
        device_name=socket.gethostname(),
        platform_name="windows" if sys.platform == "win32" else "linux",
        app_version=APP_VERSION,
    )
    save_api_secrets(activated)
    config["api"] = activated
    logging.info("Device activation completed automatically.")
    return config


def invalidate_device_credential(config: dict[str, Any]) -> dict[str, Any]:
    api = dict(config.get("api", {}))
    api["access_token"] = ""
    api["bearer_token"] = ""
    api["activated"] = False
    save_api_secrets(api)
    config["api"] = api
    logging.warning("The rejected device credential was removed; automatic activation will run again.")
    return config


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def control_api_reachable(config: dict[str, Any]) -> bool:
    endpoint = str(config.get("api", {}).get("control_endpoint") or config.get("api", {}).get("endpoint") or "")
    parts = urlsplit(endpoint)
    if not parts.hostname:
        return False
    try:
        with socket.create_connection((parts.hostname, parts.port or (443 if parts.scheme == "https" else 80)), timeout=3):
            return True
    except OSError:
        return False


def write_status(**values: Any) -> None:
    # The worker and the Hokio connector report status from different threads.
    # Serialize read/modify/write so a fresh "online" state cannot be replaced
    # by an older snapshot from the scheduling loop.
    with _STATUS_LOCK:
        current: dict[str, Any] = {}
        try:
            current = json.loads(STATUS_PATH.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass
        current.update(values)
        current.update({"pid": os.getpid(), "heartbeat": now_iso()})
        temporary = STATUS_PATH.with_suffix(".tmp")
        temporary.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        temporary.replace(STATUS_PATH)


def calculate_next_run(schedule: dict[str, Any], now: datetime | None = None) -> datetime:
    local_now = now or datetime.now().astimezone()
    requested_zone = str(schedule.get("timezone", "local")).strip()
    schedule_zone = local_now.tzinfo
    if requested_zone.upper() == "UTC":
        schedule_zone = timezone.utc
    elif requested_zone.lower() != "local":
        match = __import__("re").match(r"^([+-])(\d{2}):(\d{2})$", requested_zone)
        if not match or int(match.group(2)) > 23 or int(match.group(3)) > 59:
            raise ValueError("Schedule timezone must be local, UTC, or an offset such as +03:00.")
        minutes = int(match.group(2)) * 60 + int(match.group(3))
        if match.group(1) == "-":
            minutes = -minutes
        schedule_zone = timezone(timedelta(minutes=minutes))
    now_in_schedule_zone = local_now.astimezone(schedule_zone) if local_now.tzinfo else local_now.replace(tzinfo=schedule_zone)

    def to_local(target: datetime) -> datetime:
        converted = target.astimezone(local_now.tzinfo) if local_now.tzinfo else target
        return converted.replace(tzinfo=None) if now is not None and now.tzinfo is None else converted

    if str(schedule.get("mode", "interval")) == "twice_daily":
        configured_times = schedule.get("daily_times", ["12:00", "15:00"])
        candidates: list[datetime] = []
        for value in configured_times:
            target_time = datetime.strptime(str(value), "%H:%M").time()
            target = datetime.combine(now_in_schedule_zone.date(), target_time, tzinfo=schedule_zone)
            candidates.append(target if target > now_in_schedule_zone else target + timedelta(days=1))
        return to_local(min(candidates))
    if str(schedule.get("mode", "interval")) == "daily":
        target_time = datetime.strptime(str(schedule.get("daily_time", "09:00")), "%H:%M").time()
        target = datetime.combine(now_in_schedule_zone.date(), target_time, tzinfo=schedule_zone)
        return to_local(target if target > now_in_schedule_zone else target + timedelta(days=1))
    return to_local(now_in_schedule_zone + timedelta(minutes=max(1, int(schedule.get("interval_minutes", 15)))))


def schedule_is_due(next_run: datetime, now: datetime | None = None) -> bool:
    """Compare schedule timestamps without mixing naive and timezone-aware values."""
    current = now or (datetime.now(next_run.tzinfo) if next_run.tzinfo else datetime.now())
    if current.tzinfo is None and next_run.tzinfo is not None:
        current = current.replace(tzinfo=next_run.tzinfo)
    elif current.tzinfo is not None and next_run.tzinfo is None:
        current = current.replace(tzinfo=None)
    return current >= next_run


def collect_and_queue(config: dict[str, Any]) -> tuple[dict[str, Any], Path | None]:
    payload = collect_all_printers(config)
    if not payload.get("printers"):
        return payload, None
    return payload, enqueue_payload(payload)


def read_status() -> dict[str, Any]:
    try:
        value = json.loads(STATUS_PATH.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def consume_control_sync_request() -> bool:
    """Consume one wake-up request before any network-dependent work.

    Activation can fail before the normal control-sync block is reached. If
    the request file remained present, the error backoff loop would wake
    immediately and retry activation without delay, creating a request storm.
    """
    try:
        CONTROL_SYNC_REQUEST_PATH.unlink()
        return True
    except FileNotFoundError:
        return False


def _test_printer(config_path: Path, payload: dict[str, Any]) -> dict[str, Any]:
    config = load_config(config_path)
    target = str(payload.get("printer_id") or payload.get("serial_number") or "").strip().casefold()
    if not target:
        raise PrinterError("test_printer requires printer_id or serial_number.")
    profiles = []
    for profile in config.get("printers", []):
        serial = str(profile.get("usb", {}).get("serial_number") or profile.get("discovery", {}).get("serial_number") or profile.get("printer", {}).get("serial_number") or "").strip().casefold()
        if target in {str(profile.get("id") or "").casefold(), serial}:
            profiles.append({**profile, "enabled": True})
    if not profiles:
        raise PrinterError("The requested printer is not configured on this device.")
    result = collect_all_printers({"printers": profiles})
    return {"ok": True, "summary": result.get("summary", {}), "printers": result.get("printers", [])}


def _scan_now(config_path: Path) -> dict[str, Any]:
    scan_result = scan_all_printers()
    raw = json.loads(config_path.read_text(encoding="utf-8-sig"))
    profiles, added = merge_discovered_printers(
        list(raw.get("printers") or []), list(scan_result.get("printers") or [])
    )
    raw["printers"] = profiles
    temporary = config_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(raw, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, config_path)
    return {
        "ok": True, "found": len(scan_result.get("printers") or []), "added": added,
        "networks": scan_result.get("networks", []), "usb_error": scan_result.get("usb_error", ""),
    }


def _schedule_service_restart() -> dict[str, Any]:
    if sys.platform == "win32":
        # A plain `sc stop & sc start` races with SERVICE_STOP_PENDING and can
        # leave the service stopped. Launch the signed service executable as a
        # detached helper; it waits for STOPPED before asking SCM to start it.
        flags = (
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
            | getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0)
        )
        service_executable = (
            Path(sys.executable)
            if getattr(sys, "frozen", False)
            else INSTALL_DIR / "KyoceraPrinterService.exe"
        )
        subprocess.Popen(
            [str(service_executable), "restart-after-delay"],
            creationflags=flags,
            close_fds=True,
        )
    else:
        subprocess.Popen([
            "systemd-run", "--unit=kyocera-printer-manager-control-restart", "--collect", "--on-active=5s",
            "/bin/systemctl", "restart", "kyocera-printer-manager.service",
        ], close_fds=True)
    return {"ok": True, "scheduled": True}


def _install_update() -> dict[str, Any]:
    result = check_for_update(
        APP_VERSION,
        install=True,
        silent=True,
        launch_delay_seconds=5 if sys.platform == "win32" else 0,
    )
    write_status(update=result)
    if not result.get("available"):
        return {"ok": True, "message": "The device is already up to date.", **result}
    return {
        "ok": True,
        "message": "The verified update was downloaded and scheduled for installation.",
        **result,
    }


def control_handlers(config_path: Path) -> dict[str, Any]:
    return {
        "send_now": lambda _payload: {"ok": run_once(config_path) == 0},
        "scan_now": lambda _payload: _scan_now(config_path),
        "test_printer": lambda payload: _test_printer(config_path, payload),
        "restart_service": lambda _payload: _schedule_service_restart(),
        "check_update": lambda _payload: {"ok": True, **check_for_update(APP_VERSION, install=False)},
        "install_update": lambda _payload: _install_update(),
        "sync_configuration": lambda _payload: {"ok": True, "synchronized_at": now_iso()},
    }


def configure_logging() -> None:
    ensure_data_dir()
    handler = RotatingFileHandler(LOG_PATH, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", handlers=[handler, logging.StreamHandler()])


def request_stop(_signum=None, _frame=None) -> None:
    global STOP_REQUESTED
    STOP_REQUESTED = True


def run_once(config_path: Path) -> int:
    try:
        config = ensure_auto_activation(load_config(config_path))
        write_status(state="running", message="Collecting printer data", last_run_started=now_iso())
        payload, queue_path = collect_and_queue(config)
        if queue_path is None:
            write_status(
                state="idle",
                message="No enabled printers are configured",
                last_run_finished=now_iso(),
                queue_pending=queue_count(),
                last_result={"ok": True, "summary": payload.get("summary", {})},
            )
            return 0
        logging.info("Report saved to delivery queue: %s", queue_path.name)
        result = process_queue(config, send_to_api)
        if result.get("registration_missing"):
            config = ensure_auto_activation(invalidate_device_credential(config))
            result = process_queue(config, send_to_api)
        delivered = result["pending"] == 0 and result["failed"] == 0
        message = (
            f"Delivery succeeded (HTTP {result.get('http_status', 200)})"
            if delivered
            else f"Delivery queued; {result['pending']} report(s) pending"
        )
        write_status(
            state="idle" if delivered else "retrying",
            message=message,
            last_run_finished=now_iso(),
            queue_pending=result["pending"],
            last_result={"ok": delivered, "summary": payload.get("summary", {}), **result},
        )
        logging.info("%s", message)
        return 0 if delivered else 1
    except Exception as exc:
        write_status(state="error", message=str(exc), last_run_finished=now_iso(), last_result={"ok": False, "error": str(exc)})
        logging.exception("Delivery failed")
        return 1


def run_service(config_path: Path) -> int:
    if threading.current_thread() is threading.main_thread():
        signal.signal(signal.SIGINT, request_stop)
        if hasattr(signal, "SIGTERM"):
            signal.signal(signal.SIGTERM, request_stop)
    logging.info("Background worker started with PID %s", os.getpid())
    mark_update_healthy(APP_VERSION)
    next_run: datetime | None = None
    last_schedule_signature: str | None = None
    last_update_check = 0.0
    remote_client = RemoteControlClient(config_path)
    hokio_runtime = _initialize_hokio_runtime()
    initial_config = load_config(config_path)
    initial_discovery = initial_config.get("discovery", {})
    initial_discovery_interval = max(5, int(initial_discovery.get("interval_minutes", 30))) * 60
    next_discovery_check = (
        0.0
        if bool(initial_discovery.get("scan_on_start", True))
        else time.monotonic() + initial_discovery_interval
    )
    startup_delay = max(0, int(initial_config.get("remote_control", {}).get("startup_delay_seconds", 30)))
    if hokio_runtime and not hokio_runtime.public_status().get("webhook_url"):
        startup_delay = min(startup_delay, 5)
    next_control_sync = time.monotonic() + startup_delay
    control_offline = False
    next_connectivity_probe = 0.0
    next_command_result_retry = 0.0

    while not STOP_REQUESTED:
        cycle_delay = NORMAL_POLL_SECONDS
        try:
            if consume_control_sync_request():
                next_control_sync = 0.0
            # Updating must not depend on API enrollment. A rejected or offline
            # activation endpoint must never block delivery of a security fix.
            if not LEGACY_WINDOWS_BUILD and time.monotonic() - last_update_check >= UPDATE_CHECK_SECONDS:
                last_update_check = time.monotonic()
                try:
                    # The service detects releases and exposes the result to the
                    # GUI. Installation requires an explicit user confirmation.
                    update_result = check_for_update(APP_VERSION, install=False)
                    write_status(update=update_result)
                    if update_result.get("available"):
                        logging.info("Version %s is available and awaiting user confirmation.", update_result.get("latest_version"))
                except UpdateError as exc:
                    logging.warning("Automatic update check skipped: %s", exc)
                    write_status(update={"ok": False, "error": str(exc), "checked_at": now_iso()})
            config = ensure_auto_activation(load_config(config_path))
            remote = config.get("remote_control", {})
            if time.monotonic() >= next_command_result_retry:
                pending_results = remote_client.flush_pending_results(config)
                next_command_result_retry = time.monotonic() + (
                    COMMAND_RESULT_RETRY_SECONDS if pending_results else NORMAL_POLL_SECONDS
                )
            if control_offline and bool(remote.get("sync_after_network_restore", True)) and time.monotonic() >= next_connectivity_probe:
                next_connectivity_probe = time.monotonic() + CONTROL_CONNECTIVITY_PROBE_SECONDS
                if control_api_reachable(config):
                    next_control_sync = 0.0
            if bool(remote.get("enabled", True)) and time.monotonic() >= next_control_sync:
                try:
                    control_result = remote_client.sync(
                        config,
                        app_version=APP_VERSION,
                        service_status=read_status(),
                        handlers=control_handlers(config_path),
                        capabilities=(
                            ("remote_update_v1", "hokio_connector_v1", "hokio_command_wakeup_v1")
                            if hokio_runtime else ("remote_update_v1",)
                        ) if not LEGACY_WINDOWS_BUILD else (),
                        hokio_extension_handler=(
                            lambda extension: _apply_hokio_extension(hokio_runtime, extension)
                        ) if hokio_runtime else None,
                    )
                    config = ensure_auto_activation(load_config(config_path))
                    control_offline = False
                    pending_hokio = hokio_pending_state(control_result)
                    hokio_activation_delay = (
                        hokio_activation_delay_seconds(control_result, hokio_runtime.public_status())
                        if hokio_runtime else None
                    )
                    next_delay = hokio_activation_delay or next_sync_delay_seconds(config)
                    next_control_sync = time.monotonic() + next_delay
                    if hokio_activation_delay:
                        write_status(hokio={
                            "state": pending_hokio.state if pending_hokio else "awaiting_assignment",
                            "webhook_url": "",
                            "selected_port": None,
                            "last_error_code": "",
                        })
                    write_status(remote_control={
                        "managed": bool(control_result.get("managed", False)),
                        "assignment_status": control_result.get("assignment_status", "unassigned"),
                        "last_sync_at": now_iso(),
                        "next_sync_at": (datetime.now(timezone.utc) + timedelta(seconds=max(0, next_control_sync - time.monotonic()))).isoformat(),
                        "last_error": "",
                    })
                except DeviceNotRegisteredError:
                    config = ensure_auto_activation(invalidate_device_credential(config))
                    control_offline = False
                    next_control_sync = 0.0
                    logging.info("The deleted device record was registered again with the same device identity.")
                except RemoteControlError as exc:
                    control_offline = "Cannot connect to the control API" in str(exc)
                    remote_client.record_error(str(exc))
                    next_control_sync = time.monotonic() + CONTROL_RETRY_SECONDS
                    logging.warning("Remote control synchronization deferred: %s", exc)
                    write_status(remote_control={"last_error": str(exc), "last_attempt_at": now_iso()})
            discovery = config.get("discovery", {})
            if bool(discovery.get("enabled", False)) and bool(discovery.get("auto_add", True)):
                interval_seconds = max(5, int(discovery.get("interval_minutes", 30))) * 60
                if time.monotonic() >= next_discovery_check:
                    discovery_result = configure_automatic_operation(config_path)
                    next_discovery_check = time.monotonic() + interval_seconds
                    config = ensure_auto_activation(load_config(config_path))
                    logging.info(
                        "Automatic discovery found %s printer(s) and added %s new printer(s).",
                        discovery_result["found"], discovery_result["added"],
                    )
            retry_result = process_queue(config, send_to_api)
            if retry_result.get("registration_missing"):
                config = ensure_auto_activation(invalidate_device_credential(config))
                retry_result = process_queue(config, send_to_api)
            if retry_result["sent"]:
                logging.info("Delivered %s queued report(s)", retry_result["sent"])
            if retry_result["failed"]:
                logging.warning("Queued delivery failed; %s report(s) remain pending", retry_result["pending"])
            schedule = config.get("schedule", {})
            signature = json.dumps(schedule, sort_keys=True)
            if not bool(schedule.get("enabled", False)):
                next_run = None
                last_schedule_signature = signature
                write_status(state="waiting", message="Automatic delivery is disabled", next_run=None, queue_pending=queue_count())
            else:
                if next_run is None or signature != last_schedule_signature:
                    next_run = calculate_next_run(schedule)
                    last_schedule_signature = signature
                write_status(state="waiting", message="Waiting for the next scheduled delivery", next_run=next_run.isoformat(), queue_pending=queue_count())
                if schedule_is_due(next_run):
                    run_once(config_path)
                    config = load_config(config_path)
                    next_run = calculate_next_run(config.get("schedule", {}))
                    write_status(state="waiting", message="Waiting for the next scheduled delivery", next_run=next_run.isoformat(), queue_pending=queue_count())
        except (OSError, ValueError, TypeError, KeyError, PrinterError) as exc:
            logging.exception("Worker cycle failed")
            write_status(state="error", message=str(exc), next_run=None)
            next_run = None
            cycle_delay = ERROR_RETRY_SECONDS
        for waited in range(cycle_delay):
            if STOP_REQUESTED:
                break
            if CONTROL_SYNC_REQUEST_PATH.exists():
                break
            if cycle_delay > NORMAL_POLL_SECONDS and waited and waited % NORMAL_POLL_SECONDS == 0:
                # Keep the UI heartbeat alive while an operational error is in
                # backoff; the service is still running even though work failed.
                write_status()
            time.sleep(1)

    if hokio_runtime:
        hokio_runtime.stop()
    write_status(state="stopped", message="Background worker stopped", next_run=None)
    logging.info("Background worker stopped")
    return 0


def _initialize_hokio_runtime() -> Any | None:
    if LEGACY_WINDOWS_BUILD or not (sys.platform == "win32" or sys.platform.startswith("linux")):
        return None
    try:
        runtime_class = getattr(importlib.import_module("hokio_runtime"), "HokioRuntime")
        runtime = runtime_class(status_callback=lambda status: write_status(hokio=status))
        runtime.start_from_storage()
        return runtime
    except Exception as exc:
        # Hokio is an additive transport. A missing/quarantined dependency or
        # damaged connector state must never stop legacy collection, delivery,
        # or periodic control synchronization.
        logging.warning("Hokio runtime is unavailable: %s", type(exc).__name__)
        write_status(hokio={"state": "error", "last_error_code": "HOKIO_RUNTIME_UNAVAILABLE"})
        return None


def _apply_hokio_extension(runtime: Any, extension: dict[str, Any]) -> dict[str, Any] | None:
    try:
        return runtime.apply_extension(extension)
    except Exception as exc:
        # Do not allow port exhaustion, protected-storage failure, connector
        # startup failure, or a malformed additive response to interrupt the
        # existing printer workflow. No credential material is logged here.
        logging.warning("Hokio connector state was rejected: %s", type(exc).__name__)
        write_status(hokio={"state": "error", "last_error_code": "HOKIO_EXTENSION_REJECTED"})
        return None


def main() -> int:
    ensure_data_dir()
    parser = argparse.ArgumentParser(description="Kyocera Printer Manager background worker")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--once", action="store_true", help="Collect and send immediately, then exit")
    parser.add_argument(
        "--bootstrap-installation",
        action="store_true",
        help="Enable automatic discovery/delivery and add reachable printers",
    )
    parser.add_argument(
        "--upgrade-installation",
        action="store_true",
        help="Backfill missing automatic discovery settings and scan reachable printers",
    )
    args = parser.parse_args()
    configure_logging()
    if args.bootstrap_installation:
        result = configure_automatic_operation(args.config, fresh_install=True)
        logging.info("Installation discovery result: %s", result)
        return 0
    if args.upgrade_installation:
        result = configure_automatic_operation(args.config, fresh_install=False)
        logging.info("Upgrade discovery result: %s", result)
        return 0
    return run_once(args.config) if args.once else run_service(args.config)


if __name__ == "__main__":
    sys.exit(main())
